"""Explicit conflict-free research branch with matrix-only geography audit."""
from pathlib import Path
from decimal import Decimal
from datetime import datetime,timezone
import hashlib,io,json,math
import numpy as np
from pyproj import Transformer

ROOT=Path(__file__).resolve().parents[2]
SHA=lambda b:hashlib.sha256(b).hexdigest()
POOL='work/referees/window-targeted-expansion-pool-v2.json'
MANIFEST='work/window-routing/full-v1/manifest.json'
OLDREPORT='work/referees/window-targeted-candidate-alternatives-v2.json'
CLOSED=[401,1495,1548,1679,1832,1833,2450,2571,3411,4536]


def main():
    paths=[POOL,MANIFEST,OLDREPORT,'data/processed/dataset.json','data/processed/health-planning.json','data/processed/joint-plan.json']
    blobs={p:(ROOT/p).read_bytes() for p in paths};j={p:json.loads(b) for p,b in blobs.items()}
    pooldoc=j[POOL];pool=pooldoc['candidateIndices'];M=j[MANIFEST];D=j['data/processed/dataset.json'];H=j['data/processed/health-planning.json'];S=j['data/processed/joint-plan.json']['scenario'];C=D['candidates']
    assert SHA(blobs[POOL])=='e442209f864f3da0d3b2bad5d59ccde516cde77bd7d5d89857f3efaaee5494f6'
    assert SHA(blobs[MANIFEST])==pooldoc['profileManifestSHA256']=='29eb7c5a298536ab6a93a998fef1e39ef18a5ea3edd8d9eaf4b78db484bcc7f1'
    for name,h in pooldoc['sourceSHA256'].items():
        p='data/processed/'+name
        b=(ROOT/p).read_bytes();assert SHA(b)==h
        blobs[p]=b
    assert pool==sorted(set(pool)) and len(pool)==312 and set(CLOSED)<=set(pool)
    retained=[x for x in pool if x not in CLOSED]
    T=Transformer.from_crs(4326,32636,always_xy=True)
    xy={x:np.array(T.transform(C[x]['lon'],C[x]['lat'])) for x in pool}
    conflicts=[]
    for a,x in enumerate(pool):
        for y in pool[:a]:
            distance=float(np.linalg.norm(xy[x]-xy[y]));limit=C[x]['footprintRadiusMeters']+C[y]['footprintRadiusMeters']
            if distance<limit:conflicts.append(dict(candidateIndices=[y,x],distanceMeters=distance,sumRadiusMeters=limit,
                closedMembers=[k for k in (y,x) if k in CLOSED],remainingMembers=[k for k in (y,x) if k not in CLOSED]))
    expected={tuple(sorted(p)) for p in j[OLDREPORT]['newCandidateConflictPairs']}|{(401,1823),(1495,1618),(1549,1679)}
    assert {tuple(p['candidateIndices']) for p in conflicts}==expected and len(conflicts)==12
    assert all(p['closedMembers'] for p in conflicts)
    pop=[Decimal(str(d['population'])) for d in D['demands']];total=Decimal(str(D['metadata']['provincePopulation']))
    assert sum(Decimal(str(d['population'])) for d in D['districts'])==total
    drows={d['id']:[i for i,x in enumerate(D['demands']) if x['districtId']==d['id']] for d in D['districts']}
    involved=sorted(set(k for p in conflicts for k in p['candidateIndices']))
    site_stats={k:dict(candidateIndex=k,id=C[k]['id'],name=C[k]['name'],districtId=C[k]['districtId'],
        closed=k in CLOSED,radiusMeters=C[k]['footprintRadiusMeters'],accessMeters=C[k]['accessMeters'],roadNode=C[k]['node'],
        minimumReachableResidents=None,maximumReachableResidents=0,fittingResourceOptions=[]) for k in involved}
    q=S['contactsPerDoctor']/(H['rates']['contactsPerResident']*S['demandMultiplier'])
    bedrate=H['rates']['bedDaysPerResident']*S['demandMultiplier'];da=H['design']['areaPerDoctorM2'];min_docs=H['design']['minimumDoctorsPerSite']
    target=float(total)*S['coverageTarget']/100;doc_global=max(min_docs,math.ceil(target/q))
    for k,st in site_stats.items():
        available=math.pi*C[k]['footprintRadiusMeters']**2*H['design']['maxFloors']
        for t in H['templates']:
            docs=math.floor(min(math.nextafter((available+.001-t['grossAreaM2'])/da,math.inf),doc_global))
            if docs>=min_docs:
                cap=min(t['beds']*365*S['bedOccupancy']/100/bedrate,docs*q)
                st['fittingResourceOptions'].append(dict(templateId=t['id'],beds=t['beds'],maximumIntegerDoctors=docs,capacityResidents=cap))
        st['maximumIndividualCapacityResidents']=max(x['capacityResidents'] for x in st['fittingResourceOptions'])
    profiles=[];matrix_hashes={};removed=np.array([k in CLOSED for k in pool]);edge_count=0
    for rec in M['matrices']:
        b=(ROOT/MANIFEST).parent.joinpath(rec['file']).read_bytes();assert SHA(b)==rec['sha256'];matrix_hashes[rec['file']]=SHA(b)
        with np.load(io.BytesIO(b),allow_pickle=False) as z:times=z['minutes'][:,pool]
        assert times.shape==(len(pop),312) and not np.isnan(times).any() and (times>=0).all()
        legal=np.isfinite(times)&(times<=45);allreach=legal.any(axis=1);reach=legal[:,~removed].any(axis=1);edge_count+=int(legal[:,~removed].sum())
        whole=sum(pop[i] for i in np.flatnonzero(allreach));covered=sum(pop[i] for i in np.flatnonzero(reach))
        ds=[]
        for d in D['districts']:
            denom=Decimal(str(d['population']));cov=sum(pop[i] for i in drows[d['id']] if reach[i]);allcov=sum(pop[i] for i in drows[d['id']] if allreach[i])
            ds.append(dict(id=d['id'],name=d['name'],population=str(denom),reachableResidents=str(cov),
                reachablePercent=float(cov*100/denom),lostFromFull312Residents=str(allcov-cov),marginOver80Residents=str(cov-denom*Decimal('.8')),
                passes=cov>=denom*Decimal('.8')))
        for k,st in site_stats.items():
            mass=int(sum(pop[i] for i in np.flatnonzero(legal[:,pool.index(k)])))
            st['minimumReachableResidents']=mass if st['minimumReachableResidents'] is None else min(st['minimumReachableResidents'],mass)
            st['maximumReachableResidents']=max(st['maximumReachableResidents'],mass)
        profiles.append(dict(profile=rec['profileId'],reachableResidents=str(covered),reachablePercent=float(covered*100/total),
            lostFromFull312Residents=str(whole-covered),marginOver95Residents=str(covered-total*Decimal('.95')),
            passes=covered>=total*Decimal('.95') and all(d['passes'] for d in ds),districts=ds))
    assert len(profiles)==44 and all(p['passes'] for p in profiles)
    assert all((ROOT/p).read_bytes()==b for p,b in blobs.items())
    report=dict(format=1,builtAt=datetime.now(timezone.utc).isoformat(),auditCodeLF_SHA256=SHA(Path(__file__).read_bytes().replace(b'\r\n',b'\n')),
        sourceSHA256={p:SHA(b) for p,b in blobs.items()},matrixSHA256=matrix_hashes,profileManifestSHA256=SHA(blobs[MANIFEST]),
        candidatePoolCount=312,closedCandidateIndices=CLOSED,remainingCandidateCount=len(retained),remainingCandidateIndices=retained,
        allConflictPairs=conflicts,remainingConflictPairs=[],geometryCRS='EPSG:32636',
        geometryPredicate='Euclidean distance < sum of footprint radii, same strict predicate as original model',
        originalProvincePopulation=str(total),unlocatedPopulation=str(total-sum(pop)),profiles=profiles,
        individualSiteTradeoffs=list(site_stats.values()),remainingFlowEdgeCountAcross44=edge_count,
        minProvinceReachablePercent=min(p['reachablePercent'] for p in profiles),
        minDistrictReachablePercent=min(d['reachablePercent'] for p in profiles for d in p['districts']),
        maximumLostFromFull312Residents=max(int(p['lostFromFull312Residents']) for p in profiles),
        routingCalls=0,nativeSolverCalls=0,
        scope='Explicit optional seed branch only; final full312 formulation retains all original candidates/conflict constraints. Geography relaxes beds, doctors, budget and other allocations. Individual capacity is a separate upper bound across fitting type/integer-doctor pairs, without global budget or assignment. No feasible plan, general infeasibility, minimum count or real-city claim.')
    report_path=ROOT/'work/referees/window312-branch-geography-transport.json'
    with report_path.open('x',encoding='utf8') as f:json.dump(report,f,ensure_ascii=False,indent=2);f.write('\n')
    branch=dict(format=1,artifactType='explicit-seed-conflict-branch',candidatePoolFile=POOL,candidatePoolSHA256=SHA(blobs[POOL]),
        profileManifestSHA256=SHA(blobs[MANIFEST]),sourceSHA256=pooldoc['sourceSHA256'],
        closedCandidateIndices=CLOSED,retainedConflictPartners=sorted(set(k for p in conflicts for k in p['remainingMembers'])),
        geometryAuditFile=report_path.relative_to(ROOT).as_posix(),geometryAuditSHA256=SHA(report_path.read_bytes()),
        allConflictPairs=[p['candidateIndices'] for p in conflicts],remainingConflictPairs=[],
        originalPoolCount=312,remainingPoolCount=len(retained),all44NecessaryGeographicConditionsPass=True,
        restrictionScope='Seed LP branch only. Closed sites remain available to the final full312 free-opening model; passing geographic ceilings is not resource/budget feasibility.')
    path=ROOT/'work/referees/window312-explicit-seed-branch.json'
    with path.open('x',encoding='utf8') as f:json.dump(branch,f,ensure_ascii=False,indent=2);f.write('\n')
    print(json.dumps(dict(branchFile=str(path.relative_to(ROOT)),branchSHA256=SHA(path.read_bytes()),reportSHA256=SHA(report_path.read_bytes()),
        remaining=len(retained),conflicts=len(conflicts),minProvince=report['minProvinceReachablePercent'],
        minDistrict=report['minDistrictReachablePercent'],maximumLost=report['maximumLostFromFull312Residents'],flowEdges=edge_count)))


if __name__=='__main__':main()
