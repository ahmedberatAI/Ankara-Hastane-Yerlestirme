"""Focused sparse-opening objective delta; original annual budget never changes."""
from pathlib import Path
import importlib.util
from types import SimpleNamespace
import sys
import numpy as np
import pytest
HERE=Path(__file__).parent
sys.path.insert(0,str(HERE))
from test_window_lp_conflict_branch_repair import make_all
spec=importlib.util.spec_from_file_location('sparse_opening_repair_work',HERE/'window-lp-sparse-opening-repair.py')
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)


def test_exact_penalty_template_only_original_bill_and_rows_retained():
    f,source=make_all(sites=3,conflicts=((1,2),));mass=np.array([1.,.1,0.]);before=r.signature(f)
    q,_,eligible=r.restrict_templates(f,source,closed=[2],opening_mass=mass)
    assert r.signature(f)==before and eligible.tolist()==[0,1]
    expected=f.c.copy()
    for j,xs in enumerate(f.site_xs):expected[xs]+=.25*np.min(f.c[xs])/(mass[j]+.05)
    np.testing.assert_array_equal(q.model[0],expected)
    np.testing.assert_array_equal(q.model[0][f.nx:],f.c[f.nx:])
    nr=f.model[4].shape[0]
    np.testing.assert_array_equal(q.model[4][:nr].toarray(),f.model[4].toarray())
    for k in (5,6):np.testing.assert_array_equal(q.model[k][:nr],f.model[k])
    np.testing.assert_array_equal(q.model[4][f.budget_row_index].toarray(),f.model[4][f.budget_row_index].toarray())
    assert q.model[6][f.budget_row_index]==f.model[6][f.budget_row_index]
    assert q.material==f.material and q.cost_scale==f.cost_scale
    assert q.cost(f.read_plan(source)[0])==f.cost(f.read_plan(source)[0])
    assert np.all(q.model[3][f.site_xs[2]]==0) and q.model[3][f.nx+2]==0


@pytest.mark.parametrize('mass',[[np.nan,0],[np.inf,0],[-1e-12,0],[1+1e-12,0],[0],None])
def test_invalid_opening_mass_rejected(mass):
    f,source=make_all()
    with pytest.raises(ValueError):r.restrict_templates(f,source,opening_mass=mass)


def test_zero_mass_finite_and_larger_mass_lower_penalty():
    f,_=make_all();c0,rec0=r.sparse_objective(f,np.zeros(f.m));c1,rec1=r.sparse_objective(f,np.ones(f.m))
    assert np.all(np.isfinite(c0))
    for a,b in zip(rec0,rec1):assert a['addedCostScaledPerTemplate']>=b['addedCostScaledPerTemplate']


def test_valid_synthetic_primal_original_cost_separate_from_penalized_objective():
    f,source=make_all(sites=3,conflicts=((1,2),));raw=f.read_plan(source)[0]
    result,vectors,plan=r.repair(f,source,3,closed=[2],opening_mass=np.array([1.,1.,0.]),
        solve=lambda *a:SimpleNamespace(status=0,x=raw,message='synthetic checked primal',nit=0))
    assert result['feasible'] and len(plan['profiles'])==44
    assert result['originalAnnualCostOfContinuousPrimalTRY']==f.cost(raw)
    assert result['penalizedLPObjectiveScaled']>float(f.c@raw)
    assert 'continuousLPObjectiveTRY' not in result
    assert result['minimumAnnualCostLowerBoundTRY'] is None and result['costGap'] is None
    assert not result['provenOptimal'] and not result['nativeIntegerSearchPerformed']
    assert result['heuristicObjective']['alpha']==.25 and not result['heuristicObjective']['representsActualAnnualCost']
    assert not result['heuristicObjective']['canSupportOriginalCostLowerBound']
    np.testing.assert_array_equal(vectors['continuousRelaxationVector'][f.nf:],vectors['roundedOriginalVector'][f.nf:])


@pytest.mark.parametrize('status',[1,2,3,4])
def test_unknown_never_uses_old_source_or_original_cost_bound(status):
    f,source=make_all()
    result,vectors,plan=r.repair(f,source,3,opening_mass=np.ones(f.m),
        solve=lambda *a:SimpleNamespace(status=status,x=None,message='unknown',nit=0))
    assert result['feasible'] is None and plan is None and not vectors
    assert result['minimumAnnualCostLowerBoundTRY'] is None and not result['modelInfeasibilityIndependentlyCertified']


def test_modified_objective_mutation_detected():
    f,source=make_all()
    def mutate(q,*a):q.model[0][0]+=1;return SimpleNamespace(status=1,x=None,message='changed',nit=0)
    with pytest.raises(ValueError,match='changed during repair'):
        r.repair(f,source,3,opening_mass=np.ones(f.m),solve=mutate)


def test_native_tolerances_remain_tighter(monkeypatch):
    f,source=make_all();q,_,_=r.restrict_templates(f,source,opening_mass=np.ones(f.m));calls=[]
    def spy(*a,**kw):calls.append(kw);return SimpleNamespace(status=1,x=None,message='no native',nit=0)
    monkeypatch.setattr(r,'linprog',spy);r.optimize_lp(q,3)
    assert calls[0]['options']['primal_feasibility_tolerance']==1e-9
    assert calls[0]['options']['dual_feasibility_tolerance']==1e-9


def test_rounding_rejects_positive_flow_at_explicitly_closed_site():
    f,source=make_all();raw=f.read_plan(source)[0]
    result,vectors,plan=r.repair(f,source,3,closed=[1],opening_mass=np.ones(f.m),
        solve=lambda *a:SimpleNamespace(status=0,x=raw,message='bad closure',nit=0))
    assert result['feasible'] is None and plan is None and 'rawContinuousSolverVector' in vectors


def test_cleanup_preserves_positive_and_prefix_for_sparse_objective():
    f,source=make_all();raw=f.read_plan(source)[0];zero=np.flatnonzero(raw[f.nf:]==0)[0]+f.nf;raw[zero]=-1e-10
    clean,report=r.correct_tiny_negative_flows(f,raw)
    assert clean[zero]==0 and report['changedFlowCount']==1
    np.testing.assert_array_equal(clean[:f.nf],raw[:f.nf])
    np.testing.assert_array_equal(clean[raw>0],raw[raw>0])
