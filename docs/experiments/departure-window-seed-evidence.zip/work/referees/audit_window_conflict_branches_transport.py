"""Read-only eight-branch reachability audit; no optimizer or router imports."""
from pathlib import Path
from decimal import Decimal
from datetime import datetime, timezone
import hashlib, io, itertools, json
import numpy as np
from pyproj import Transformer

ROOT = Path(__file__).resolve().parents[2]
SHA = lambda b: hashlib.sha256(b).hexdigest()
PAIRS = ((1495, 1618), (1549, 1679), (401, 1823))
PATHS = dict(
    manifest='work/window-routing/full-v1/manifest.json',
    pool='work/referees/window-pool-analysis-v1/geographic_plus32_large-pool.json',
    result='work/window-repair/lp-open273-v2/repair-result.json',
    vectors='work/window-repair/lp-open273-v2/vectors.npz',
    data='data/processed/dataset.json', health='data/processed/health-planning.json')


def main():
    blobs = {k:(ROOT/p).read_bytes() for k,p in PATHS.items()}
    docs = {k:json.loads(b) for k,b in blobs.items() if k!='vectors'}
    manifest, pooldoc, result, data, health = (docs[k] for k in ('manifest','pool','result','data','health'))
    assert SHA(blobs['manifest'])=='29eb7c5a298536ab6a93a998fef1e39ef18a5ea3edd8d9eaf4b78db484bcc7f1'
    assert SHA(blobs['vectors'])==result['vectorSHA256']
    assert result['profileManifestSHA256']==SHA(blobs['manifest'])
    for k in ('data','health'):
        assert SHA(blobs[k])==manifest['sourceSHA256'][PATHS[k]]
    pool=pooldoc['candidateIndices']; assert pool==sorted(set(pool))==result['candidateIndices']
    assert len(pool)==273 and all(j in pool for pair in PAIRS for j in pair)
    population=[Decimal(str(d['population'])) for d in data['demands']]
    total=Decimal(str(data['metadata']['provincePopulation']))
    districts=data['districts']; assert sum(Decimal(str(d['population'])) for d in districts)==total
    drows={d['id']:[i for i,x in enumerate(data['demands']) if x['districtId']==d['id']] for d in districts}
    candidates=data['candidates']; trans=Transformer.from_crs(4326,32636,always_xy=True)
    xy=np.array([trans.transform(c['lon'],c['lat']) for c in candidates])
    pair_records=[]
    for pair in PAIRS:
        a,b=pair; dist=float(np.linalg.norm(xy[a]-xy[b])); radii=sum(candidates[j]['footprintRadiusMeters'] for j in pair)
        assert dist<radii
        pair_records.append(dict(indices=list(pair),ids=[candidates[j]['id'] for j in pair],distanceMeters=dist,sumRadiusMeters=radii))
    area=np.array([t['grossAreaM2'] for t in health['templates']],float)
    available=np.pi*np.array([candidates[j]['footprintRadiusMeters'] for j in pool])**2*health['design']['maxFloors']
    fitting=area[None,:]+health['design']['minimumDoctorsPerSite']*health['design']['areaPerDoctorM2']<=available[:,None]+.001
    nf=int(fitting.sum())+len(pool)
    with np.load(io.BytesIO(blobs['vectors']),allow_pickle=False) as z:raw=z['rawContinuousSolverVector'].copy()
    assert np.isfinite(raw).all()
    branches=[]
    for closed in itertools.product(*PAIRS):
        remaining=[j for j in pool if j not in closed]
        branches.append(dict(closedCandidateIndices=list(closed),retainedFromPairs=[next(j for j in pair if j not in closed) for pair in PAIRS],
            remainingCandidateCount=len(remaining),profiles=[],failedProfiles=[],rawPositiveLoadRemovedAcross44=0.,
            maxRawPositiveLoadRemovedAnyProfile=0.,removedReachableResidentsAcross44=0))
    loads={j:[] for pair in PAIRS for j in pair}; offset=nf
    matrix_hashes={}
    for rec in manifest['matrices']:
        blob=(ROOT/PATHS['manifest']).parent.joinpath(rec['file']).read_bytes(); assert SHA(blob)==rec['sha256']
        matrix_hashes[rec['file']]=SHA(blob)
        with np.load(io.BytesIO(blob),allow_pickle=False) as z:minutes=z['minutes']
        assert minutes.shape==(len(population),4701) and not np.isnan(minutes).any() and (minutes>=0).all()
        legal=np.isfinite(minutes[:,pool])&(minutes[:,pool]<=45)
        base=legal.any(axis=1); base_res=sum(population[i] for i in np.flatnonzero(base))
        oi,sj=np.where(legal); flows=raw[offset:offset+len(oi)]*1000; offset+=len(oi)
        positive=np.maximum(flows,0.) # descriptive positive loads only; no new vector/certificate
        mass=np.bincount(sj,weights=positive,minlength=len(pool))
        for j in loads:loads[j].append(dict(profile=rec['profileId'],positiveLoadResidents=float(mass[pool.index(j)])))
        for branch in branches:
            cols=[k for k,j in enumerate(pool) if j not in branch['closedCandidateIndices']]
            reachable=legal[:,cols].any(axis=1); covered=sum(population[i] for i in np.flatnonzero(reachable))
            local=[]
            for d in districts:
                denom=Decimal(str(d['population'])); cov=sum(population[i] for i in drows[d['id']] if reachable[i])
                local.append(dict(id=d['id'],name=d['name'],population=str(denom),reachableResidents=str(cov),
                    percent=float(cov*100/denom),marginResidents=str(cov-denom*Decimal('.8')),passes=cov>=denom*Decimal('.8')))
            passed=covered>=total*Decimal('.95') and all(d['passes'] for d in local)
            if not passed:branch['failedProfiles'].append(rec['profileId'])
            removed=float(sum(mass[pool.index(j)] for j in branch['closedCandidateIndices']))
            branch['rawPositiveLoadRemovedAcross44']+=removed
            branch['maxRawPositiveLoadRemovedAnyProfile']=max(branch['maxRawPositiveLoadRemovedAnyProfile'],removed)
            branch['removedReachableResidentsAcross44']+=int(base_res-covered)
            branch['profiles'].append(dict(profile=rec['profileId'],provinceReachableResidents=str(covered),
                provincePercent=float(covered*100/total),province95MarginResidents=str(covered-total*Decimal('.95')),
                lostReachableResidents=str(base_res-covered),rawPositiveLoadOnClosedSites=removed,districts=local,passes=passed))
    assert offset==len(raw)
    for branch in branches:
        branch['minProvincePercent']=min(p['provincePercent'] for p in branch['profiles'])
        branch['minDistrictPercent']=min(d['percent'] for p in branch['profiles'] for d in p['districts'])
        branch['all44NecessaryConditionsPass']=not branch['failedProfiles']
    ranking=sorted(branches,key=lambda b:(bool(b['failedProfiles']),-b['minProvincePercent'],-b['minDistrictPercent'],
        b['removedReachableResidentsAcross44'],b['maxRawPositiveLoadRemovedAnyProfile'],b['rawPositiveLoadRemovedAcross44']))
    for rank,branch in enumerate(ranking,1):branch['suggestedResearchPriority']=rank
    assert all((ROOT/p).read_bytes()==blobs[k] for k,p in PATHS.items())
    out=dict(builtAt=datetime.now(timezone.utc).isoformat(),auditCodeLF_SHA256=SHA(Path(__file__).read_bytes().replace(b'\r\n',b'\n')),
        sourceSHA256={PATHS[k]:SHA(b) for k,b in blobs.items()},matrixSHA256=matrix_hashes,
        profileManifestSHA256=SHA(blobs['manifest']),sourceRejectedRawPrimal=True,provincePopulation=str(total),
        unlocatedPopulation=str(total-sum(population)),conflictPairs=pair_records,profileIds=manifest['producedProfileIds'],
        rawPositiveSiteLoads=loads,branches=ranking,routingCalls=0,nativeSolverCalls=0,
        scope='Eight explicit subsets of current273, closing exactly one member per recorded footprint conflict pair. Geographic ceilings relax all capacities, remaining conflicts and cost; complete province/district denominators retained. Ranking uses geography then displacement of positive entries in an already rejected continuous primal, not an accepted plan. Across-profile sums are not unique people. No feasibility/infeasibility of another pool or real city is inferred.')
    path=ROOT/'work/referees/window-conflict-branches-transport.json'
    with path.open('x',encoding='utf8') as f:json.dump(out,f,ensure_ascii=False,indent=2); f.write('\n')
    print(json.dumps(dict(report=str(path.relative_to(ROOT)),sha256=SHA(path.read_bytes()),
        ranking=[{k:b[k] for k in ('suggestedResearchPriority','closedCandidateIndices','failedProfiles','minProvincePercent','minDistrictPercent','maxRawPositiveLoadRemovedAnyProfile','rawPositiveLoadRemovedAcross44','removedReachableResidentsAcross44')} for b in ranking]),ensure_ascii=False))


if __name__=='__main__':main()
