"""No-solver targeted candidate alternatives, capacities, conflicts and clocks."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,io,json,math,sys
import numpy as np
from pyproj import Transformer
ROOT=Path(__file__).resolve().parents[2]
sha=lambda b:hashlib.sha256(b).hexdigest()
paths={k:ROOT/v for k,v in dict(data='data/processed/dataset.json',health='data/processed/health-planning.json',
    source='data/processed/joint-plan.json',pool='work/referees/window-pool-analysis-v1/geographic_plus32_large-pool.json',
    stage='work/window-plans/joint273-v3/seed-preparation/stage-01-cost.json',
    raw='work/window-repair/lp223-v1/vectors.npz',rawaudit='work/referees/lp223-v1-transport-actual-audit.json',
    manifest='work/window-routing/full-v1/manifest.json').items()}
blobs={k:p.read_bytes() for k,p in paths.items()};J={k:json.loads(b) for k,b in blobs.items() if k!='raw'}
D,H,S=J['data'],J['health'],J['source']['scenario'];C=D['candidates'];M=J['manifest'];pool=J['pool']['candidateIndices'];poolset=set(pool)
assert sha(blobs['manifest'])=='29eb7c5a298536ab6a93a998fef1e39ef18a5ea3edd8d9eaf4b78db484bcc7f1'
assert sha(blobs['data'])==M['sourceSHA256']['data/processed/dataset.json']
assert sha(blobs['health'])==M['sourceSHA256']['data/processed/health-planning.json']
assert sha(blobs['raw'])==J['rawaudit']['vectorsSHA256']
selected=sorted(x['candidateIndex'] for x in J['stage']['costResult']['selected']);selectedset=set(selected)
pop=np.array([d['population'] for d in D['demands']],float);dd=np.array([d['districtId'] for d in D['demands']]);total=D['metadata']['provincePopulation']
T=Transformer.from_crs(4326,32636,always_xy=True);xy=np.array([T.transform(c['lon'],c['lat']) for c in C]);rad=np.array([c['footprintRadiusMeters'] for c in C],float)
available=np.pi*rad**2*H['design']['maxFloors'];area=np.array([t['grossAreaM2'] for t in H['templates']],float);beds=np.array([t['beds'] for t in H['templates']],float)
contact=H['rates']['contactsPerResident']*S['demandMultiplier'];bedrate=H['rates']['bedDaysPerResident']*S['demandMultiplier'];q=S['contactsPerDoctor']/contact;bedcap=beds*365*S['bedOccupancy']/100/bedrate
min_docs=H['design']['minimumDoctorsPerSite'];da=H['design']['areaPerDoctorM2'];target=total*S['coverageTarget']/100
docub=np.minimum(np.maximum(0,np.floor(np.nextafter((available+.001-area.min())/da,np.inf))),max(min_docs,math.ceil(target*contact/S['contactsPerDoctor'])))
capacities=[];besttypes=[]
for j in range(len(C)):
    opts=[]
    for t in range(len(area)):
        docs=math.floor(min(math.nextafter((available[j]+.001-area[t])/da,math.inf),docub[j]))
        if docs>=min_docs:opts.append((min(bedcap[t],docs*q),int(t),int(docs)))
    cap,t,docs=max(opts,default=(0.,-1,0));capacities.append(cap);besttypes.append((t,docs))
capacities=np.array(capacities)
def info(j):
    t,docs=besttypes[j]
    return dict(candidateIndex=int(j),id=C[j]['id'],name=C[j]['name'],districtId=C[j]['districtId'],
        radiusMeters=float(rad[j]),accessMeters=C[j]['accessMeters'],roadNode=C[j]['node'],
        capacityUpperResidents=float(capacities[j]),capacityTemplateId=None if t<0 else H['templates'][t]['id'],
        capacityDoctors=docs,inCurrent273=j in poolset,inCurrent223=j in selectedset)
critical={r['candidateIndex']:r for r in J['rawaudit']['integerFitFailures']}
alternatives={};stats={}
for original,r in critical.items():
    distances=np.linalg.norm(xy-xy[original],axis=1)
    choices=np.flatnonzero((distances<=2500)&(capacities>=r['maximumAssignedResidents'])&(np.arange(len(C))!=original))
    # Include same-family larger options explicitly even if the geometry moved.
    base=C[original].get('baseCandidateIndex',original)
    family=[j for j,c in enumerate(C) if c.get('baseCandidateIndex',j)==base and capacities[j]>capacities[original]]
    choices=sorted(set(choices.tolist()+family))
    rows=[]
    for j in choices:
        conflicts=[k for k in selected if k not in (original,j) and np.linalg.norm(xy[j]-xy[k])<rad[j]+rad[k]]
        row=info(j);row.update(distanceMeters=float(distances[j]),sourceFamily=C[j].get('baseCandidateIndex',j)==base,
            conflictingOtherSourceIndices=conflicts,conflictingOtherSourceCount=len(conflicts))
        rows.append(row);stats[(original,j)]=dict(totalFlow=0.,retainedFlow=0.,profileRetention=[])
    alternatives[original]=rows
weak_ids=['1473','1658','1539','1227','1924','1365','1427','1387']
districts={d['id']:d for d in D['districts']};gains={k:[] for k in weak_ids};basecovered={k:[] for k in weak_ids};province_gains=[];province_base=[]
eligible=area[None,:]+min_docs*da<=available[pool,None]+.001;nf=int(eligible.sum())+len(pool);offset=nf
with np.load(io.BytesIO(blobs['raw']),allow_pickle=False) as z:raw=z['continuousRelaxationVector'].copy()
profile_ids=[]
for rec in M['matrices']:
    b=(paths['manifest'].parent/rec['file']).read_bytes();assert sha(b)==rec['sha256']
    with np.load(io.BytesIO(b),allow_pickle=False) as z:times=z['minutes']
    legal=np.isfinite(times)&(times<=45);reachable=legal[:,pool].any(axis=1);profile_ids.append(rec['profileId'])
    province_base.append(float(pop[reachable].sum()));province_gains.append(pop[~reachable]@legal[~reachable])
    for k in weak_ids:
        mask=(dd==k)&~reachable;basecovered[k].append(float(pop[(dd==k)&reachable].sum()));gains[k].append(pop[mask]@legal[mask])
    oi,sj=np.where(legal[:,pool]);f=raw[offset:offset+len(oi)]*1000;offset+=len(oi)
    for original,rows in alternatives.items():
        local=pool.index(original);mask=sj==local;weights=np.bincount(oi[mask],weights=f[mask],minlength=len(pop));mass=float(weights.sum())
        for row in rows:
            j=row['candidateIndex'];kept=float(weights[legal[:,j]].sum());st=stats[(original,j)]
            st['totalFlow']+=mass;st['retainedFlow']+=kept
            if mass>0:st['profileRetention'].append((kept/mass,rec['profileId']))
assert offset==len(raw)
critical_results=[];shortlist=set()
for original,rows in alternatives.items():
    for row in rows:
        st=stats[(original,row['candidateIndex'])];row['retainedRawFlowAcross44Percent']=100*st['retainedFlow']/st['totalFlow']
        worst,name=min(st['profileRetention']);row.update(worstRawFlowRetentionPercent=100*worst,worstRawFlowRetentionProfile=name)
    ordered=sorted(rows,key=lambda x:(x['conflictingOtherSourceCount']>0,-x['worstRawFlowRetentionPercent'],-x['retainedRawFlowAcross44Percent'],x['conflictingOtherSourceCount'],x['distanceMeters']))
    new=[r for r in ordered if not r['inCurrent273']][:3];shortlist.update(r['candidateIndex'] for r in new)
    critical_results.append(dict(source=info(original),rawMaximumProfileLoad=critical[original]['maximumAssignedResidents'],
        sourceProfileAtMaximum=critical[original]['profileAtMaximum'],nearbyAdequateCandidateCount=len(rows),
        bestCurrent273=[r for r in ordered if r['inCurrent273']][:3],newCandidateSuggestions=new,allAlternatives=ordered))
geo=[]
for k in weak_ids:
    g=np.array(gains[k]);base=np.array(basecovered[k]);den=districts[k]['population']
    minima=(base[:,None]+g).min(axis=0);ranking=np.argsort(-minima,kind='stable')
    suggestions=[]
    for j in ranking:
        if j in poolset or minima[j]<=base.min():continue
        r=info(int(j));r.update(currentWorstReachableResidents=float(base.min()),newWorstReachableResidents=float(minima[j]),
            minimumExtraResidentsAcross44=float(g[:,j].min()),worstCoveragePercent=float(minima[j]*100/den),
            conflictingSourceIndices=[i for i in selected if np.linalg.norm(xy[j]-xy[i])<rad[j]+rad[i]])
        suggestions.append(r)
        if len(suggestions)==2:break
    geo.append(dict(districtId=k,name=districts[k]['name'],population=den,currentWorstPercent=float(base.min()*100/den),
        marginOver80Residents=float(base.min()-.8*den),suggestions=suggestions))
    shortlist.update(r['candidateIndex'] for r in suggestions)
pg=np.array(province_gains);pb=np.array(province_base);pmin=(pb[:,None]+pg).min(axis=0);province_suggestions=[]
for j in np.argsort(-pmin,kind='stable'):
    if j in poolset or pmin[j]<=pb.min():continue
    r=info(int(j));r.update(currentWorstProvinceResidents=float(pb.min()),newWorstProvinceResidents=float(pmin[j]),
        saturday0956AddedResidents=float(pg[profile_ids.index('saturday-0956'),j]),
        worstCoveragePercent=float(100*pmin[j]/total),
        conflictingSourceIndices=[i for i in selected if np.linalg.norm(xy[j]-xy[i])<rad[j]+rad[i]])
    province_suggestions.append(r)
    if len(province_suggestions)==8:break
shortlist.update(r['candidateIndex'] for r in province_suggestions)
expanded=sorted(poolset|shortlist);extra=sorted(shortlist-poolset)
flow_old=0;flow_new=0;expanded_province=[];expanded_district={k:[] for k in districts}
for rec in M['matrices']:
    b=(paths['manifest'].parent/rec['file']).read_bytes();assert sha(b)==rec['sha256']
    with np.load(io.BytesIO(b),allow_pickle=False) as z:times=z['minutes']
    legal=np.isfinite(times)&(times<=45);flow_old+=int(legal[:,pool].sum());flow_new+=int(legal[:,expanded].sum())
    reach=legal[:,expanded].any(axis=1);expanded_province.append(float(pop[reach].sum()*100/total))
    for k,d in districts.items():expanded_district[k].append(float(pop[(dd==k)&reach].sum()*100/d['population']))
new_conflicts=[]
for a,j in enumerate(expanded):
    for k in expanded[:a]:
        if (j in shortlist or k in shortlist) and np.linalg.norm(xy[j]-xy[k])<rad[j]+rad[k]:new_conflicts.append([k,j])
assert all(p.read_bytes()==blobs[k] for k,p in paths.items())
out=dict(builtAt=datetime.now(timezone.utc).isoformat(),auditCodeLF_SHA256=sha(Path(__file__).read_bytes().replace(b'\r\n',b'\n')),
    sourceSHA256={str(paths[k].relative_to(ROOT)):sha(b) for k,b in blobs.items()},profileIds=profile_ids,
    currentPoolCount=len(pool),sourceSelectedCount=len(selected),criticalCapacityAlternatives=critical_results,
    weakDistrictGeographicAlternatives=geo,provinceGeographicAlternatives=province_suggestions,
    suggestedAdditionalCandidateIndices=sorted(shortlist),
    proposedNestedPoolCount=len(poolset|shortlist),newCandidateConflictPairs=new_conflicts,
    originalPoolFlowEdgeCountAcross44=flow_old,expandedPoolFlowEdgeCountAcross44=flow_new,
    addedFlowEdgeCountAcross44=flow_new-flow_old,expandedGeographicMinimumProvincePercent=min(expanded_province),
    expandedGeographicMinimumDistrictPercent=min(min(x) for x in expanded_district.values()),
    expandedDistrictMinimumPercent={k:min(x) for k,x in expanded_district.items()},nativeSolverCalls=0,routingCalls=0,
    scope='Exploratory candidate ranking only. Capacity uses the best individually fitting integer type/doctor pair, without common budget or inter-site conflicts. Retention is of the prior rejected continuous assignments, not a feasible reassignment or travel improvement. A replacement may require closing conflicting source sites. Geographic gains are capacity-free union ceilings; adding a candidate does not force its opening. No feasibility or minimal-count claim.')
p=ROOT/'work/referees/window-targeted-candidate-alternatives-v2.json';assert not p.exists();p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
pool_output=ROOT/'work/referees/window-targeted-expansion-pool-v2.json';assert not pool_output.exists()
pool_doc=dict(format=1,candidateIndices=sorted(poolset|shortlist),
    method='Research pool: original273 plus targeted integer-capacity alternatives within2.5km, weak-district union-coverage candidates and province worst-clock union-coverage candidates. No feasibility claim; sites remain optional.',
    sourceSHA256=J['pool']['sourceSHA256'],profileManifestSHA256=sha(blobs['manifest']))
pool_output.write_text(json.dumps(pool_doc,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps(dict(report=str(p.relative_to(ROOT)),sha256=sha(p.read_bytes()),additionalIndices=out['suggestedAdditionalCandidateIndices'],nestedPool=out['proposedNestedPoolCount'],critical=[dict(source=x['source']['candidateIndex'],existing=[r['candidateIndex'] for r in x['bestCurrent273']],new=[r['candidateIndex'] for r in x['newCandidateSuggestions']]) for x in critical_results]),ensure_ascii=False))
