"""Independent read-only full44 repair and canonical4 projection evidence gate.

No optimizer/model builder is imported. Native search and optimality are not
replayed; the final allocations/resources and archived byte identities are.
"""
import argparse
from copy import deepcopy
import io
import json
import math
from pathlib import Path
import sys

import numpy as np

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from scripts import audit_window_plan as a

FIELDS=('selected','profiles','hospitalCount','totalBeds','totalDoctors',
        'annualEquivalentCostTRY','annualMaterialCostTRY','annualFixedResourceCostTRY')
CANONICAL=tuple(a.BASE_PROFILES)
SCOPE='Only the fixed source template choices, supplied candidate pool, and all 44 named profiles; not an unrestricted location/template optimum.'
STAGE='work/window-plans/joint273-v3/seed-preparation/stage-01-cost.json'
POOL='work/referees/window-pool-analysis-v1/geographic_plus32_large-pool.json'
SCRIPT='work/referees/window-resource-repair.py'
UPGRADE_SCRIPT='work/referees/window-bed-upgrade-repair.py'
UPGRADE_SCOPE='Only mandatory source locations with same-or-larger beds, optional remaining pool sites, and all 44 named profiles; not an unrestricted location/template optimum.'
UPGRADE_METHOD='Canonical four-profile primal projection of a new all-44 mandatory-source-location, same-or-larger-bed and optional-extra-site repair with free integer physicians. No separate four-profile native search; no unrestricted optimality claim.'
LP_SCRIPT='work/referees/window-lp-round-repair.py'
LP_SCOPE='Feasible integer seed only at the same source locations after continuous resource LP and explicit rounding; no integer-native optimality or unrestricted lower-bound claim.'
LP_METHOD='Canonical four-profile primal projection of a new all-44 continuous resource LP followed by validated integer resource rounding at the same source locations. No separate four-profile native search; no unrestricted optimality claim.'
ENVELOPE_SCRIPT='work/referees/window-lp-envelope-repair.py'
ENVELOPE_SCOPE='Feasible integer seed only at source locations after capacity-envelope continuous LP and rounding; the inward capacity margin is a seed restriction, not a general infeasibility or optimum claim.'
ENVELOPE_METHOD='Canonical four-profile primal projection of a new all-44 capacity-envelope continuous resource LP followed by validated integer resource rounding at the same source locations. No separate four-profile native search; no unrestricted optimality claim.'
OPEN_POOL_SCRIPT='work/referees/window-lp-open-pool-repair.py'
OPEN_POOL_SCOPE='Feasible integer seed only within the supplied full candidate pool with free opening/closing, after opening-coupled capacity-envelope LP and rounding; the inward margin is a seed restriction, not general infeasibility or optimality proof.'
OPEN_POOL_METHOD='Canonical four-profile primal projection of a new all-44 capacity-envelope continuous resource LP followed by validated integer resource rounding with opening and closing allowed throughout the supplied candidate pool. No separate four-profile native search; no unrestricted optimality claim.'
CORRECTED_SCRIPT='work/referees/window-lp-open-pool-repair-v2.py'
CORRECTED_METHOD='Canonical four-profile primal projection of a new all-44 capacity-envelope continuous resource LP, explicitly bounded tiny-negative-flow correction and validated integer resource rounding with opening and closing allowed throughout the supplied candidate pool. No separate four-profile native search; no unrestricted optimality claim.'
BRANCH_SCRIPT='work/referees/window-lp-conflict-branch-repair.py'
BRANCH_SCOPE='Feasible integer seed only within an explicitly closed-candidate branch of the supplied pool; all remaining locations may open or close. Opening-coupled capacity-envelope LP and rounding retain the hard original budget and all 44 targets. Branch closures and inward margins are seed restrictions, never general infeasibility or original optimality proof.'
BRANCH_METHOD='Canonical four-profile primal projection of a new all-44 capacity-envelope continuous resource LP in the explicitly closed-candidate branch recorded by its research report, bounded tiny-negative-flow correction and validated integer resource rounding. Remaining supplied locations may open or close. No separate four-profile native search or unrestricted optimality claim.'
SPARSE_SCRIPT='work/referees/window-lp-sparse-opening-repair.py'
SPARSE_SCOPE='Heuristic sparse-opening LP seed only in the declared closed-candidate branch. The penalized objective is not actual annual cost or a cost lower bound. All original annual-cost budget/44-target rows remain, then integer/primal/Decimal audit decides. No general infeasibility or optimality claim.'
SPARSE_METHOD='Canonical four-profile primal projection of a new all-44 heuristic sparse-opening capacity-envelope continuous resource LP in the explicitly closed-candidate branch recorded by its research report, bounded tiny-negative-flow correction and validated integer resource rounding. Remaining supplied locations may open or close. No separate four-profile native search or unrestricted optimality claim.'
WEIGHT_REPORT='work/window-repair/lp-branch273-v1/repair-result.json'
WEIGHT_VECTORS='work/window-repair/lp-branch273-v1/vectors.npz'
STRONG_SCRIPT='work/referees/window-lp-sparse-opening-strong-repair.py'
STRONG_METHOD='Canonical four-profile primal projection of a new all-44 heuristic sparse-opening capacity-envelope continuous resource LP in the explicitly closed-candidate branch recorded by its research report, explicit bounded two-sided tiny-flow snapping and validated integer resource rounding. Remaining supplied locations may open or close. No separate four-profile native search or unrestricted optimality claim.'
STRONG_WEIGHT_REPORT='work/window-repair/lp-sparse273-v1/repair-result.json'
STRONG_WEIGHT_VECTORS='work/window-repair/lp-sparse273-v1/vectors.npz'
EXPANDED_SCRIPT='work/referees/window-lp-expanded312-repair.py'
EXPANDED_POOL='work/referees/window-targeted-expansion-pool-v2.json'
EXPANDED_BRANCH='work/referees/window312-explicit-seed-branch.json'
EXPANDED_SCOPE='Heuristic sparse-opening LP seed only in the expanded pool and declared closed-candidate branch. The penalized objective is not actual annual cost or a cost lower bound. All original annual-cost budget/44-target rows remain, then integer/primal/Decimal audit decides. No general infeasibility or optimality claim.'
EXPANDED_WEIGHT_REPORT='work/window-repair/lp-sparse-strong273-v1/repair-result.json'
EXPANDED_WEIGHT_VECTORS='work/window-repair/lp-sparse-strong273-v1/vectors.npz'


def template_scope(mode,source,chosen,inputs,pool):
    """Independently reconstruct the fixed binary columns; physicians stay free."""
    a.check(mode in ('fixed-all','fixed-core'),'Unsupported repair restriction mode')
    fields=('candidateIndex','id','templateId','beds','footprintRadiusMeters')
    fixed={s['candidateIndex']:{k:s[k] for k in fields} for s in source}
    actual={s['candidateIndex']:{k:s[k] for k in fields} for s in chosen}
    a.check(len(fixed)==len(source) and len(actual)==len(chosen),'Duplicate fixed/selected source site')
    a.check(set(fixed)<=set(actual),'Repair removed a fixed source site')
    a.check(all(a.digest(v)==a.digest(actual[k]) for k,v in fixed.items()),'Repair changed fixed location/template/bed decisions')
    if mode=='fixed-all':a.check(set(actual)==set(fixed),'Fixed-all repair opened a new site')
    health=inputs['health'];data=inputs['data']
    available=np.array([math.pi*data['candidates'][g]['footprintRadiusMeters']**2*health['design']['maxFloors'] for g in pool])
    areas=np.array([t['grossAreaM2'] for t in health['templates']])
    eligible=areas[None,:]+health['design']['minimumDoctorsPerSite']*health['design']['areaPerDoctorM2']<=available[:,None]+.001
    sites,_=np.where(eligible)
    return [k for k,local in enumerate(sites) if mode=='fixed-all' or pool[int(local)] in fixed]


def upgrade_scope(source,chosen,inputs,pool):
    """Check mandatory original locations and independently reconstruct smaller modules."""
    fixed={s['candidateIndex']:s for s in source};actual={s['candidateIndex']:s for s in chosen}
    a.check(len(fixed)==len(source) and len(actual)==len(chosen),'Duplicate upgrade location')
    a.check(set(fixed)<=set(actual),'Upgrade removed a mandatory source location')
    for j,s in fixed.items():
        a.check(all(a.digest(s[k])==a.digest(actual[j][k]) for k in ('candidateIndex','id','footprintRadiusMeters')),
            'Upgrade changed mandatory source location')
        a.check(a.D(actual[j]['beds'])>=a.D(s['beds']),'Upgrade decreased source bed count')
    h=inputs['health'];d=inputs['data'];templates=h['templates']
    available=np.array([math.pi*d['candidates'][g]['footprintRadiusMeters']**2*h['design']['maxFloors'] for g in pool])
    areas=np.array([t['grossAreaM2'] for t in templates])
    eligible=areas[None,:]+h['design']['minimumDoctorsPerSite']*h['design']['areaPerDoctorM2']<=available[:,None]+.001
    sites,types=np.where(eligible);mandatory=[j for j,g in enumerate(pool) if g in fixed]
    forbidden=[k for j in mandatory for k,(s,t) in enumerate(zip(sites,types))
        if s==j and templates[int(t)]['beds']<fixed[pool[j]]['beds']]
    return dict(mandatoryLocalIndices=mandatory,mandatoryCandidateIndices=[pool[j] for j in mandatory],
        minimumBeds=[fixed[pool[j]]['beds'] for j in mandatory],smallerTemplateIndices=forbidden)


def location_scope(source,chosen):
    fields=('candidateIndex','id','footprintRadiusMeters')
    original={s['candidateIndex']:{k:s[k] for k in fields} for s in source}
    final={s['candidateIndex']:{k:s[k] for k in fields} for s in chosen}
    a.check(len(original)==len(source) and len(final)==len(chosen) and a.digest(original)==a.digest(final),
        'LP rounding changed the exact source location set or footprints')


def verify_rounding_links(raw,rounded,final,shared_prefix):
    for value in (raw,rounded,final):
        a.check(value.dtype.kind=='f' and value.ndim==1 and value.shape==final.shape
            and np.all(np.isfinite(value)) and np.all(value[shared_prefix:]>=0),'Invalid LP-round vector')
    a.check(np.array_equal(raw[shared_prefix:],rounded[shared_prefix:]),'LP rounding changed an assignment')
    a.check(np.array_equal(rounded[:shared_prefix],final[:shared_prefix])
        and np.array_equal(final[:shared_prefix],np.rint(final[:shared_prefix])),
        'LP JSON serialization changed rounded integer resources')
    a.check(np.all(np.abs(rounded-final)<=2*np.spacing(np.maximum(np.abs(rounded),np.abs(final)))),
        'LP JSON serialization changed flows beyond two ULPs')


def wire_flow_slices(inputs,pool):
    """Reconstruct ordered flow slices directly from eligible modules and matrices."""
    data,h=inputs['data'],inputs['health']
    areas=np.array([t['grossAreaM2'] for t in h['templates']],dtype=float)
    available=np.array([math.pi*data['candidates'][j]['footprintRadiusMeters']**2*h['design']['maxFloors'] for j in pool])
    eligible=areas[None,:]+h['design']['minimumDoctorsPerSite']*h['design']['areaPerDoctorM2']<=available[:,None]+.001
    nf=int(eligible.sum())+len(pool);offset=nf;slices=[]
    for profile in a.expected_profiles():
        matrix=inputs['matrices'][profile['id']][:,pool]
        count=int((np.isfinite(matrix)&(matrix<=45)).sum())
        slices.append((profile['id'],offset,offset+count));offset+=count
    return nf,slices,offset


def verify_flow_correction(raw,clean,record,shared_prefix,slices,validated,threshold=1e-10):
    """Verify only the declared bounded correction; no producer cleanup is called."""
    size=slices[-1][2] if slices else shared_prefix
    for value in (raw,clean):
        a.check(value.dtype.kind=='f' and value.shape==(size,) and np.all(np.isfinite(value)),
            'Invalid numerical-correction vector')
    flow=raw[shared_prefix:];negative=flow<0
    a.check(type(threshold) is float and threshold in (1e-10,1e-9),'Unsupported reviewed numerical threshold')
    a.check(np.all(flow>=-threshold),'Numerical correction exceeds its negative threshold')
    expected=raw.copy();expected[shared_prefix:][negative]=0.
    a.check(np.array_equal(clean,expected),'Correction changed more than permitted negative entries')
    a.keys(record,('allowedNegativeThresholdThousandResidents','changedFlowCount','maximumCorrectionResidents',
        'totalCorrectionResidents','positiveFlowEntriesPreserved','resourcePrefixPreserved','rawFlowEntriesPreserved',
        'originalRelaxedConstraintsRevalidated','mostNegativeRawFlowThousandResidents',
        'totalIsSumAcrossProfilesNotUniqueResidents','profiles'),'numerical correction')
    a.check(a.D(record['allowedNegativeThresholdThousandResidents'])==a.D(threshold),'Negative threshold changed')
    a.check(type(record['changedFlowCount']) is int and record['changedFlowCount']==int(negative.sum()),'Correction count differs')
    for field,wanted in dict(positiveFlowEntriesPreserved=True,resourcePrefixPreserved=True,
        rawFlowEntriesPreserved=not bool(negative.any()),originalRelaxedConstraintsRevalidated=validated,
        totalIsSumAcrossProfilesNotUniqueResidents=True).items():
        a.check(record[field] is wanted,'Numerical correction claim differs: '+field)
    changes=[-float(v)*1000 for v in flow[negative]]
    for field,value in dict(maximumCorrectionResidents=max(changes,default=0.),
        totalCorrectionResidents=math.fsum(changes)).items():
        a.near(record[field],value,'1e-18','numerical correction '+field)
    most_negative=record['mostNegativeRawFlowThousandResidents']
    a.check(type(most_negative) in (int,float) and math.isfinite(most_negative)
        and a.D(most_negative)==a.D(min(0.,float(flow.min(initial=0.)))),'Raw minimum correction differs')
    a.check(len(record['profiles'])==len(slices),'Correction profile count differs')
    for row,(name,start,end) in zip(record['profiles'],slices):
        a.keys(row,('profile','changedFlowCount','totalCorrectionResidents','maximumCorrectionResidents'),'profile correction')
        values=[-float(v)*1000 for v in raw[start:end] if v<0]
        a.check(row['profile']==name and type(row['changedFlowCount']) is int and row['changedFlowCount']==len(values),
            'Correction profile identity/count differs')
        a.near(row['totalCorrectionResidents'],math.fsum(values),'1e-18','profile correction total')
        a.near(row['maximumCorrectionResidents'],max(values,default=0.),'1e-18','profile correction maximum')
    return dict(changedFlowCount=int(negative.sum()),totalCorrectionResidents=math.fsum(changes),
        maximumCorrectionResidents=max(changes,default=0.),mostNegativeRawFlowThousandResidents=min(0.,float(flow.min(initial=0.))),
        rawFlowEntriesPreserved=not bool(negative.any()),positiveEntriesAndResourcePrefixExactlyPreserved=True,
        totalIsSumAcrossProfilesNotUniqueResidents=True)


def verify_branch_closures(closed,pool,result,freeze,selected=None):
    a.check(isinstance(closed,list) and all(type(j) is int for j in closed)
        and closed==sorted(set(closed)) and set(closed)<=set(pool),'Invalid closed branch identities')
    a.check(a.digest(result['closedCandidateIndices'])==a.digest(closed)
        and a.digest(freeze['closedCandidateIndices'])==a.digest(closed),'Closed branch binding differs')
    a.check(result['branchRestrictionRemovedForFinalFullSearch'] is True,'Final unrestricted search requirement differs')
    for field in ('nativePrimalFeasibilityTolerance','nativeDualFeasibilityTolerance'):
        a.check(type(result[field]) is float and result[field]==1e-9,'Native numerical policy differs')
    if selected is not None:
        a.check(not set(closed)&{s['candidateIndex'] for s in selected},'Final seed reopens a closed branch candidate')


def verify_signed_flow_snap(raw,clean,record,shared_prefix,slices,validated):
    size=slices[-1][2] if slices else shared_prefix
    for value in (raw,clean):
        a.check(value.dtype.kind=='f' and value.shape==(size,) and np.all(np.isfinite(value)),'Invalid signed-snap vector')
    f=raw[shared_prefix:];changed=(f!=0)&(np.abs(f)<=1e-9)
    a.check(np.all(f>=-1e-9),'Significant negative exceeds signed-snap threshold')
    expected=raw.copy();expected[shared_prefix:][changed]=0
    a.check(np.array_equal(expected,clean),'Signed snap changed remaining flows or resources')
    def stats(values):
        delta=[-float(v)*1000 for v in values if v!=0 and abs(v)<=1e-9]
        removed=[-x for x in delta if x<0];added=[x for x in delta if x>0]
        return dict(changedFlowCount=len(delta),negativeChangedFlowCount=len(added),positiveChangedFlowCount=len(removed),
            positiveRemovedTotalResidents=math.fsum(removed),negativeAddedTotalResidents=math.fsum(added),
            positiveRemovedMaximumResidents=max(removed,default=0.),negativeAddedMaximumResidents=max(added,default=0.),
            totalCorrectionResidents=math.fsum(abs(x) for x in delta),totalSignedCorrectionResidents=math.fsum(delta),
            maximumCorrectionResidents=max((abs(x) for x in delta),default=0.))
    overall=stats(f)
    flags=dict(positiveFlowEntriesPreserved=overall['positiveChangedFlowCount']==0,
        allRemainingPositiveFlowEntriesPreserved=True,resourcePrefixPreserved=True,
        rawFlowEntriesPreserved=overall['changedFlowCount']==0,originalRelaxedConstraintsRevalidated=validated,
        totalIsSumAcrossProfilesNotUniqueResidents=True)
    a.keys(record,(*overall,*flags,'allowedNegativeThresholdThousandResidents','allowedAbsoluteSnapThresholdThousandResidents',
        'flowSnapPolicy','mostNegativeRawFlowThousandResidents','profiles'),'signed snap')
    for key in ('allowedNegativeThresholdThousandResidents','allowedAbsoluteSnapThresholdThousandResidents'):
        a.check(type(record[key]) is float and record[key]==1e-9,'Signed-snap threshold changed')
    a.check(record['flowSnapPolicy']=='Nonzero flow with absolute value at most threshold becomes zero; original target and all validation tolerances unchanged',
        'Signed-snap policy differs')
    for key,value in flags.items():a.check(record[key] is value,'Signed-snap preservation claim differs: '+key)
    def check_stats(row,wanted):
        for key,value in wanted.items():
            if key.endswith('Count'):a.check(type(row[key]) is int and row[key]==value,'Signed-snap count differs')
            else:a.check(type(row[key]) in (int,float) and math.isfinite(row[key])
                and abs(a.D(row[key])-a.D(value))<=a.D('1e-18'),'Signed-snap mass differs: '+key)
    check_stats(record,overall)
    a.check(type(record['mostNegativeRawFlowThousandResidents']) in (int,float)
        and a.D(record['mostNegativeRawFlowThousandResidents'])==a.D(float(f.min(initial=0.))),'Signed-snap raw minimum differs')
    a.check(len(record['profiles'])==len(slices),'Signed-snap profile count differs')
    for row,(name,start,end) in zip(record['profiles'],slices):
        wanted=stats(raw[start:end]);a.keys(row,('profile',*wanted),'signed profile snap')
        a.check(row['profile']==name,'Signed-snap profile order differs');check_stats(row,wanted)
    return dict(overall,rawFlowEntriesPreserved=overall['changedFlowCount']==0,
        positiveFlowEntriesPreserved=overall['positiveChangedFlowCount']==0,
        remainingPositiveEntriesAndResourcePrefixExactlyPreserved=True,totalIsSumAcrossProfilesNotUniqueResidents=True)


def verify_sparse_weights(report,result,freeze,references,inputs,current_vectors,strong=False,expanded=False):
    """Rebuild heuristic coefficients from source bytes; original bill stays separate."""
    pool=report['candidateIndices'];source=report['openingWeightSource'];objective=result['heuristicObjective']
    source_report=EXPANDED_WEIGHT_REPORT if expanded else STRONG_WEIGHT_REPORT if strong else WEIGHT_REPORT
    source_vectors=EXPANDED_WEIGHT_VECTORS if expanded else STRONG_WEIGHT_VECTORS if strong else WEIGHT_VECTORS
    alpha,offset=(2.,.005) if strong else (.25,.05)
    source_keys=('report','reportSHA256','vectors','vectorsSHA256','rawOpeningMass','usedOpeningMass',
        'numericalMassClampOnlyForHeuristicWeights')
    if expanded:source_keys+=('sourceCandidateIndices','newlyInitializedCandidateIndices','newCandidateInitialization')
    a.keys(source,source_keys,'opening weights source')
    a.check(source['report']==source_report and source['vectors']==source_vectors
        and source['reportSHA256']==a.sha256(references[source_report])
        and source['vectorsSHA256']==a.sha256(references[source_vectors])
        and source['numericalMassClampOnlyForHeuristicWeights'] is True,'Opening weight raw identity differs')
    prior=a.load_json(references[source_report])
    for field in (('profileManifestSHA256','sourceSHA256','modelCodeSHA256') if expanded else
                  ('candidateIndices','closedCandidateIndices','profileManifestSHA256','sourceSHA256','modelCodeSHA256')):
        a.check(a.digest(prior[field])==a.digest(report[field]),'Weight source scope differs: '+field)
    a.check(prior['vectorSHA256']==source['vectorsSHA256'],'Weight report/vector link differs')
    a.check(freeze['sparseOpeningAlpha']==alpha and freeze['openingMassOffset']==offset,'Sparse frozen controls differ')
    a.keys(objective,('kind','alpha','openingMassOffset','calibratedClinicalParameter','representsActualAnnualCost',
        'canSupportOriginalCostLowerBound','originalBudgetRowUnchanged','originalPhysicianCoefficientsUnchanged','siteWeights'),
        'heuristic objective')
    a.check(objective['kind']=='reweighted_opening_L1' and objective['alpha']==alpha and objective['openingMassOffset']==offset,
        'Sparse heuristic parameters differ')
    for key,wanted in dict(calibratedClinicalParameter=False,representsActualAnnualCost=False,
        canSupportOriginalCostLowerBound=False,originalBudgetRowUnchanged=True,originalPhysicianCoefficientsUnchanged=True).items():
        a.check(objective[key] is wanted,'Sparse objective overclaim: '+key)
    a.check(result['nativeOptimalityScope']=='Penalized continuous branch LP only; never original annual-cost or integer optimum'
        and 'continuousLPObjectiveTRY' not in result,'Ambiguous original objective claim')
    h=inputs['health'];d=inputs['data'];s=inputs['source_cost_certificate']['scenario'];eco=h['economics'];design=h['design']
    areas=np.array([t['grossAreaM2'] for t in h['templates']],dtype=float)
    beds=np.array([t['beds'] for t in h['templates']],dtype=float)
    available=np.array([math.pi*d['candidates'][g]['footprintRadiusMeters']**2*design['maxFloors'] for g in pool])
    si,ti=np.where(areas[None,:]+design['minimumDoctorsPerSite']*design['areaPerDoctorM2']<=available[:,None]+.001)
    nf,slices,size=wire_flow_slices(inputs,pool);nx=len(si)
    with np.load(io.BytesIO(references[source_vectors]),allow_pickle=False) as arrays:
        raw=arrays['rawContinuousSolverVector']
    old_pool=prior['candidateIndices'] if expanded else pool
    if expanded:
        old_doc=a.load_json(references[POOL]);a.check(old_pool==old_doc['candidateIndices']
            and source['sourceCandidateIndices']==old_pool and set(old_pool)<=set(pool)
            and prior['closedCandidateIndices']==[401,1495,1679],'Historical weight pool/branch differs')
        _,_,source_size=wire_flow_slices(inputs,old_pool)
        old_available=np.array([math.pi*d['candidates'][g]['footprintRadiusMeters']**2*design['maxFloors'] for g in old_pool])
        old_si,_=np.where(areas[None,:]+design['minimumDoctorsPerSite']*design['areaPerDoctorM2']<=old_available[:,None]+.001)
    else:source_size=size;old_si=si
    a.check(raw.dtype.kind=='f' and raw.shape==(source_size,) and np.all(np.isfinite(raw)),'Invalid raw weight-source vector')
    masses=np.array([raw[np.flatnonzero(old_si==j)].sum() for j in range(len(old_pool))])
    a.check(np.all(masses>=-1e-7) and np.all(masses<=1+1e-7),'Weight source masses exceed row tolerance')
    if expanded:
        by_id=dict(zip(old_pool,masses));observed=[float(by_id[g]) if g in by_id else None for g in pool]
        used=np.array([float(np.clip(by_id[g],0,1)) if g in by_id else 1. for g in pool])
        added=[g for g in pool if g not in by_id]
        a.check(source['newlyInitializedCandidateIndices']==added
            and a.digest(source['newCandidateInitialization'])==a.digest(dict(value=1.,kind='heuristic_initialization_not_observed')),
            'New candidate initialization falsely reported as observed')
    else:used=np.clip(masses,0,1);observed=masses.tolist();added=[]
    a.check(a.digest(source['rawOpeningMass'])==a.digest(observed)
        and a.digest(source['usedOpeningMass'])==a.digest(used.tolist()),'Weight mass data differs from raw vector')
    rate=eco['realDiscountRate'];years=eco['horizonYears'];annuity=rate/(1-(1+rate)**-years) if rate else 1/years
    module=areas*eco['buildingUnitCostTRY']*annuity+s['operatingCostMultiplier']*(eco['annualFixedSiteCostTRY']+beds*eco['annualBedSupportCostTRY'])
    doctor=design['areaPerDoctorM2']*eco['buildingUnitCostTRY']*annuity+s['operatingCostMultiplier']*eco['annualDoctorCostTRY']
    scale=max(1.,float(module.max()),doctor);original=np.r_[module[ti],np.full(len(pool),doctor)]/scale;penalized=original.copy()
    a.check(len(objective['siteWeights'])==len(pool),'Sparse site weight count differs')
    for j,(g,row) in enumerate(zip(pool,objective['siteWeights'])):
        a.keys(row,('candidateIndex','sourceOpeningMass','minimumOriginalTemplateCostScaled','addedCostScaledPerTemplate'),'site weight')
        xs=np.flatnonzero(si==j);minimum=float(original[xs].min());penalty=alpha*minimum/(used[j]+offset)
        a.check(type(row['candidateIndex']) is int and row['candidateIndex']==g,'Sparse weight candidate identity differs')
        for field,wanted in dict(sourceOpeningMass=used[j],minimumOriginalTemplateCostScaled=minimum,addedCostScaledPerTemplate=penalty).items():
            a.near(row[field],float(wanted),'1e-12','site weight '+field)
        penalized[xs]+=penalty
    if result['continuousRelaxationPrimalValidated']:
        with np.load(io.BytesIO(current_vectors),allow_pickle=False) as arrays:clean=arrays['continuousRelaxationVector']
        total=sum(row['population'] for row in d['districts']);target=total*s['coverageTarget']/100
        material=target*h['rates']['contactsPerResident']*s['demandMultiplier']*eco['costPerContactTRY']*s['operatingCostMultiplier']
        original_cost=float(original@clean[:nf]*scale+material)
        a.near(result['originalAnnualCostOfContinuousPrimalTRY'],original_cost,'1','continuous original annual cost')
        a.near(result['penalizedLPObjectiveScaled'],float(penalized@clean[:nf]),'1e-9','penalized objective')
    return dict(sourceReportSHA256=source['reportSHA256'],sourceVectorSHA256=source['vectorsSHA256'],
        alpha=alpha,openingMassOffset=offset,weightCount=len(pool),observedWeightCount=len(old_pool),
        newlyInitializedCandidateIndices=added,originalAnnualCostAndPenaltyKeptSeparate=True)


def verify_expanded_branch(report,references,inputs):
    document=a.load_json(references[EXPANDED_BRANCH]);pool=report['candidateIndices']
    a.check(document['candidatePoolFile']==EXPANDED_POOL
        and document['candidatePoolSHA256']==a.sha256(references[EXPANDED_POOL])
        and document['profileManifestSHA256']==inputs['manifest_sha256']
        and a.digest(document['sourceSHA256'])==a.digest(inputs['current_source_hashes'])
        and document['closedCandidateIndices']==report['closedCandidateIndices'],'Expanded branch source identity differs')
    path=document['geometryAuditFile'];a.check(path in references
        and a.sha256(references[path])==document['geometryAuditSHA256'],'Expanded geometry evidence hash differs')
    transform=a.cost.Transformer.from_crs(4326,32636,always_xy=True)
    sites=[inputs['data']['candidates'][g] for g in pool]
    points=[transform.transform(s['lon'],s['lat']) for s in sites]
    conflicts=set()
    for j in range(len(pool)):
        for i in range(j):
            if math.dist(points[i],points[j])<sites[i]['footprintRadiusMeters']+sites[j]['footprintRadiusMeters']-1e-7:
                conflicts.add((pool[i],pool[j]))
    a.check(conflicts=={tuple(sorted(pair)) for pair in document['allConflictPairs']},'Expanded physical conflict set differs')
    closed=set(report['closedCandidateIndices'])
    a.check(not document['remainingConflictPairs'] and all(closed&set(pair) for pair in conflicts),
        'Expanded branch leaves a physical conflict')


def verify_projection(full_certificate,projected,inputs):
    """Check exact named flows, retained resources and independently summed maxima."""
    full=full_certificate['plan']; part=projected['plan']
    expected={p['profile']:p for p in full['profiles']}
    a.check([p['profile'] for p in part['profiles']]==list(CANONICAL),'Canonical order differs')
    for row in part['profiles']:
        a.check(a.digest(row)==a.digest(expected[row['profile']]),'Canonical allocation/profile data changed')
    a.check(len(part['selected'])==len(full['selected']),'Projection dropped or added a resource site')
    loads={s['candidateIndex']:a.D(0) for s in full['selected']}
    for profile in part['profiles']:
        current=dict.fromkeys(loads,a.D(0))
        for flow in profile['allocations']:current[flow['candidateIndex']]+=a.D(flow['population'])
        loads={j:max(loads[j],current[j]) for j in loads}
    for source,target in zip(full['selected'],part['selected']):
        a.check(a.digest({k:v for k,v in source.items() if k!='maximumAssignedPopulationAcrossProfiles'})
            ==a.digest({k:v for k,v in target.items() if k!='maximumAssignedPopulationAcrossProfiles'}),
            'Projection changed resources or their order')
        a.near(target['maximumAssignedPopulationAcrossProfiles'],loads[source['candidateIndex']],'.001','canonical maximum load')
    for field in FIELDS[2:]:a.check(a.digest(full[field])==a.digest(part[field]),'Projection changed total or annual bill: '+field)
    full_audit=a.validate_window_plan(full_certificate,**{k:v for k,v in inputs.items() if k!='bindings'})
    part_audit=a.cost.validate_joint_plan(projected,inputs['data'],inputs['health'],inputs['baseline_matrices'],
        inputs['published_reference'],{k:inputs['current_source_hashes'][k] for k in a.cost.SOURCE_FILES},inputs['package_id'])
    a.check(part_audit['withinOriginalTransitBudget'] is True,'Projected source exceeds hard budget')
    for field in ('decimalAnnualEquivalentCostTRY','decimalAnnualMaterialCostTRY','decimalAnnualFixedResourceCostTRY'):
        a.check(a.D(full_audit[field])==a.D(part_audit[field]),'Projection changed independently computed annual cost')
    return full_audit,part_audit


def audit(folder,manifest,freeze_path,root=ROOT,producer_script=None):
    root=Path(root).resolve(strict=True);folder=Path(folder).resolve(strict=True)
    blobs={};bindings={}
    def read(path,parent=None):
        resolved,content=a._file_bytes(path,parent);bindings[str(resolved)]=content;return content
    report_bytes=read(folder/'repair-result.json',folder);report=a.load_json(report_bytes)
    inputs=a.read_window_inputs(manifest,root)
    upgrade=report.get('artifactType')=='open-location-bed-upgrade-window-resource-repair'
    expanded=report.get('artifactType')=='expanded-pool-strong-sparse-opening-tiny-snap-lp-rounded-window-resource-seed'
    strong=expanded or report.get('artifactType')=='strong-sparse-opening-tiny-snap-lp-rounded-window-resource-seed'
    sparse=strong or report.get('artifactType')=='sparse-opening-capacity-envelope-lp-rounded-window-resource-seed'
    branch=sparse or report.get('artifactType')=='conflict-branch-capacity-envelope-lp-rounded-window-resource-seed'
    corrected=branch or report.get('artifactType')=='open-pool-capacity-envelope-lp-corrected-rounded-window-resource-seed'
    open_pool=corrected or report.get('artifactType')=='open-pool-capacity-envelope-lp-rounded-window-resource-seed'
    envelope=open_pool or report.get('artifactType')=='capacity-envelope-lp-rounded-window-resource-seed'
    lp_round=envelope or report.get('artifactType')=='continuous-lp-rounded-window-resource-seed'
    artifact_type='expanded-pool-strong-sparse-opening-tiny-snap-lp-rounded-window-resource-seed' if expanded else 'strong-sparse-opening-tiny-snap-lp-rounded-window-resource-seed' if strong else 'sparse-opening-capacity-envelope-lp-rounded-window-resource-seed' if sparse else 'conflict-branch-capacity-envelope-lp-rounded-window-resource-seed' if branch else 'open-pool-capacity-envelope-lp-corrected-rounded-window-resource-seed' if corrected else 'open-pool-capacity-envelope-lp-rounded-window-resource-seed' if open_pool else 'capacity-envelope-lp-rounded-window-resource-seed' if envelope else 'continuous-lp-rounded-window-resource-seed' if lp_round else 'open-location-bed-upgrade-window-resource-repair' if upgrade else 'fixed-template-window-resource-repair'
    scope=EXPANDED_SCOPE if expanded else SPARSE_SCOPE if sparse else BRANCH_SCOPE if branch else OPEN_POOL_SCOPE if open_pool else ENVELOPE_SCOPE if envelope else LP_SCOPE if lp_round else UPGRADE_SCOPE if upgrade else SCOPE
    freeze=a.load_json(read(freeze_path))
    script_path=Path(producer_script) if producer_script is not None else root/(EXPANDED_SCRIPT if expanded else STRONG_SCRIPT if strong else SPARSE_SCRIPT if sparse else BRANCH_SCRIPT if branch else CORRECTED_SCRIPT if corrected else OPEN_POOL_SCRIPT if open_pool else ENVELOPE_SCRIPT if envelope else LP_SCRIPT if lp_round else UPGRADE_SCRIPT if upgrade else SCRIPT)
    script_blob=read(script_path)
    script_sha=a.sha256(script_blob.replace(b'\r\n',b'\n'))
    a.check(report['format']==1 and type(report['format']) is int
        and report['artifactType']==artifact_type,'Repair type differs')
    a.check(report['transitPackageId']==inputs['package_id'] and report['profileManifestSHA256']==inputs['manifest_sha256'],
            'Repair package/manifest differs')
    a.same_hashes(report['sourceSHA256'],inputs['current_source_hashes'],a.SOURCE_FILES,'repair inputs')
    a.same_hashes(report['modelCodeSHA256'],inputs['current_code_hashes'],a.MODEL_FILES,'repair model code')
    a.check(report['repairScriptLF_SHA256']==freeze['scriptLF_SHA256']==script_sha,'Repair code identity differs')
    a.check(a.digest(freeze['modelCodeSHA256'])==a.digest(inputs['current_code_hashes'])
        and a.digest(report['referenceSHA256'])==a.digest(freeze['referenceSHA256']),'Freeze references differ')
    references={}
    for name,wanted in report['referenceSHA256'].items():
        path=root/name
        a.check(path.resolve(strict=True)==path and path.is_relative_to(root),'Redirected/reference path outside repository')
        references[name]=read(path);a.check(a.sha256(references[name])==a.hash_value(wanted),'Changed historical source: '+name)
    a.check(STAGE in references,'Original fixed-template stage is not bound')
    source=a.load_json(references[STAGE])['costResult']
    mode=report['templateRestrictionMode']
    a.check(mode in (('lp-round',) if lp_round else ('open-upgrade',) if upgrade else ('fixed-all','fixed-core')),'Unsupported template restriction mode')
    pool_source=EXPANDED_POOL if expanded else POOL
    a.check(pool_source in references,'Candidate-pool source is not bound')
    a.validate_explicit_candidate_pool(a.load_json(references[pool_source]),inputs,
        [s['candidateIndex'] for s in source['selected']],report['candidateIndices'])
    if expanded:
        old_pool=a.validate_explicit_candidate_pool(a.load_json(references[POOL]),inputs,[s['candidateIndex'] for s in source['selected']])
        a.check(set(old_pool)<=set(report['candidateIndices']),'Expanded pool lost a historical candidate')
        verify_expanded_branch(report,references,inputs)
    a.check(a.digest(report['sourceLocationResources' if lp_round else 'sourceMinimumBedChoices' if upgrade else 'fixedSourceTemplateChoices'])==a.digest(source['selected'])
        and type(report['sourceTemplateCount']) is int and report['sourceTemplateCount']==source['hospitalCount'],
        'Fixed template source differs')
    names=[p['id'] for p in a.expected_profiles()]
    a.check(report['profileIds']==names and report['scope']==scope
        and report['isFinalUnrestrictedPlan'] is False and report['unrestrictedCostSearchStillRequired'] is True,
        'Repair scope overclaimed')
    a.check(a.D(report['hardAnnualBudgetTRY'])==a.D(inputs['published_reference']['capacity']['budgetLimitTRY']),
        'Repair hard budget changed')
    a.check(a.D(report['referenceAnnualCostTRY'])==a.D(inputs['source_cost_certificate']['plan']['annualEquivalentCostTRY'])
        and a.D(report['sourceAnnualCostTRY'])==a.D(source['annualEquivalentCostTRY']),
        'Source/reference annual cost differs')
    for name,field in (('vectors.npz','vectorSHA256'),('solver.log','solverLogSHA256')):
        blobs[name]=read(folder/name,folder);a.check(a.sha256(blobs[name])==a.hash_value(report[field]),'Repair artifact hash differs')
    process=a.load_json(read(folder/'process-status.json',folder))
    a.check(process['status']=='completed' and type(process['returnCode']) is int and process['returnCode']==0,
        'Repair worker did not finish successfully')
    if lp_round:
        a.check(report['nativeLogCapture']=='worker_stdout' and report['solverLogContainsNativeOutput'] is False
            and blobs['solver.log']==b'' and process['nativeLogFile']=='worker.log','LP log capture scope differs')
        a.check(a.sha256(read(folder/'worker.log',folder))==a.hash_value(process['workerLogSHA256']),'Native stdout log hash differs')
    result=report['result']
    sparse_summary=verify_sparse_weights(report,result,freeze,references,inputs,blobs['vectors.npz'],strong,expanded) if sparse else None
    if branch:verify_branch_closures(report['closedCandidateIndices'],report['candidateIndices'],result,freeze)
    correction_summary=None
    if corrected:
        nf,flow_slices,wire_size=wire_flow_slices(inputs,report['candidateIndices'])
        with np.load(io.BytesIO(blobs['vectors.npz']),allow_pickle=False) as arrays:
            a.check(len(arrays.files)==len(set(arrays.files)),'Duplicate correction vector members')
            if 'numericalFlowCorrection' in result:
                a.check({'rawContinuousSolverVector','continuousRelaxationVector'}<=set(arrays.files),'Correction vectors missing')
                args=(arrays['rawContinuousSolverVector'],arrays['continuousRelaxationVector'],result['numericalFlowCorrection'],
                    nf,flow_slices,result['continuousRelaxationPrimalValidated'])
                correction_summary=verify_signed_flow_snap(*args) if strong else verify_flow_correction(*args,1e-9 if branch else 1e-10)
            if result['continuousRelaxationPrimalValidated']:
                a.check(correction_summary is not None and result['rawFlowAssignmentsPreserved'] is correction_summary['rawFlowEntriesPreserved']
                    and result['rawPositiveFlowAssignmentsPreserved'] is (correction_summary['positiveFlowEntriesPreserved'] if strong else True),
                    'Raw/cleaned scope differs')
                if strong:a.check(result['allRemainingPositiveFlowAssignmentsPreserved'] is True,'Remaining flow preservation differs')
    a.check(result['templateRestrictionMode']==mode,'Result search mode differs')
    if not lp_round:
        a.check(result['profileIds']==names and result['boundCandidateIndices']==report['candidateIndices'],
            'Result search scope differs')
    fixed_indices=[]
    if lp_round:
        for field,value in dict(nativeIntegerSearchPerformed=False,provenOptimal=False,fixedSourceLocations=not open_pool,
            sourceBedSizesFixed=False,annualDemandCountedOnce=True,modelInfeasibilityIndependentlyCertified=False).items():
            a.check(result[field] is value,'False LP scope: '+field)
        a.check(result['minimumAnnualCostLowerBoundTRY'] is None and result['costGap'] is None,'LP bound leaked into integer result')
        if open_pool:
            a.check(result['locationsMayOpenOrClose'] is True and result['sourcePlanUsedOnlyForProvenance'] is True
                and result['openingCoupledIntegerCapacityEnvelope'] is True,'Free-pool LP scope differs')
        if envelope:
            a.check(result['inwardCapacityMarginPreservesAllIntegerSolutions'] is False
                and result['capacityRestrictionCanSupportGlobalInfeasibilityClaim'] is False
                and a.D(result['capacityMarginResidents'])==a.D('.001'),'Envelope heuristic scope differs')
            records=result['integerCapacityEnvelope'];pool=report['candidateIndices']
            source_ids=pool if open_pool else sorted(s['candidateIndex'] for s in source['selected'])
            a.check([r['candidateIndex'] for r in records]==source_ids,'Envelope source locations differ')
            for row in records:
                a.check(type(row['localIndex']) is int and pool[row['localIndex']]==row['candidateIndex']
                    and row['id']==inputs['data']['candidates'][row['candidateIndex']]['id'],
                    'Envelope local/global identity differs')
                a.check(a.D(row['inwardMarginResidents'])==a.D('.001'),'Envelope inward margin differs')
                a.near(row['workingCapacityThousandResidents'],
                    max(a.D(0),a.D(row['optimisticUpperBoundResidents'])/1000-a.D('.000001')),
                    '.000000001','Envelope working capacity')
    elif upgrade:
        restriction=upgrade_scope(source['selected'],source['selected'],inputs,report['candidateIndices'])
        a.check(a.digest(result['resourceRestrictions'])==a.digest(restriction),'Upgrade resource restriction scope differs')
        a.check(result['sourceLocationsMandatoryOpen'] is True and result['sourceBedCountsCannotDecrease'] is True,
            'Upgrade mandatory location/bed claim differs')
    else:
        fixed_indices=template_scope(mode,source['selected'],source['selected'],inputs,report['candidateIndices'])
        a.check(a.digest(result['templateBinaryFixedIndices'])==a.digest(fixed_indices),'Fixed binary scope differs')
    flags=dict(isFinalUnrestrictedPlan=False,unrestrictedCostSearchStillRequired=True,all44ProfilesRequired=True)
    if not lp_round:flags.update(fixedTemplateDecisions=not upgrade,sharedIntegerPhysiciansFree=True,
        restrictedModelInfeasibilityIndependentlyCertified=False)
    for field,value in flags.items():
        a.check(result[field] is value,'Unsupported repair result claim: '+field)
    a.check(result['boundScope']==scope,'Repair bound scope differs')
    if result.get('feasible') is not True:
        a.check(result.get('feasible') is None and process['full44CertificateFilePresent'] is False
            and not (folder/'full44-seed-plan.json').exists(),'Unknown repair exported a certificate')
        for field in ('selected','profiles','annualEquivalentCostTRY','minimumAnnualCostLowerBoundTRY','costGap'):
            a.check(result.get(field) is None,'Unknown repair published a success field: '+field)
        a.check(result['incumbentValidated'] is False and result['provenOptimal'] is False
            and result['modelInfeasibilityIndependentlyCertified'] is False,'Unknown repair overclaimed a proof')
        for name in ('canonical-four-source.json','canonical-four-audit.json','full44-audit.json','projection-metadata.json'):
            a.check(not (folder/name).exists(),'Unknown repair exported a projection or validated audit')
        with np.load(io.BytesIO(blobs['vectors.npz']),allow_pickle=False) as arrays:
            allowed=['continuousRelaxationVector'] if lp_round and result['continuousRelaxationPrimalValidated'] is True else []
            if corrected:
                allowed=[]
                if 'rawContinuousSolverVector' in arrays.files:allowed.append('rawContinuousSolverVector')
                if 'numericalFlowCorrection' in result:allowed.append('continuousRelaxationVector')
            a.check(arrays.files==allowed,'Unknown repair exported an integer primal vector or unexpected relaxation')
            if allowed and not corrected:
                raw=arrays[allowed[0]]
                a.check(raw.dtype.kind=='f' and raw.ndim==1 and np.all(np.isfinite(raw)),'Invalid retained continuous vector')
            if corrected and 'rawContinuousSolverVector' in arrays.files:
                a.check(arrays['rawContinuousSolverVector'].dtype.kind=='f','Diagnostic raw array must be numeric')
        summary=dict(status='inconclusive_repair_identity_checked',full44Validated=False,solverRun=False,
            nativeReportedInfeasible=result.get('relaxationNativeStatus')==2 if lp_round else result['nativeReportedInfeasible'],
            nativeModelStatus=result.get('relaxationNativeMessage') if lp_round else result['nativeModelStatus'],
            restrictedInfeasibilityIndependentlyCertified=False,canonical4Exported=False)
    else:
        a.check(process['full44CertificateFilePresent'] is True,'Completed repair certificate missing')
        cert_blob=read(folder/'full44-seed-plan.json',folder);cert=a.load_json(cert_blob)
        projected_blob=read(folder/'canonical-four-source.json',folder);projected=a.load_json(projected_blob)
        a.check(a.digest(cert['plan'])==a.digest({k:result[k] for k in FIELDS}),'Full certificate/result differs')
        a.check(cert['generation']['runReportSHA256']==a.sha256(report_bytes)
            and cert['generation']['vectorSHA256']==report['vectorSHA256']
            and cert['generation']['candidateIndices']==report['candidateIndices'],'Full certificate generation differs')
        method='Canonical four-profile primal projection of a new all-44 '+mode+' source-template, free-integer-physician resource repair. No separate four-profile native search; no unrestricted optimality claim.'
        if upgrade:method=UPGRADE_METHOD
        if lp_round:method=LP_METHOD
        if envelope:method=ENVELOPE_METHOD
        if open_pool:method=OPEN_POOL_METHOD
        if corrected:method=CORRECTED_METHOD
        if branch:method=BRANCH_METHOD
        if sparse:method=SPARSE_METHOD
        if strong:method=STRONG_METHOD
        a.check(projected['generation']['method']==method
            and projected['generation']['researchReportSHA256']==a.sha256(report_bytes)
            and projected['generation']['researchVectorSHA256']==report['vectorSHA256'],'Projection generation differs')
        if open_pool:pass  # The independent full44 gate below checks exact candidate-pool membership; no source-site condition.
        elif lp_round:location_scope(source['selected'],cert['plan']['selected'])
        elif upgrade:upgrade_scope(source['selected'],cert['plan']['selected'],inputs,report['candidateIndices'])
        else:template_scope(mode,source['selected'],cert['plan']['selected'],inputs,report['candidateIndices'])
        if branch:verify_branch_closures(report['closedCandidateIndices'],report['candidateIndices'],result,freeze,cert['plan']['selected'])
        full_audit,part_audit=verify_projection(cert,projected,inputs)
        vector,layout=a.reconstruct_saved_vector(cert,inputs)
        with np.load(io.BytesIO(blobs['vectors.npz']),allow_pickle=False) as arrays:
            expected_lp={'continuousRelaxationVector','roundedOriginalVector','finalOriginalVector'}
            if corrected:expected_lp.add('rawContinuousSolverVector')
            a.check(len(arrays.files)==len(set(arrays.files)) and 'finalOriginalVector' in arrays.files
                and (set(arrays.files)==expected_lp if lp_round else set(arrays.files)<={'finalOriginalVector','nativeValidatedVector','returnedRawVector'}),'Repair vector member set differs')
            for name in arrays.files:
                v=arrays[name];a.check(v.dtype.kind=='f' and v.shape==vector.shape and np.all(np.isfinite(v)),'Invalid repair vector')
            a.check(np.array_equal(arrays['finalOriginalVector'],vector),'Repair final vector differs from independent JSON reconstruction')
            if lp_round:
                verify_rounding_links(arrays['continuousRelaxationVector'],arrays['roundedOriginalVector'],vector,layout['sharedPrefix'])
                a.check(result['continuousLPPerformed'] is True and result['integerRoundingPerformed'] is True
                    and result['continuousRelaxationPrimalValidated'] is True
                    and result['numericallyCleanedFlowAssignmentsPreservedDuringRounding' if corrected else 'sourceFlowAssignmentsPreservedDuringRounding'] is True,
                    'LP successful rounding scope differs')
                if corrected:a.check('sourceFlowAssignmentsPreservedDuringRounding' not in result,'Ambiguous raw-flow preservation claim')
            if 'nativeValidatedVector' in arrays.files:
                v=arrays['nativeValidatedVector']
                a.check(np.array_equal(v[:layout['sharedPrefix']],vector[:layout['sharedPrefix']])
                    and np.all(np.abs(v-vector)<=2*np.spacing(np.maximum(np.abs(v),np.abs(vector)))),
                    'Repair native/serialized vector exceeds two ULPs or changes integer resources')
        for name,value in (('full44-audit.json',full_audit),('canonical-four-audit.json',part_audit)):
            a.check(a.digest(a.load_json(read(folder/name,folder)))==a.digest(value),'Saved audit differs: '+name)
        metadata=a.load_json(read(folder/'projection-metadata.json',folder))
        wanted=dict(format=1,artifactType='canonical-four-primal-projection',repairReportSHA256=a.sha256(report_bytes),
            repairVectorSHA256=report['vectorSHA256'],full44CertificateSHA256=a.sha256(cert_blob),
            projectionSHA256=a.sha256(projected_blob),canonicalProfiles=list(CANONICAL),newFourProfileNativeSearch=False,
            resourcesPreserved=True,annualCostPreserved=True,full44ValidationSeparate=True,
            modelCodeSHA256=inputs['current_code_hashes'],repairScriptLF_SHA256=script_sha)
        a.check(a.digest(metadata)==a.digest(wanted),'Projection provenance metadata differs')
        source_set={s['candidateIndex'] for s in source['selected']};final_set={s['candidateIndex'] for s in cert['plan']['selected']}
        summary=dict(status='validated_resource_repair_and_canonical_projection',full44Validated=True,
            canonical4Validated=True,canonicalProfilesExactlyPreserved=True,sourceLocationsPreserved=source_set<=final_set,
            sourceTemplateChoicesPreserved=not(upgrade or lp_round),sourceMinimumBedsPreserved=not lp_round,
            newlySelectedSiteCount=len(final_set-source_set),removedSourceSiteCount=len(source_set-final_set),
            hospitalCount=full_audit['hospitalCount'],beds=full_audit['beds'],doctors=full_audit['doctors'],
            decimalAnnualEquivalentCostTRY=full_audit['decimalAnnualEquivalentCostTRY'],
            decimalBudgetSlackTRY=full_audit['decimalBudgetSlackTRY'],projectionSHA256=a.sha256(projected_blob),
            newFourProfileNativeSearch=False,unrestrictedOptimalityCertified=False,solverRun=False)
    a.unchanged_window_inputs(inputs,root)
    for name,content in bindings.items():a.check(Path(name).read_bytes()==content,'Repair evidence changed during audit')
    summary.update(templateRestrictionMode=mode,mandatorySourceLocationCount=0 if open_pool else len(source['selected']),
        sourceReferenceLocationCount=len(source['selected']),locationsMayOpenOrClose=open_pool,
        closedCandidateIndices=report['closedCandidateIndices'] if branch else [],
        sourceTemplateChoicesFixed=not(upgrade or lp_round),sourceBedMinimumsEnforced=upgrade,
        nativeIntegerSearchPerformed=not lp_round,
        capacityEnvelopeCoefficientsIndependentlyRecomputedHere=False,
        numericalFlowCorrection=correction_summary,
        sparseObjectiveAudit=sparse_summary,
        fixedTemplateBinaryColumns=len(fixed_indices),candidatePoolSites=len(report['candidateIndices']),
        repairReportSHA256=a.sha256(report_bytes),repairVectorSHA256=report['vectorSHA256'],
        verifierCodeLF_SHA256=a.sha256(Path(__file__).read_bytes().replace(b'\r\n',b'\n')),
        scope='Independent current-source primal, Decimal annual cost, stated resource restrictions and exact projection checks only; no native replay, unrestricted optimum, minimum hospital count or real-city claim.')
    return summary


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-folder',required=True)
    parser.add_argument('--manifest',default=str(ROOT/'work/window-routing/full-v1/manifest.json'))
    parser.add_argument('--freeze',default=str(ROOT/'work/referees/window-resource-repair-freeze.json'))
    parser.add_argument('--producer-script',help='Explicit archived producer source; its LF hash must equal both frozen and reported hashes')
    args=parser.parse_args()
    print(json.dumps(audit(args.run_folder,args.manifest,args.freeze,producer_script=args.producer_script),ensure_ascii=False,indent=2,allow_nan=False))
