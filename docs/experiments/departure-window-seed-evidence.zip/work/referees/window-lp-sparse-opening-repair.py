"""Work-only continuous resource LP and validated integer rounding for 44 profiles.

No frozen production source is modified. --run is required for an actual
bounded subprocess experiment; default --preflight performs no native solve.
"""
from copy import copy,deepcopy
from datetime import datetime,timezone
import argparse
import io
import json
import math
from pathlib import Path
import subprocess
import sys
from time import monotonic

import numpy as np
from scipy import __version__ as SCIPY_VERSION
from scipy.optimize import linprog
from scipy.sparse import coo_matrix,vstack

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from backend.joint_model import validate_vector,AREA_TOL
from backend.window_seed import signature
from scripts import run_window_plan as runner
from scripts.audit_window_plan import (read_window_inputs,unchanged_window_inputs,code_hashes,
    validate_window_plan,validate_explicit_candidate_pool,BASE_PROFILES)
from scripts.audit_joint_plan import validate_joint_plan,SOURCE_FILES
from scripts.run_joint_plan import PLAN_FIELDS,sha,json_bytes,load_json,write_new,output_directory

HERE=Path(__file__).resolve()
LOADED_SCRIPT_SHA=sha(HERE.read_bytes().replace(b'\r\n',b'\n'))
LOADED_CODES=code_hashes()
FREEZE=HERE.with_name('window-lp-sparse-opening-repair-freeze.json')
MANIFEST='work/window-routing/full-v1/manifest.json'
STAGE='work/window-plans/joint273-v3/seed-preparation/stage-01-cost.json'
STAGE_VECTORS='work/window-plans/joint273-v3/seed-preparation/stage-01-cost-vectors.npz'
POOL='work/referees/window-pool-analysis-v1/geographic_plus32_large-pool.json'
SCOPE='Heuristic sparse-opening LP seed only in the declared closed-candidate branch. The penalized objective is not actual annual cost or a cost lower bound. All original annual-cost budget/44-target rows remain, then integer/primal/Decimal audit decides. No general infeasibility or optimality claim.'
CAPACITY_MARGIN_RESIDENTS=.001
ORIGINAL_ROW_TOLERANCE_THOUSAND_RESIDENTS=1e-7
NEGATIVE_FLOW_TOLERANCE_THOUSAND_RESIDENTS=1e-9
NATIVE_FEASIBILITY_TOLERANCE=1e-9
DEFAULT_CLOSED_CANDIDATES=(401,1495,1679)
SPARSE_OPENING_ALPHA=.25
OPENING_MASS_OFFSET=.05
WEIGHT_REPORT='work/window-repair/lp-branch273-v1/repair-result.json'
WEIGHT_VECTORS='work/window-repair/lp-branch273-v1/vectors.npz'


def controls(seconds,hard_seconds):
    for value,cap in ((seconds,180),(hard_seconds,300)):
        if type(value) not in (int,float) or not np.isfinite(value) or not 0<value<=cap:
            raise ValueError('Repair time must be positive and bounded')
    if hard_seconds<seconds+60:raise ValueError('Outer timeout must reserve audit time')


def integer_capacity_limits(full,mandatory):
    """Separate an optimistic integer capacity bound from an inward seed cap.

    Original physical area tolerance and integer variable bounds are included.
    Each resource row permits 1e-7 thousand residents: include this in the
    optimistic bound. The subsequent .001-resident inward margin is explicitly
    heuristic and may exclude borderline feasible assignments; no proof of
    original infeasibility or original LP optimality is derived from this LP.
    """
    records=[]
    for j in mandatory:
        options=[]
        for x in full.site_xs[j]:
            t=int(full.xtype[x])
            area_limit=math.nextafter((full.available[j]+AREA_TOL-full.area[t])/full.da,math.inf)
            variable_limit=math.nextafter(float(full.model[3][full.nx+j])+1e-8,math.inf)
            docs=math.floor(min(area_limit,variable_limit))
            if docs<full.minimum:continue
            base=min(float(full.bedcap[t]),docs*float(full.q))
            optimistic=math.nextafter(base+ORIGINAL_ROW_TOLERANCE_THOUSAND_RESIDENTS,math.inf)
            options.append(dict(templateId=full.h['templates'][t]['id'],beds=int(full.beds[t]),
                maximumIntegerDoctors=docs,capacityThousandResidents=base,
                optimisticCapacityThousandResidents=optimistic))
        if not options:raise ValueError('No fitting integer resource pair at candidate location')
        bound=max(x['optimisticCapacityThousandResidents'] for x in options)
        working=max(0.,bound-CAPACITY_MARGIN_RESIDENTS/1000)
        records.append(dict(localIndex=int(j),candidateIndex=full.ids[j],id=full.sites[j]['id'],
            optimisticUpperBoundResidents=bound*1000,workingCapacityThousandResidents=working,
            inwardMarginResidents=CAPACITY_MARGIN_RESIDENTS,templates=options))
    return records


def closed_candidates(full, values):
    if not isinstance(values,(list,tuple)) or any(type(x) is not int for x in values):
        raise ValueError('Closed candidates must be integer IDs')
    if list(values)!=sorted(set(values)) or any(x not in full.local for x in values):
        raise ValueError('Closed candidates must be sorted unique members of the candidate pool')
    return tuple(values)


def sparse_objective(full,opening_mass):
    mass=np.asarray(opening_mass,dtype=float)
    if mass.shape!=(full.m,) or not np.all(np.isfinite(mass)) or np.any(mass<0) or np.any(mass>1):
        raise ValueError('Finite site opening masses in [0,1] required')
    c=full.model[0].copy();records=[]
    for j,xs in enumerate(full.site_xs):
        original_min=float(np.min(full.c[xs]))
        if original_min<0:raise ValueError('Nonnegative original template costs required')
        penalty=SPARSE_OPENING_ALPHA*original_min/(mass[j]+OPENING_MASS_OFFSET)
        c[xs]+=penalty
        records.append(dict(candidateIndex=full.ids[j],sourceOpeningMass=float(mass[j]),
            minimumOriginalTemplateCostScaled=original_min,addedCostScaledPerTemplate=penalty))
    if not np.all(np.isfinite(c)):raise ValueError('Nonfinite penalized objective')
    return c,records


def restrict_templates(full,source_plan,mode='lp-round',closed=(),opening_mass=None):
    """Non-closed supplied sites may open or close; source is provenance.

    Original plot/conflict/count/resource/budget rows stay. Only the named
    closed candidates' template and physician upper bounds become zero.
    New load <= working_integer_capacity * sum(template opening variables)
    cuts hold for integer open/closed choices except the explicit inward seed
    margin. These branch restrictions cannot certify general infeasibility.
    """
    if len(full.times)!=44:raise ValueError('Exactly 44 real named profiles required')
    if mode!='lp-round':raise ValueError('Unknown LP repair mode')
    prefix=full.fixed_resource_vector(source_plan)[:full.nf].copy()
    if np.any(prefix!=np.rint(prefix)):raise ValueError('Source resource integers required')
    closed=closed_candidates(full,closed)
    eligible=np.array([j for j in range(full.m) if full.ids[j] not in closed],dtype=int)
    relaxed=copy(full);model=list(full.model);model[1]=np.zeros_like(model[1])
    model[3]=model[3].copy()
    for candidate in closed:
        j=full.local[candidate];model[3][full.site_xs[j]]=0.;model[3][full.nx+j]=0.
    limits=integer_capacity_limits(full,np.arange(full.m,dtype=int))
    cap_rows=[];cap_cols=[];cap_values=[];cap_hi=[]
    for name,(oi,sj) in full.edges.items():
        for record in limits:
            j=record['localIndex'];es=np.flatnonzero(sj==j)
            if not len(es):continue
            xs=full.site_xs[j];row=len(cap_hi)
            cap_rows.extend([row]*(len(es)+len(xs)))
            cap_cols.extend((full.offsets[name]+es).tolist()+xs.tolist())
            cap_values.extend([1.]*len(es)+[-record['workingCapacityThousandResidents']]*len(xs))
            cap_hi.append(0.)
    cap_A=coo_matrix((cap_values,(cap_rows,cap_cols)),shape=(len(cap_hi),len(full.c))).tocsc()
    model[4]=vstack([full.model[4],cap_A],format='csc')
    model[5]=np.r_[full.model[5],np.full(len(cap_hi),-np.inf)];model[6]=np.r_[full.model[6],cap_hi]
    if opening_mass is None:opening_mass=getattr(full,'heuristic_opening_mass',None)
    model[0],weight_records=sparse_objective(full,opening_mass)
    relaxed.model=tuple(model);relaxed.integer_capacity_limits=limits
    relaxed.sparse_opening_records=weight_records
    relaxed.dimensions=dict(full.dimensions,constraints=model[4].shape[0],nonzeros=model[4].nnz)
    return relaxed,prefix,eligible


def optimize_lp(problem,seconds):
    """One continuous LP; assembly consumes the native time allowance."""
    deadline=monotonic()+seconds;c,integer,lb,ub,A,lo,hi=problem.model
    eq=np.isfinite(lo)&np.isfinite(hi)&(lo==hi)
    upper=np.isfinite(hi)&~eq;lower=np.isfinite(lo)&~eq
    A_ub=vstack([A[upper],-A[lower]],format='csc');b_ub=np.r_[hi[upper],-lo[lower]]
    A_eq=A[eq];b_eq=lo[eq];bounds=np.column_stack([lb,ub])
    remaining=deadline-monotonic()
    if remaining<=0:raise TimeoutError('LP assembly consumed native time allowance')
    print('Starting continuous LP:',len(c),'variables;',A.shape[0],'rows; time',remaining,flush=True)
    return linprog(c,A_ub=A_ub,b_ub=b_ub,A_eq=A_eq,b_eq=b_eq,bounds=bounds,
        method='highs-ipm',options={'time_limit':remaining,'disp':True,
            'primal_feasibility_tolerance':NATIVE_FEASIBILITY_TOLERANCE,
            'dual_feasibility_tolerance':NATIVE_FEASIBILITY_TOLERANCE})


def correct_tiny_negative_flows(full,raw):
    """Explicit numerical repair only; preserve every positive flow bit-for-bit.

    This alone does not establish feasibility. The original relaxed model,
    original integer model, and independent Decimal/primal audit still decide.
    """
    raw=np.asarray(raw,dtype=float)
    if raw.shape!=(len(full.c),) or not np.all(np.isfinite(raw)):
        raise ValueError('Raw LP vector shape/finiteness invalid')
    flow=raw[full.nf:];negative=flow<0
    if np.any(flow < -NEGATIVE_FLOW_TOLERANCE_THOUSAND_RESIDENTS):
        raise ValueError('Significant negative LP flow exceeds explicit numerical correction threshold')
    clean=raw.copy();clean[full.nf:][negative]=0.
    changed=-flow[negative]*1000
    if not np.array_equal(clean[:full.nf],raw[:full.nf]) or not np.array_equal(clean[full.nf:][flow>0],flow[flow>0]):
        raise ValueError('Numerical correction changed positive flow or resource prefix')
    report=dict(allowedNegativeThresholdThousandResidents=NEGATIVE_FLOW_TOLERANCE_THOUSAND_RESIDENTS,
        changedFlowCount=int(negative.sum()),maximumCorrectionResidents=float(changed.max(initial=0.)),
        totalCorrectionResidents=float(changed.sum()),positiveFlowEntriesPreserved=True,
        resourcePrefixPreserved=True,rawFlowEntriesPreserved=not bool(negative.any()),
        originalRelaxedConstraintsRevalidated=False,
        mostNegativeRawFlowThousandResidents=float(flow.min(initial=0.)),
        totalIsSumAcrossProfilesNotUniqueResidents=True,profiles=[])
    for name,(oi,sj) in full.edges.items():
        f=raw[full.offsets[name]:full.offsets[name]+len(oi)];mask=f<0
        report['profiles'].append(dict(profile=name,changedFlowCount=int(mask.sum()),
            totalCorrectionResidents=float((-f[mask]*1000).sum()),
            maximumCorrectionResidents=float((-f[mask]*1000).max(initial=0.))))
    return clean,report


def round_flow_resources(full,raw,eligible):
    """Preserve every profile flow; pick integer resources from its max load."""
    v=np.asarray(raw,dtype=float).copy()
    if v.shape!=(len(full.c),) or not np.all(np.isfinite(v)) or np.any(v[full.nf:]<0):
        raise ValueError('Finite, nonnegative complete LP flows required')
    maximum=np.zeros(full.m)
    for name,(oi,sj) in full.edges.items():
        flow=v[full.offsets[name]:full.offsets[name]+len(oi)]
        maximum=np.maximum(maximum,np.bincount(sj,weights=flow*1000,minlength=full.m))
    mask=np.zeros(full.m,dtype=bool);mask[eligible]=True
    if np.any(maximum[~mask]>0):raise ValueError('Positive LP flow outside supplied eligible pool')
    active=np.flatnonzero(maximum>0)
    active_ids={full.ids[j] for j in active}
    conflicts=[list(pair) for pair in full.conflicts if set(pair)<=active_ids]
    if conflicts:raise ValueError('Positive LP flow opens conflicting candidate pairs: '+json.dumps(conflicts))
    v[:full.nf]=0
    for j in active:
        # Exactly the frozen cleanup's one-ULP ceil and physical tolerances.
        # Full original matrix/physical validation remains mandatory afterward.
        need=max(full.minimum,math.ceil(math.nextafter(maximum[j]*full.contact/full.s['contactsPerDoctor'],-math.inf)))
        options=[]
        for x in full.site_xs[j]:
            t=full.xtype[x]
            if (full.beds[t]*365*full.occupancy+.1>=maximum[j]*full.bedrate
                and full.area[t]+need*full.da<=full.available[j]+AREA_TOL
                and need<=full.model[3][full.nx+j]):
                options.append((float(full.c[x]),int(x)))
        if not options:raise ValueError('No integer bed/physician pair fits candidate location and its maximum load')
        _,x=min(options);v[x]=1;v[full.nx+j]=need
    full.validate(v)
    if not np.array_equal(v[full.nf:],np.asarray(raw)[full.nf:]):raise ValueError('Rounding changed profile flows')
    return v


def repair(full,source_plan,seconds=180,*,mode='lp-round',closed=(),opening_mass=None,solve=optimize_lp):
    if type(seconds) not in (int,float) or not np.isfinite(seconds) or not 0<seconds<=180:
        raise ValueError('Continuous LP allowance is at most 180 seconds')
    closed=closed_candidates(full,closed)
    original_signature=signature(full);relaxed,prefix,mandatory=restrict_templates(full,source_plan,mode,closed,opening_mass)
    relaxed_signature=signature(relaxed);began=monotonic();vectors={}
    common=dict(status='inconclusive_without_validated_integer_seed',feasible=None,selected=None,profiles=None,
        annualEquivalentCostTRY=None,minimumAnnualCostLowerBoundTRY=None,costGap=None,provenOptimal=False,
        nativeIntegerSearchPerformed=False,continuousLPPerformed=False,integerRoundingPerformed=False,
        incumbentValidated=False,isFinalUnrestrictedPlan=False,unrestrictedCostSearchStillRequired=True,
        all44ProfilesRequired=True,templateRestrictionMode=mode,boundScope=SCOPE,
        closedCandidateIndices=list(closed),branchRestrictionRemovedForFinalFullSearch=True,
        nativePrimalFeasibilityTolerance=NATIVE_FEASIBILITY_TOLERANCE,
        nativeDualFeasibilityTolerance=NATIVE_FEASIBILITY_TOLERANCE,
        heuristicObjective=dict(kind='reweighted_opening_L1',alpha=SPARSE_OPENING_ALPHA,
            openingMassOffset=OPENING_MASS_OFFSET,calibratedClinicalParameter=False,
            representsActualAnnualCost=False,canSupportOriginalCostLowerBound=False,
            originalBudgetRowUnchanged=True,originalPhysicianCoefficientsUnchanged=True,
            siteWeights=relaxed.sparse_opening_records),
        nativeOptimalityScope='Penalized continuous branch LP only; never original annual-cost or integer optimum',
        fixedSourceLocations=False,locationsMayOpenOrClose=True,sourcePlanUsedOnlyForProvenance=True,
        openingCoupledIntegerCapacityEnvelope=True,sourceBedSizesFixed=False,annualDemandCountedOnce=True,
        modelInfeasibilityIndependentlyCertified=False,hardAnnualBudgetTRY=full.annual_budget,
        continuousSolver='scipy.linprog(method=highs-ipm)',scipyVersion=SCIPY_VERSION,
        continuousRelaxationPrimalValidated=False,
        integerCapacityEnvelope=relaxed.integer_capacity_limits,
        capacityMarginResidents=CAPACITY_MARGIN_RESIDENTS,
        inwardCapacityMarginPreservesAllIntegerSolutions=False,
        capacityRestrictionCanSupportGlobalInfeasibilityClaim=False,
        roundingNumericalPolicy=dict(doctorCeil='one nextafter toward negative infinity, matching frozen cleanup',
            bedDayTolerance=.1,areaToleranceM2=AREA_TOL,fullOriginalValidationRequired=True))
    try:solved=solve(relaxed,seconds)
    except TimeoutError as exc:
        if signature(full)!=original_signature or signature(relaxed)!=relaxed_signature:
            raise ValueError('Original/LP model changed during timeout')
        return dict(common,reason=str(exc)),vectors,None
    if signature(full)!=original_signature or signature(relaxed)!=relaxed_signature:
        raise ValueError('Original/LP model changed during repair')
    common.update(continuousLPPerformed=True,relaxationNativeStatus=int(solved.status),
        relaxationNativeMessage=str(solved.message),relaxationIterations=int(getattr(solved,'nit',0) or 0))
    if solved.x is not None:
        vectors['rawContinuousSolverVector']=np.asarray(solved.x,dtype=float).copy()
    if isinstance(solved.status,(bool,np.bool_)) or not isinstance(solved.status,(int,np.integer)) or solved.status!=0 or solved.x is None:
        return dict(common,reason='No optimal continuous LP primal accepted; no old-flow fallback'),vectors,None
    raw=np.asarray(solved.x,dtype=float)
    # Diagnostic storage precedes every negative-flow/shape/primal gate.
    vectors['rawContinuousSolverVector']=raw.copy()
    try:
        clean,correction=correct_tiny_negative_flows(full,raw)
        common['numericalFlowCorrection']=correction
        vectors['continuousRelaxationVector']=clean.copy()
        validate_vector(clean,*relaxed.model[1:])
        correction['originalRelaxedConstraintsRevalidated']=True
    except (ValueError,RuntimeError) as exc:
        return dict(common,reason='Continuous primal numerical correction/validation failed: '+str(exc)),vectors,None
    common.update(continuousRelaxationPrimalValidated=True,originalAnnualCostOfContinuousPrimalTRY=full.cost(clean),
        penalizedLPObjectiveScaled=float(relaxed.model[0]@clean),
        rawFlowAssignmentsPreserved=correction['rawFlowEntriesPreserved'],rawPositiveFlowAssignmentsPreserved=True)

    try:
        v=round_flow_resources(full,clean,mandatory)
        result=full.serialize(v)
        actual,_=full.read_plan(result);full.validate(actual)
        if not np.array_equal(actual[:full.nf],v[:full.nf]):raise ValueError('JSON roundtrip changed rounded resources')
        tolerance=2*np.spacing(np.maximum(np.abs(actual),np.abs(v)))
        if np.any(np.abs(actual-v)>tolerance):raise ValueError('Flow roundtrip exceeds two ULPs')

    except (ValueError,RuntimeError) as exc:
        return dict(common,reason='Continuous primal/rounding failed: '+str(exc)),vectors,None
    if signature(full)!=original_signature or signature(relaxed)!=relaxed_signature:
        raise ValueError('Original/LP model changed before final export')
    vectors.update(roundedOriginalVector=v.copy(),finalOriginalVector=actual.copy())
    result.update(common);result.update(status='feasible',seedMethod='continuous_lp_then_integer_resource_rounding',feasible=True,
        selected=full.serialize(actual)['selected'],profiles=full.serialize(actual)['profiles'],
        annualEquivalentCostTRY=full.cost(actual),incumbentValidated=True,integerRoundingPerformed=True,
        originalAnnualCostOfContinuousPrimalTRY=full.cost(clean),roundingAnnualCostIncreaseTRY=full.cost(actual)-full.cost(clean),
        numericallyCleanedFlowAssignmentsPreservedDuringRounding=True,elapsedRepairSeconds=monotonic()-began,
        reason=None,hardBudgetConstraint=True)
    return result,vectors,{key:result[key] for key in PLAN_FIELDS}


def canonical_projection(plan,source_certificate,source_hashes,report_sha,vector_sha,mode='lp-round',closed=()):
    """A new four-clock primal view, never an invented historical native run."""
    by_name={p['profile']:p for p in plan['profiles']}
    if len(by_name)!=44 or any(name not in by_name for name in BASE_PROFILES):
        raise ValueError('A complete 44-profile plan is required before projection')
    projected={key:deepcopy(plan[key]) for key in PLAN_FIELDS}
    projected['profiles']=[deepcopy(by_name[name]) for name in BASE_PROFILES]
    maximum={s['candidateIndex']:0. for s in projected['selected']}
    for profile in projected['profiles']:
        load={j:0. for j in maximum}
        for allocation in profile['allocations']:load[allocation['candidateIndex']]+=allocation['population']
        maximum={j:max(maximum[j],load[j]) for j in maximum}
    for site in projected['selected']:site['maximumAssignedPopulationAcrossProfiles']=maximum[site['candidateIndex']]
    return dict(format=1,transitPackageId=source_certificate['transitPackageId'],
        planningVersion=source_certificate['planningVersion'],scenario=deepcopy(source_certificate['scenario']),
        sourceSHA256={name:source_hashes[name] for name in SOURCE_FILES},
        generation=dict(method='Canonical four-profile primal projection of a new all-44 heuristic sparse-opening capacity-envelope continuous resource LP in the explicitly closed-candidate branch recorded by its research report, bounded tiny-negative-flow correction and validated integer resource rounding. Remaining supplied locations may open or close. No separate four-profile native search or unrestricted optimality claim.',
            researchReportSHA256=report_sha,researchVectorSHA256=vector_sha,searchProvenOptimal=False,
            minimumHospitalCountProven=False,travelTimeOptimized=False,annualDemandCountedOnce=True,
            sameIndividualsAcrossProfilesConstrained=False),plan=projected)


def certificate(plan,inputs,pool,report_sha,vector_sha):
    source=inputs['source_cost_certificate'];names=list(inputs['matrices'])
    return dict(format=1,artifactType='window-common-resource-plan',transitPackageId=inputs['package_id'],
        planningVersion=source['planningVersion'],scenario=source['scenario'],
        profileManifestSHA256=inputs['manifest_sha256'],sourceSHA256=inputs['current_source_hashes'],
        modelCodeSHA256=inputs['current_code_hashes'],budget=dict(limitTRY=runner.ORIGINAL_ANNUAL_BUDGET_TRY,
            referenceAnnualCostTRY=source['plan']['annualEquivalentCostTRY'],hardConstraint=True),
        generation=dict(method='Work-only seed: all 44 profiles within the explicitly closed-candidate branch recorded in the run report; other pool locations may open/close. Heuristic sparse-opening capacity-envelope continuous resource LP with original-cost budget unchanged, bounded numerical flow correction and validated integer rounding. No integer-native or unrestricted optimum claim.',
            runReportSHA256=report_sha,vectorSHA256=vector_sha,candidateIndices=pool,
            optimizedProfiles=names,validatedProfiles=names,searchProvenOptimal=False,minimumHospitalCountProven=False,
            annualDemandCountedOnce=True,sameIndividualsAcrossProfilesConstrained=False),plan=plan)


def read_setup(freeze_path=FREEZE,closed=DEFAULT_CLOSED_CANDIDATES):
    freeze_path=Path(freeze_path).resolve(strict=True);freeze_bytes=freeze_path.read_bytes();freeze=load_json(freeze_bytes)
    if (freeze['scriptLF_SHA256']!=LOADED_SCRIPT_SHA or sha(HERE.read_bytes().replace(b'\r\n',b'\n'))!=LOADED_SCRIPT_SHA
        or freeze['modelCodeSHA256']!=LOADED_CODES or code_hashes()!=LOADED_CODES):
        raise ValueError('Frozen/loaded repair or production code differs')
    if freeze.get('closedCandidateIndices')!=list(closed):raise ValueError('Closed branch differs from reviewed freeze')
    if freeze.get('sparseOpeningAlpha')!=SPARSE_OPENING_ALPHA or freeze.get('openingMassOffset')!=OPENING_MASS_OFFSET:
        raise ValueError('Sparse objective controls differ from reviewed freeze')
    references={}
    for name,wanted in freeze['referenceSHA256'].items():
        path=ROOT/name
        if path.resolve()!=path or not path.is_file() or not path.is_relative_to(ROOT):raise ValueError('Redirected repair source')
        content=path.read_bytes()
        if sha(content)!=wanted:raise ValueError('Frozen repair source differs: '+name)
        references[name]=content
    if not {MANIFEST,STAGE,STAGE_VECTORS,POOL,WEIGHT_REPORT,WEIGHT_VECTORS}<=set(references):raise ValueError('Repair source bindings incomplete')
    inputs=read_window_inputs(ROOT/MANIFEST)
    if inputs['current_code_hashes']!=LOADED_CODES:raise ValueError('Reader and loaded code differ')
    stage=load_json(references[STAGE]);pool_doc=load_json(references[POOL]);plan=stage['costResult']
    selected=sorted(s['candidateIndex'] for s in plan['selected'])
    pool=validate_explicit_candidate_pool(pool_doc,inputs,selected)
    if stage['candidateIndices']!=pool or stage['optimizedProfileIds']!=list(inputs['matrices'])[:12]:
        raise ValueError('Historical source candidate/profile scope differs')
    subset=runner.formulate(dict(inputs,matrices={n:inputs['matrices'][n] for n in stage['optimizedProfileIds']}),pool)
    json_vector,_=subset.read_plan(plan)
    with np.load(io.BytesIO(references[STAGE_VECTORS]),allow_pickle=False) as arrays:
        native=arrays['finalOriginalVector'];subset.validate(native)
        if not np.array_equal(native[:subset.nf],json_vector[:subset.nf]):raise ValueError('Source resource vector differs')
        if np.any(np.abs(native-json_vector)>2*np.spacing(np.maximum(np.abs(native),np.abs(json_vector)))):
            raise ValueError('Source flow vector differs beyond serialization tolerance')
    full=runner.formulate(inputs,pool)
    prior=load_json(references[WEIGHT_REPORT])
    if (prior['vectorSHA256']!=sha(references[WEIGHT_VECTORS]) or prior['candidateIndices']!=pool
        or prior['closedCandidateIndices']!=list(closed)
        or prior['profileManifestSHA256']!=inputs['manifest_sha256']
        or prior['sourceSHA256']!=inputs['current_source_hashes'] or prior['modelCodeSHA256']!=LOADED_CODES):
        raise ValueError('Opening weight source has different model/pool/branch identity')
    with np.load(io.BytesIO(references[WEIGHT_VECTORS]),allow_pickle=False) as arrays:
        raw=np.asarray(arrays['rawContinuousSolverVector'],dtype=float)
    if raw.shape!=(len(full.c),) or not np.all(np.isfinite(raw)):
        raise ValueError('Weight source raw vector shape/finiteness differs')
    raw_mass=np.array([raw[xs].sum() for xs in full.site_xs])
    if np.any(raw_mass < -1e-7) or np.any(raw_mass>1+1e-7):raise ValueError('Opening mass outside original row tolerance')
    full.heuristic_opening_mass=np.clip(raw_mass,0,1)
    full.heuristic_raw_opening_mass=raw_mass
    restrict_templates(full,plan,closed=closed)
    def gate():
        unchanged_window_inputs(inputs)
        if freeze_path.read_bytes()!=freeze_bytes or code_hashes()!=LOADED_CODES or sha(HERE.read_bytes().replace(b'\r\n',b'\n'))!=LOADED_SCRIPT_SHA:
            raise ValueError('Repair freeze/code changed')
        if any((ROOT/name).read_bytes()!=content for name,content in references.items()):raise ValueError('Repair source changed')
    gate()
    return inputs,stage,full,pool,freeze,gate


def worker(args):
    began=monotonic();folder=Path(args.out).absolute();work=ROOT/'work'
    if work.resolve()!=work or folder.resolve()!=folder or not folder.is_relative_to(work) or folder==work or not folder.is_dir():
        raise ValueError('Worker requires a fresh unredirected work directory')
    inputs,stage,full,pool,freeze,gate=read_setup(args.freeze,args.closed_candidates)
    print('LP repair free candidate pool:',len(pool),'candidates; source provenance locations:',stage['costResult']['hospitalCount'],'original dimensions:',full.dimensions,flush=True)
    result,vectors,plan=repair(full,stage['costResult'],args.seconds,mode=args.mode,closed=args.closed_candidates)
    native_log=result.get('warmStart',{}).pop('solverLog','').encode('utf8')
    archive=io.BytesIO();np.savez_compressed(archive,**vectors);vector_bytes=archive.getvalue()
    report=dict(format=1,artifactType='sparse-opening-capacity-envelope-lp-rounded-window-resource-seed',builtAt=datetime.now(timezone.utc).isoformat(),
        transitPackageId=inputs['package_id'],profileManifestSHA256=inputs['manifest_sha256'],
        sourceSHA256=inputs['current_source_hashes'],modelCodeSHA256=LOADED_CODES,
        repairScriptLF_SHA256=LOADED_SCRIPT_SHA,referenceSHA256=freeze['referenceSHA256'],
        candidateIndices=pool,profileIds=list(inputs['matrices']),sourceLocationResources=stage['costResult']['selected'],
        sourceTemplateCount=stage['costResult']['hospitalCount'],hardAnnualBudgetTRY=full.annual_budget,
        templateRestrictionMode=args.mode,closedCandidateIndices=list(args.closed_candidates),
        openingWeightSource=dict(report=WEIGHT_REPORT,reportSHA256=freeze['referenceSHA256'][WEIGHT_REPORT],
            vectors=WEIGHT_VECTORS,vectorsSHA256=freeze['referenceSHA256'][WEIGHT_VECTORS],
            rawOpeningMass=full.heuristic_raw_opening_mass.tolist(),
            usedOpeningMass=full.heuristic_opening_mass.tolist(),
            numericalMassClampOnlyForHeuristicWeights=True),
        sourceAnnualCostTRY=stage['costResult']['annualEquivalentCostTRY'],referenceAnnualCostTRY=full.reference_annual_cost,
        controls=dict(nativeSeconds=args.seconds,outerHardSeconds=args.hard_seconds),result=result,
        vectorSHA256=sha(vector_bytes),solverLogSHA256=sha(native_log),elapsedSeconds=monotonic()-began,
        nativeLogCapture='worker_stdout',solverLogContainsNativeOutput=False,
        isFinalUnrestrictedPlan=False,unrestrictedCostSearchStillRequired=True,scope=SCOPE)
    report_bytes=json_bytes(report);payloads={'repair-result.json':report_bytes,'vectors.npz':vector_bytes,'solver.log':native_log}
    if plan is not None:
        cert=certificate(plan,inputs,pool,sha(report_bytes),sha(vector_bytes))
        audited=validate_window_plan(cert,**{k:inputs[k] for k in runner.INPUT_KEYS})
        projected=canonical_projection(plan,inputs['source_cost_certificate'],inputs['current_source_hashes'],sha(report_bytes),sha(vector_bytes),args.mode)
        projected_audit=validate_joint_plan(projected,inputs['data'],inputs['health'],inputs['baseline_matrices'],
            inputs['published_reference'],{k:inputs['current_source_hashes'][k] for k in SOURCE_FILES},inputs['package_id'])
        if not projected_audit['withinOriginalTransitBudget']:raise ValueError('Projected source exceeds strict budget')
        projected_bytes=json_bytes(projected)
        metadata=dict(format=1,artifactType='canonical-four-primal-projection',repairReportSHA256=sha(report_bytes),
            repairVectorSHA256=sha(vector_bytes),full44CertificateSHA256=sha(json_bytes(cert)),
            projectionSHA256=sha(projected_bytes),canonicalProfiles=list(BASE_PROFILES),
            newFourProfileNativeSearch=False,resourcesPreserved=True,annualCostPreserved=True,
            full44ValidationSeparate=True,modelCodeSHA256=LOADED_CODES,repairScriptLF_SHA256=LOADED_SCRIPT_SHA)
        payloads.update({'full44-seed-plan.json':json_bytes(cert),'full44-audit.json':json_bytes(audited),
            'canonical-four-source.json':projected_bytes,'canonical-four-audit.json':json_bytes(projected_audit),
            'projection-metadata.json':json_bytes(metadata)})
    gate()
    for name,content in payloads.items():write_new(folder/name,content)
    print('Repair finished:',result['status'],'full44 checked:',plan is not None,flush=True)


def run(args):
    controls(args.seconds,args.hard_seconds)
    folder=output_directory(ROOT,args.out);folder.mkdir(parents=True,exist_ok=False)
    command=[sys.executable,'-X','utf8',str(HERE),'--worker','--out',str(folder),'--freeze',str(Path(args.freeze).resolve(strict=True)),
        '--seconds',str(args.seconds),'--hard-seconds',str(args.hard_seconds),'--mode',args.mode,
        '--closed-candidates',*[str(x) for x in args.closed_candidates]]
    began=monotonic()
    with (folder/'worker.log').open('xb') as log:
        try:
            process=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,timeout=args.hard_seconds,check=False)
            status=dict(status='completed' if process.returncode==0 else 'worker_failed',returnCode=process.returncode)
        except subprocess.TimeoutExpired:status=dict(status='hard_timeout',returnCode=None)
    status.update(elapsedSeconds=monotonic()-began,hardSeconds=args.hard_seconds,
        full44CertificateFilePresent=(folder/'full44-seed-plan.json').is_file(),
        workerLogSHA256=sha((folder/'worker.log').read_bytes()),nativeLogFile='worker.log')
    write_new(folder/'process-status.json',json_bytes(status));print(json.dumps(status),flush=True)
    if status['status']!='completed':raise SystemExit(1)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--out')
    parser.add_argument('--freeze',default=str(FREEZE));parser.add_argument('--seconds',type=float,default=180)
    parser.add_argument('--hard-seconds',type=float,default=300);parser.add_argument('--run',action='store_true')
    parser.add_argument('--mode',choices=('lp-round',),default='lp-round')
    parser.add_argument('--closed-candidates',nargs='+',type=int,default=list(DEFAULT_CLOSED_CANDIDATES))
    parser.add_argument('--worker',action='store_true',help=argparse.SUPPRESS)
    args=parser.parse_args();controls(args.seconds,args.hard_seconds)
    if args.worker or args.run:
        if not args.out:parser.error('--out required for a run')
        worker(args) if args.worker else run(args)
    else:
        inputs,stage,problem,pool,freeze,gate=read_setup(args.freeze,args.closed_candidates);gate()
        print(json.dumps(dict(status='preflight_only_no_native',dimensions=problem.dimensions,
            candidatePoolSize=len(pool),closedCandidateIndices=list(args.closed_candidates),
            freeCandidateCount=len(pool)-len(args.closed_candidates),sourceProvenanceLocations=stage['costResult']['hospitalCount'],
            conflictCandidatePairs=list(problem.conflicts),sourceCostTRY=stage['costResult']['annualEquivalentCostTRY'],
            hardBudgetTRY=problem.annual_budget,modelCodeSHA256=LOADED_CODES,repairScriptLF_SHA256=LOADED_SCRIPT_SHA),indent=2))
