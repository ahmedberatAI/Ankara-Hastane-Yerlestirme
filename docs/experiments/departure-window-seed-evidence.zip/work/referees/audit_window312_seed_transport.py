"""Independent arithmetic/identity/flow audit: no model, solver or router import."""
from pathlib import Path
from datetime import datetime,timezone
from decimal import Decimal,getcontext
import hashlib,io,json,math
import numpy as np
from pyproj import Transformer

ROOT=Path(__file__).resolve().parents[2]
SHA=lambda b:hashlib.sha256(b).hexdigest()
D=lambda x:Decimal(str(x))
getcontext().prec=45


def main():
    folder=ROOT/'work/window-repair/lp-expanded312-v1';base=ROOT/'work/window-routing/full-v1'
    files={name:(folder/name).read_bytes() for name in ['repair-result.json','vectors.npz','full44-seed-plan.json','canonical-four-source.json','projection-metadata.json','process-status.json','worker.log']}
    report=json.loads(files['repair-result.json']);cert=json.loads(files['full44-seed-plan.json']);plan=cert['plan'];source=json.loads(files['canonical-four-source.json']);meta=json.loads(files['projection-metadata.json']);status=json.loads(files['process-status.json'])
    manifest_bytes=(base/'manifest.json').read_bytes();M=json.loads(manifest_bytes)
    assert SHA(manifest_bytes)==report['profileManifestSHA256']==cert['profileManifestSHA256']=='29eb7c5a298536ab6a93a998fef1e39ef18a5ea3edd8d9eaf4b78db484bcc7f1'
    assert SHA(files['vectors.npz'])==report['vectorSHA256']==cert['generation']['vectorSHA256']
    assert SHA(files['repair-result.json'])==cert['generation']['runReportSHA256']
    assert status['returnCode']==0 and status['status']=='completed' and SHA(files['worker.log'])==status['workerLogSHA256']
    for p,h in report['referenceSHA256'].items():assert SHA((ROOT/p).read_bytes())==h,p
    for p,h in report['modelCodeSHA256'].items():assert SHA((ROOT/p).read_bytes().replace(b'\r\n',b'\n'))==h,p
    assert report['modelCodeSHA256']==cert['modelCodeSHA256']
    src={}
    for p,h in report['sourceSHA256'].items():
        src[p]=(ROOT/'data/processed'/p).read_bytes();assert SHA(src[p])==h,p
    assert report['sourceSHA256']==cert['sourceSHA256']
    data=json.loads(src['dataset.json']);health=json.loads(src['health-planning.json']);scenario=cert['scenario'];C=data['candidates']
    assert scenario==source['scenario'] and scenario['threshold']==45 and scenario['coverageTarget']==95 and scenario['districtFloor']==80
    pool=report['candidateIndices'];assert len(pool)==312 and pool==sorted(set(pool))==cert['generation']['candidateIndices']
    names=M['producedProfileIds'];assert len(names)==44 and [p['profile'] for p in plan['profiles']]==names==report['profileIds']
    pop=[D(x['population']) for x in data['demands']];total=D(data['metadata']['provincePopulation']);target=total*D('.95')
    districts={d['id']:d for d in data['districts']};assert sum(D(d['population']) for d in districts.values())==total
    design=health['design'];rates=health['rates'];eco=health['economics'];templates=health['templates'];tid={t['id']:i for i,t in enumerate(templates)}
    contact=D(rates['contactsPerResident'])*D(scenario['demandMultiplier']);bedrate=D(rates['bedDaysPerResident'])*D(scenario['demandMultiplier'])
    areas=np.array([t['grossAreaM2'] for t in templates],float);available=np.pi*np.array([C[j]['footprintRadiusMeters'] for j in pool])**2*design['maxFloors']
    xs,ts=np.where(areas[None,:]+design['minimumDoctorsPerSite']*design['areaPerDoctorM2']<=available[:,None]+.001)
    nx=len(xs);nf=nx+len(pool);local={j:k for k,j in enumerate(pool)};prefix_index={(int(j),int(t)):i for i,(j,t) in enumerate(zip(xs,ts))}
    with np.load(io.BytesIO(files['vectors.npz']),allow_pickle=False) as z:
        assert set(z.files)=={'rawContinuousSolverVector','continuousRelaxationVector','roundedOriginalVector','finalOriginalVector'}
        raw,clean,rounded,final=[z[k].copy() for k in ['rawContinuousSolverVector','continuousRelaxationVector','roundedOriginalVector','finalOriginalVector']]
    assert all(v.shape==raw.shape and np.isfinite(v).all() for v in (clean,rounded,final))
    expected=raw.copy();mask=(expected[nf:]!=0)&(np.abs(expected[nf:])<=1e-9);assert raw[nf:].min()>=-1e-9;expected[nf:][mask]=0
    assert np.array_equal(expected,clean) and np.array_equal(clean[nf:],rounded[nf:])
    assert np.array_equal(rounded[:nf],final[:nf]) and np.all(np.abs(rounded-final)<=2*np.spacing(np.maximum(abs(rounded),abs(final))))
    correction=report['result']['numericalFlowCorrection'];assert correction['changedFlowCount']==int(mask.sum())
    assert correction['positiveChangedFlowCount']==int(((raw[nf:]>0)&mask).sum()) and correction['negativeChangedFlowCount']==int(((raw[nf:]<0)&mask).sum())
    recon=np.zeros(len(final));selected={s['candidateIndex']:s for s in plan['selected']};assert len(selected)==plan['hospitalCount']==228
    assert not(set(selected)&set(report['closedCandidateIndices']))
    minarea=math.inf;staff_bound=max(design['minimumDoctorsPerSite'],math.ceil(float(target)*(rates['contactsPerResident']*scenario['demandMultiplier'])/scenario['contactsPerDoctor']))
    for j,s in selected.items():
        assert type(j)is int and j in local and s['id']==C[j]['id'] and s['footprintRadiusMeters']==C[j]['footprintRadiusMeters']
        t=templates[tid[s['templateId']]];assert type(s['doctors'])is int and design['minimumDoctorsPerSite']<=s['doctors']<=staff_bound
        assert type(s['beds'])is int and s['beds']==t['beds']
        gross=D(t['grossAreaM2'])+D(s['doctors'])*D(design['areaPerDoctorM2']);assert abs(gross-D(s['grossAreaM2']))<=D('.001')
        slack=available[local[j]]-float(gross);assert slack>=-.001;minarea=min(minarea,slack)
        recon[prefix_index[local[j],tid[s['templateId']]]]=1;recon[nx+local[j]]=s['doctors']
    assert np.array_equal(recon[:nf],final[:nf])
    assert sum(s['beds'] for s in selected.values())==plan['totalBeds']==31000 and sum(s['doctors'] for s in selected.values())==plan['totalDoctors']==23095
    tr=Transformer.from_crs(4326,32636,always_xy=True);points={j:tr.transform(C[j]['lon'],C[j]['lat']) for j in selected};clearance=math.inf
    ordered=list(selected)
    for a,j in enumerate(ordered):
        for k in ordered[:a]:
            gap=math.dist(points[j],points[k])-C[j]['footprintRadiusMeters']-C[k]['footprintRadiusMeters'];assert gap>=-1e-7;clearance=min(clearance,gap)
    maximum={j:D(0) for j in selected};profiles=[];offset=nf;allocation_count=0;matrix_sha={}
    min_doc=D('Infinity');min_bed=D('Infinity');max_target=D(0);max_origin=D(0);min_district=D(100)
    for rec,p in zip(M['matrices'],plan['profiles']):
        blob=(base/rec['file']).read_bytes();assert SHA(blob)==rec['sha256'];matrix_sha[rec['file']]=SHA(blob)
        with np.load(io.BytesIO(blob),allow_pickle=False) as z:matrix=z['minutes']
        sub=matrix[:,pool];oi,sj=np.where(np.isfinite(sub)&(sub<=45));index={(int(i),pool[int(j)]):offset+k for k,(i,j) in enumerate(zip(oi,sj))};offset+=len(oi)
        served=[D(0) for _ in pop];loads={j:D(0) for j in selected};seen=set();person_minutes=D(0)
        for a in p['allocations']:
            i,j=a['demandIndex'],a['candidateIndex'];assert type(i)is int and type(j)is int and (i,j) in index and (i,j) not in seen and j in selected
            mass=D(a['population']);assert mass>0 and math.isfinite(a['population']);minutes=float(matrix[i,j]);assert math.isfinite(minutes) and minutes<=45 and abs(minutes-a['minutes'])<=1e-6
            seen.add((i,j));served[i]+=mass;loads[j]+=mass;person_minutes+=mass*D(minutes);recon[index[i,j]]=float(a['population'])/1000
        allocation_count+=len(seen);mass=sum(served);error=abs(mass-target);assert error<=D('.001');max_target=max(max_target,error)
        overshoot=max((served[i]-pop[i] for i in range(len(pop))),default=D(0));assert overshoot<=D('.001');max_origin=max(max_origin,overshoot)
        ds=[]
        for did,d in districts.items():
            cov=sum(served[i] for i,x in enumerate(data['demands']) if x['districtId']==did);pct=cov*100/D(d['population']);assert pct>=D('79.999999');min_district=min(min_district,pct);ds.append(dict(id=did,percent=str(pct)))
        docslack=[];bedslack=[]
        for j,s in selected.items():
            dsla=D(s['doctors'])*D(scenario['contactsPerDoctor'])-loads[j]*contact
            bsla=D(s['beds'])*365*D(scenario['bedOccupancy'])/100-loads[j]*bedrate
            assert dsla>=D('-.1') and bsla>=D('-.1');min_doc=min(min_doc,dsla);min_bed=min(min_bed,bsla)
            maximum[j]=max(maximum[j],loads[j])
        assert abs(D(p['coveredPopulation'])-mass)<=D('.001') and abs(D(p['meanMinutes'])-person_minutes/target)<=D('.000001')
        profiles.append(dict(profile=p['profile'],coveredResidents=str(mass),coveragePercent=str(mass*100/total),
            minimumDistrictPercent=str(min(D(d['percent']) for d in ds)),meanMinutes=str(person_minutes/target),allocationCount=len(seen)))
    assert offset==len(final)==145520 and np.array_equal(recon,final)
    for j,s in selected.items():assert abs(maximum[j]-D(s['maximumAssignedPopulationAcrossProfiles']))<=D('.001')
    r=D(eco['realDiscountRate']);years=D(eco['horizonYears']);annuity=r/(1-(1+r)**(-years)) if r else 1/years
    construction=sum(D(s['grossAreaM2']) for s in selected.values())*D(eco['buildingUnitCostTRY'])
    operating=sum(D(scenario['operatingCostMultiplier'])*(D(eco['annualFixedSiteCostTRY'])+D(s['beds'])*D(eco['annualBedSupportCostTRY'])+D(s['doctors'])*D(eco['annualDoctorCostTRY'])) for s in selected.values())
    material=target*contact*D(eco['costPerContactTRY'])*D(scenario['operatingCostMultiplier']);annual=construction*annuity+operating+material
    assert abs(annual-D(plan['annualEquivalentCostTRY']))<D('.001') and abs(material-D(plan['annualMaterialCostTRY']))<D('.001')
    budget=D(cert['budget']['limitTRY']);assert annual<=budget
    assert [p['profile'] for p in source['plan']['profiles']]==names[:4] and source['plan']['profiles']==plan['profiles'][:4]
    for a,b in zip(source['plan']['selected'],plan['selected']):assert {k:v for k,v in a.items() if k!='maximumAssignedPopulationAcrossProfiles'}=={k:v for k,v in b.items() if k!='maximumAssignedPopulationAcrossProfiles'}
    assert source['plan']['annualEquivalentCostTRY']==plan['annualEquivalentCostTRY'] and meta['full44CertificateSHA256']==SHA(files['full44-seed-plan.json'])
    assert meta['repairReportSHA256']==SHA(files['repair-result.json']) and meta['repairVectorSHA256']==SHA(files['vectors.npz']) and meta['projectionSHA256']==SHA(files['canonical-four-source.json'])
    assert all((folder/n).read_bytes()==b for n,b in files.items()) and (base/'manifest.json').read_bytes()==manifest_bytes
    for p,h in report['modelCodeSHA256'].items():assert SHA((ROOT/p).read_bytes().replace(b'\r\n',b'\n'))==h
    out=dict(status='accepted_within_stored_44_profile_model',builtAt=datetime.now(timezone.utc).isoformat(),auditCodeLF_SHA256=SHA(Path(__file__).read_bytes().replace(b'\r\n',b'\n')),
        artifactSHA256={n:SHA(b) for n,b in files.items()},sourceSHA256=report['sourceSHA256'],modelCodeSHA256=report['modelCodeSHA256'],matrixSHA256=matrix_sha,
        candidatePoolCount=312,selectedHospitalCount=228,beds=31000,doctors=23095,profileCount=44,allocationCount=allocation_count,
        exactReconstructedFinalVector=True,roundedFlowSuffixEqualsCleanedLP=True,tinySnapCount=int(mask.sum()),
        tinySnapMaximumResidents=float(np.abs((clean-raw)[nf:]).max()*1000),tinySnapTotalAcrossProfilesResidents=float(np.abs((clean-raw)[nf:]).sum()*1000),
        maximumProvinceTargetAbsoluteErrorResidents=str(max_target),maximumOriginPopulationOvershootResidents=str(max_origin),minimumDistrictPercent=str(min_district),
        minimumDoctorContactSlack=str(min_doc),minimumBedDaySlack=str(min_bed),minimumAreaSlackM2=minarea,minimumPlotClearanceMeters=clearance,
        decimalAnnualEquivalentCostTRY=str(annual),decimalMaterialCostTRY=str(material),decimalBudgetSlackTRY=str(budget-annual),profiles=profiles,
        routingCalls=0,nativeSolverCalls=0,scope='Independent complete JSON/NPZ and matrix-edge arithmetic for this 312-pool, 44 stored exact-minute model seed. Original numerical tolerances unchanged. Separate flows may serve different people. No continuous-time/all-day/real-EGO reliability, minimum-count or global-cost-optimum claim. Final unrestricted native run remains a separate artifact/gate.')
    path=ROOT/'work/referees/window312-seed-transport-actual-audit.json'
    with path.open('x',encoding='utf8') as f:json.dump(out,f,ensure_ascii=False,indent=2);f.write('\n')
    print(json.dumps({k:out[k] for k in ['status','selectedHospitalCount','allocationCount','maximumProvinceTargetAbsoluteErrorResidents','maximumOriginPopulationOvershootResidents','minimumDistrictPercent','minimumDoctorContactSlack','minimumBedDaySlack','minimumAreaSlackM2','minimumPlotClearanceMeters','decimalAnnualEquivalentCostTRY','decimalBudgetSlackTRY']}|dict(reportSHA256=SHA(path.read_bytes()))))


if __name__=='__main__':main()
