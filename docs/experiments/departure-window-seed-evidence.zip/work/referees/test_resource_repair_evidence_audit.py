"""Independent projection counterexamples; no routing or native solver."""
from copy import deepcopy
import importlib.util
import io
import json
from pathlib import Path
import sys

import numpy as np
import pytest

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'))
from test_window_plan_audit import window,tiny,update_cost

spec=importlib.util.spec_from_file_location('repair_evidence_audit',Path(__file__).with_name('audit_window_resource_repair_evidence.py'))
e=importlib.util.module_from_spec(spec);spec.loader.exec_module(e)


@pytest.fixture
def projection(window):
    full=window['certificate'];plan=full['plan']
    site=deepcopy(plan['selected'][0]);site.update(candidateIndex=1,id='s1',doctors=1,grossAreaM2=101.,maximumAssignedPopulationAcrossProfiles=20.)
    plan['selected'].append(site)
    # A site is used only outside the canonical four. Its physical resources
    # and cost must survive projection while its canonical maximum becomes 0.
    row=plan['profiles'][8];flow=row['allocations'][0];flow['population']-=20
    row['allocations'].append(dict(demandIndex=flow['demandIndex'],candidateIndex=1,population=20.,minutes=11.))
    row['meanMinutes']+=20/190
    update_cost(full,window['health'])
    part=deepcopy(window['source_cost_certificate']);part['plan']=deepcopy(plan)
    part['plan']['profiles']=part['plan']['profiles'][:4]
    part['plan']['selected'][1]['maximumAssignedPopulationAcrossProfiles']=0.
    inputs={k:v for k,v in window.items() if k!='certificate'}
    return full,part,inputs


def test_projection_retains_unused_resources_and_recomputes_four_profile_maximum(projection):
    full,part,inputs=projection;fa,pa=e.verify_projection(full,part,inputs)
    assert fa['hospitalCount']==pa['hospitalCount']==2 and pa['doctors']==11
    assert e.a.D(fa['decimalAnnualEquivalentCostTRY'])==e.a.D('9260')
    assert part['plan']['selected'][1]['maximumAssignedPopulationAcrossProfiles']==0
    assert full['plan']['selected'][1]['maximumAssignedPopulationAcrossProfiles']==20


def test_fixed_core_preserves_source_template_but_allows_new_sites_and_changed_doctors(projection):
    full,part,inputs=projection;selected=full['plan']['selected'];source=deepcopy(selected[:1])
    source[0]['doctors']-=1
    core=e.template_scope('fixed-core',source,selected,inputs,[0,1,2])
    all_indices=e.template_scope('fixed-all',source,source,inputs,[0,1,2])
    assert core and len(core)<len(all_indices) and set(core)<set(all_indices)
    with pytest.raises(ValueError,match='new site'):
        e.template_scope('fixed-all',source,selected,inputs,[0,1,2])


@pytest.mark.parametrize('kind',['remove_source','beds','template','position','duplicate','mode'])
def test_core_scope_does_not_relax_original_sites(projection,kind):
    full,part,inputs=projection;chosen=full['plan']['selected'];source=deepcopy(chosen[:1]);mode='fixed-core'
    if kind=='remove_source':chosen.pop(0)
    elif kind=='beds':chosen[0]['beds']+=1
    elif kind=='template':chosen[0]['templateId']='different'
    elif kind=='position':chosen[0]['footprintRadiusMeters']+=1
    elif kind=='duplicate':chosen.append(deepcopy(chosen[0]))
    else:mode='unrestricted'
    with pytest.raises(ValueError):e.template_scope(mode,source,chosen,inputs,[0,1,2])


def test_upgrade_scope_allows_bed_template_changes_but_preserves_source_location(projection):
    full,part,inputs=projection;chosen=full['plan']['selected'];source=deepcopy(chosen[:1])
    chosen[0]['beds']+=100;chosen[0]['templateId']='larger-for-scope-only'
    rule=e.upgrade_scope(source,chosen,inputs,[0,1,2])
    assert rule['mandatoryLocalIndices']==[0] and rule['minimumBeds']==[source[0]['beds']]
    assert rule['mandatoryCandidateIndices']==[0]
    with pytest.raises(ValueError):e.template_scope('fixed-core',source,chosen,inputs,[0,1,2])


@pytest.mark.parametrize('kind',['fewer_beds','closed_source','moved_source','duplicate'])
def test_upgrade_scope_rejects_relaxing_mandatory_location_or_beds(projection,kind):
    full,part,inputs=projection;chosen=full['plan']['selected'];source=deepcopy(chosen[:1])
    if kind=='fewer_beds':chosen[0]['beds']-=1
    elif kind=='closed_source':chosen.pop(0)
    elif kind=='moved_source':chosen[0]['footprintRadiusMeters']+=1
    else:chosen.append(deepcopy(chosen[0]))
    with pytest.raises(ValueError):e.upgrade_scope(source,chosen,inputs,[0,1,2])


def test_lp_rounding_location_scope_allows_resource_changes_only(projection):
    full,part,inputs=projection;source=deepcopy(full['plan']['selected']);chosen=full['plan']['selected']
    chosen[0]['beds']-=1;chosen[0]['templateId']='smaller';chosen[0]['doctors']+=1
    e.location_scope(source,chosen)
    chosen.pop()
    with pytest.raises(ValueError):e.location_scope(source,chosen)


def test_lp_to_rounded_to_json_links_allow_fractional_resources_but_no_changed_flows():
    raw=np.array([.4,1.9,.1,.2]);rounded=np.array([1.,2.,.1,.2]);final=rounded.copy()
    e.verify_rounding_links(raw,rounded,final,2)
    final[2]=np.nextafter(final[2],np.inf)
    e.verify_rounding_links(raw,rounded,final,2)


@pytest.mark.parametrize('kind',['changed_assignment','changed_integer','noninteger','negative','nan','large_json_change'])
def test_lp_rounding_vector_counterexamples_rejected(kind):
    raw=np.array([.4,1.9,.1,.2]);rounded=np.array([1.,2.,.1,.2]);final=rounded.copy()
    if kind=='changed_assignment':rounded[2]=np.nextafter(rounded[2],np.inf)
    elif kind=='changed_integer':final[0]=0
    elif kind=='noninteger':rounded[0]=final[0]=.5
    elif kind=='negative':raw[2]=rounded[2]=final[2]=-.1
    elif kind=='nan':raw[0]=np.nan
    else:final[2]+=1e-10
    with pytest.raises(ValueError):e.verify_rounding_links(raw,rounded,final,2)


@pytest.mark.parametrize('kind',['relabel','reorder','change_flow','drop_unused','change_doctor','change_template',
    'copy_full_maximum','changed_site_order','annual_cost','material','wrong_count','unknown_profile'])
def test_projection_counterexamples_fail(projection,kind):
    full,part,inputs=projection;plan=part['plan']
    if kind=='relabel':plan['profiles'][0]['profile']='weekday-0805'
    elif kind=='reorder':plan['profiles'].reverse()
    elif kind=='change_flow':plan['profiles'][0]['allocations'][0]['population']+=1
    elif kind=='drop_unused':plan['selected'].pop()
    elif kind=='change_doctor':plan['selected'][1]['doctors']+=1
    elif kind=='change_template':plan['selected'][1]['templateId']='other'
    elif kind=='copy_full_maximum':plan['selected'][1]['maximumAssignedPopulationAcrossProfiles']=20.
    elif kind=='changed_site_order':plan['selected'].reverse()
    elif kind=='annual_cost':plan['annualEquivalentCostTRY']+=.001
    elif kind=='material':plan['annualMaterialCostTRY']*=4
    elif kind=='wrong_count':plan['hospitalCount']=1
    else:plan['profiles'][0]['profile']='made-up'
    with pytest.raises((ValueError,KeyError)):e.verify_projection(full,part,inputs)


@pytest.fixture
def correction():
    raw=np.array([.4,1.9,-1e-12,.2,.1,-1e-10]);clean=raw.copy();clean[[2,5]]=0
    record=dict(allowedNegativeThresholdThousandResidents=1e-10,changedFlowCount=2,
        maximumCorrectionResidents=1e-7,totalCorrectionResidents=1.01e-7,
        positiveFlowEntriesPreserved=True,resourcePrefixPreserved=True,rawFlowEntriesPreserved=False,
        originalRelaxedConstraintsRevalidated=True,mostNegativeRawFlowThousandResidents=-1e-10,
        totalIsSumAcrossProfilesNotUniqueResidents=True,profiles=[
            dict(profile='first',changedFlowCount=1,totalCorrectionResidents=1e-9,maximumCorrectionResidents=1e-9),
            dict(profile='second',changedFlowCount=1,totalCorrectionResidents=1e-7,maximumCorrectionResidents=1e-7)])
    return raw,clean,record,2,[('first',2,4),('second',4,6)]


def test_bounded_negative_correction_has_explicit_exact_chain_and_marginal_units(correction):
    summary=e.verify_flow_correction(*correction,True)
    assert summary['changedFlowCount']==2 and summary['totalCorrectionResidents']==pytest.approx(1.01e-7)
    assert not summary['rawFlowEntriesPreserved']


@pytest.mark.parametrize('kind',['larger_negative','positive_drop','resource_change','negative_remains','metadata_count',
    'metadata_bool_count','metadata_total','metadata_max','metadata_raw_claim','metadata_threshold','metadata_validated',
    'profile_order','profile_total','profile_count','nan','wrong_shape','unknown_field'])
def test_correction_does_not_silently_change_positive_flow_resources_or_evidence(correction,kind):
    raw,clean,record,nf,slices=correction
    if kind=='larger_negative':raw[2]=-1.0001e-10
    elif kind=='positive_drop':clean[3]=0
    elif kind=='resource_change':clean[0]+=1e-10
    elif kind=='negative_remains':clean[2]=-1e-12
    elif kind=='metadata_count':record['changedFlowCount']=1
    elif kind=='metadata_bool_count':record['changedFlowCount']=True
    elif kind=='metadata_total':record['totalCorrectionResidents']+=1e-10
    elif kind=='metadata_max':record['maximumCorrectionResidents']+=1e-10
    elif kind=='metadata_raw_claim':record['rawFlowEntriesPreserved']=True
    elif kind=='metadata_threshold':record['allowedNegativeThresholdThousandResidents']=1e-8
    elif kind=='metadata_validated':record['originalRelaxedConstraintsRevalidated']=False
    elif kind=='profile_order':record['profiles'].reverse()
    elif kind=='profile_total':record['profiles'][0]['totalCorrectionResidents']+=1e-10
    elif kind=='profile_count':record['profiles'].pop()
    elif kind=='nan':raw[0]=np.nan
    elif kind=='wrong_shape':raw=raw[:-1]
    else:record['globalMinimumProven']=True
    with pytest.raises(ValueError):e.verify_flow_correction(raw,clean,record,nf,slices,True)


def test_correction_retains_failed_relaxed_validation_as_false(correction):
    raw,clean,record,nf,slices=correction
    record['originalRelaxedConstraintsRevalidated']=False
    e.verify_flow_correction(raw,clean,record,nf,slices,False)


def test_branch_threshold_is_explicit_not_inherited_by_earlier_artifact(correction):
    raw,clean,record,nf,slices=correction
    record['allowedNegativeThresholdThousandResidents']=1e-9
    e.verify_flow_correction(raw,clean,record,nf,slices,True,1e-9)
    with pytest.raises(ValueError):e.verify_flow_correction(raw,clean,record,nf,slices,True)


def test_branch_exact_closure_bindings_and_final_selection():
    result=dict(closedCandidateIndices=[2],branchRestrictionRemovedForFinalFullSearch=True,
        nativePrimalFeasibilityTolerance=1e-9,nativeDualFeasibilityTolerance=1e-9)
    e.verify_branch_closures([2],[0,1,2],result,{'closedCandidateIndices':[2]},[{'candidateIndex':0}])
    with pytest.raises(ValueError):
        e.verify_branch_closures([2],[0,1,2],result,{'closedCandidateIndices':[2]},[{'candidateIndex':2}])


@pytest.mark.parametrize('kind',['bool','duplicate','unsorted','outside_pool','freeze','result','tolerance','scope'])
def test_branch_provenance_cannot_be_silently_changed(kind):
    closed=[1,2];result=dict(closedCandidateIndices=closed.copy(),branchRestrictionRemovedForFinalFullSearch=True,
        nativePrimalFeasibilityTolerance=1e-9,nativeDualFeasibilityTolerance=1e-9)
    freeze={'closedCandidateIndices':closed.copy()}
    if kind=='bool':closed=[True,2]
    elif kind=='duplicate':closed=[1,1,2]
    elif kind=='unsorted':closed=[2,1]
    elif kind=='outside_pool':closed=[1,3]
    elif kind=='freeze':freeze['closedCandidateIndices']=[1]
    elif kind=='result':result['closedCandidateIndices']=[1]
    elif kind=='tolerance':result['nativePrimalFeasibilityTolerance']=1e-7
    else:result['branchRestrictionRemovedForFinalFullSearch']=False
    with pytest.raises(ValueError):e.verify_branch_closures(closed,[0,1,2],result,freeze)


@pytest.fixture
def sparse_weights(window):
    cert=window['certificate'];inputs={k:v for k,v in window.items() if k!='certificate'}
    v,_=e.a.reconstruct_saved_vector(cert,inputs);archive=io.BytesIO()
    np.savez_compressed(archive,rawContinuousSolverVector=v,continuousRelaxationVector=v);blob=archive.getvalue()
    report={key:deepcopy(cert[key]) for key in ('profileManifestSHA256','sourceSHA256','modelCodeSHA256')}
    report.update(candidateIndices=[0,1,2],closedCandidateIndices=[2],vectorSHA256=e.a.sha256(blob))
    prior=json.dumps(report).encode();refs={e.WEIGHT_REPORT:prior,e.WEIGHT_VECTORS:blob}
    report['openingWeightSource']=dict(report=e.WEIGHT_REPORT,reportSHA256=e.a.sha256(prior),vectors=e.WEIGHT_VECTORS,
        vectorsSHA256=e.a.sha256(blob),rawOpeningMass=[1.,0.,0.],usedOpeningMass=[1.,0.,0.],numericalMassClampOnlyForHeuristicWeights=True)
    objective=dict(kind='reweighted_opening_L1',alpha=.25,openingMassOffset=.05,calibratedClinicalParameter=False,
        representsActualAnnualCost=False,canSupportOriginalCostLowerBound=False,originalBudgetRowUnchanged=True,
        originalPhysicianCoefficientsUnchanged=True,siteWeights=[dict(candidateIndex=j,sourceOpeningMass=mass,
            minimumOriginalTemplateCostScaled=1.,addedCostScaledPerTemplate=.25/(mass+.05)) for j,mass in enumerate((1.,0.,0.))])
    result=dict(heuristicObjective=objective,continuousRelaxationPrimalValidated=True,
        nativeOptimalityScope='Penalized continuous branch LP only; never original annual-cost or integer optimum',
        originalAnnualCostOfContinuousPrimalTRY=6050.,penalizedLPObjectiveScaled=1.7+.25/1.05)
    return report,result,dict(sparseOpeningAlpha=.25,openingMassOffset=.05),refs,inputs,blob


def test_sparse_weights_independent_cost_basis_and_raw_mass(sparse_weights):
    result=e.verify_sparse_weights(*sparse_weights)
    assert result['weightCount']==3 and result['originalAnnualCostAndPenaltyKeptSeparate']


@pytest.mark.parametrize('kind',['mass','penalty','candidate','annual','penalized','scope','original_objective_name','source_sha'])
def test_sparse_objective_evidence_tamper_rejected(sparse_weights,kind):
    report,result,freeze,refs,inputs,blob=sparse_weights
    if kind=='mass':report['openingWeightSource']['usedOpeningMass'][0]=.9
    elif kind=='penalty':result['heuristicObjective']['siteWeights'][0]['addedCostScaledPerTemplate']+=.1
    elif kind=='candidate':result['heuristicObjective']['siteWeights'][0]['candidateIndex']=2
    elif kind=='annual':result['originalAnnualCostOfContinuousPrimalTRY']+=2
    elif kind=='penalized':result['penalizedLPObjectiveScaled']+=.01
    elif kind=='scope':result['heuristicObjective']['canSupportOriginalCostLowerBound']=True
    elif kind=='original_objective_name':result['continuousLPObjectiveTRY']=6050
    else:report['openingWeightSource']['reportSHA256']='a'*64
    with pytest.raises(ValueError):e.verify_sparse_weights(report,result,freeze,refs,inputs,blob)


@pytest.fixture
def signed_snap():
    raw=np.array([.4,1.9,-1e-10,1e-10,2e-9,0.]);clean=raw.copy();clean[2:4]=0
    stats=dict(changedFlowCount=2,negativeChangedFlowCount=1,positiveChangedFlowCount=1,
        positiveRemovedTotalResidents=1e-7,negativeAddedTotalResidents=1e-7,
        positiveRemovedMaximumResidents=1e-7,negativeAddedMaximumResidents=1e-7,
        maximumCorrectionResidents=1e-7,totalCorrectionResidents=2e-7,totalSignedCorrectionResidents=0.)
    empty={k:0 if k.endswith('Count') else 0. for k in stats}
    record=dict(stats,allowedNegativeThresholdThousandResidents=1e-9,allowedAbsoluteSnapThresholdThousandResidents=1e-9,
        flowSnapPolicy='Nonzero flow with absolute value at most threshold becomes zero; original target and all validation tolerances unchanged',
        positiveFlowEntriesPreserved=False,allRemainingPositiveFlowEntriesPreserved=True,resourcePrefixPreserved=True,
        rawFlowEntriesPreserved=False,originalRelaxedConstraintsRevalidated=True,mostNegativeRawFlowThousandResidents=-1e-10,
        totalIsSumAcrossProfilesNotUniqueResidents=True,profiles=[dict(profile='first',**stats),dict(profile='second',**empty)])
    return raw,clean,record,2,[('first',2,4),('second',4,6)]


def test_two_sided_snap_preserves_signed_and_absolute_accounting(signed_snap):
    result=e.verify_signed_flow_snap(*signed_snap,True)
    assert result['totalSignedCorrectionResidents']==0 and result['totalCorrectionResidents']==pytest.approx(2e-7)
    assert result['positiveChangedFlowCount']==1 and result['positiveFlowEntriesPreserved'] is False


@pytest.mark.parametrize('kind',['remaining_positive','prefix','all_positive_claim','signed_total','absolute_total',
    'positive_total','negative_count','threshold','profile_order','large_negative','new_claim'])
def test_two_sided_snap_does_not_hide_changes_or_scope(signed_snap,kind):
    raw,clean,record,nf,slices=signed_snap
    if kind=='remaining_positive':clean[4]=0
    elif kind=='prefix':clean[0]+=1e-10
    elif kind=='all_positive_claim':record['positiveFlowEntriesPreserved']=True
    elif kind=='signed_total':record['totalSignedCorrectionResidents']=2e-7
    elif kind=='absolute_total':record['totalCorrectionResidents']=0
    elif kind=='positive_total':record['positiveRemovedTotalResidents']=0
    elif kind=='negative_count':record['negativeChangedFlowCount']=True
    elif kind=='threshold':record['allowedAbsoluteSnapThresholdThousandResidents']=1e-8
    elif kind=='profile_order':record['profiles'].reverse()
    elif kind=='large_negative':raw[2]=-1.01e-9
    else:record['samePeoplePreserved']=True
    with pytest.raises(ValueError):e.verify_signed_flow_snap(raw,clean,record,nf,slices,True)


@pytest.fixture
def expanded_weights(sparse_weights,window):
    report,result,freeze,refs,inputs,blob=sparse_weights
    old_cert=deepcopy(window['certificate']);old_cert['generation']['candidateIndices']=[0,2]
    old_vector,_=e.a.reconstruct_saved_vector(old_cert,inputs)
    archive=io.BytesIO();np.savez_compressed(archive,rawContinuousSolverVector=old_vector);old_blob=archive.getvalue()
    prior=json.loads(refs[e.WEIGHT_REPORT]);prior.update(candidateIndices=[0,2],closedCandidateIndices=[401,1495,1679],
        vectorSHA256=e.a.sha256(old_blob))
    prior_blob=json.dumps(prior).encode();refs={e.EXPANDED_WEIGHT_REPORT:prior_blob,e.EXPANDED_WEIGHT_VECTORS:old_blob,
        e.POOL:json.dumps({'candidateIndices':[0,2]}).encode()}
    report['openingWeightSource']=dict(report=e.EXPANDED_WEIGHT_REPORT,reportSHA256=e.a.sha256(prior_blob),
        vectors=e.EXPANDED_WEIGHT_VECTORS,vectorsSHA256=e.a.sha256(old_blob),rawOpeningMass=[1.,None,0.],usedOpeningMass=[1.,1.,0.],
        sourceCandidateIndices=[0,2],newlyInitializedCandidateIndices=[1],newCandidateInitialization=dict(value=1.,kind='heuristic_initialization_not_observed'),
        numericalMassClampOnlyForHeuristicWeights=True)
    freeze.update(sparseOpeningAlpha=2.,openingMassOffset=.005)
    result['heuristicObjective'].update(alpha=2.,openingMassOffset=.005,siteWeights=[dict(candidateIndex=j,sourceOpeningMass=mass,
        minimumOriginalTemplateCostScaled=1.,addedCostScaledPerTemplate=2/(mass+.005)) for j,mass in enumerate((1.,1.,0.))])
    result['penalizedLPObjectiveScaled']=1.7+2/1.005
    return report,result,freeze,refs,inputs,blob


def test_expanded_old_layout_global_identity_and_new_unobserved_weights(expanded_weights):
    result=e.verify_sparse_weights(*expanded_weights,strong=True,expanded=True)
    assert result['observedWeightCount']==2 and result['weightCount']==3
    assert result['newlyInitializedCandidateIndices']==[1]


@pytest.mark.parametrize('kind',['invented_observation','mapped_by_local_index','wrong_new_ids','initialization_claim','old_pool','old_branch'])
def test_expanded_weight_source_tampering_rejected(expanded_weights,kind):
    report,result,freeze,refs,inputs,blob=expanded_weights;source=report['openingWeightSource']
    if kind=='invented_observation':source['rawOpeningMass'][1]=1.
    elif kind=='mapped_by_local_index':source['usedOpeningMass']=[1.,0.,1.]
    elif kind=='wrong_new_ids':source['newlyInitializedCandidateIndices']=[2]
    elif kind=='initialization_claim':source['newCandidateInitialization']['kind']='observed'
    elif kind=='old_pool':source['sourceCandidateIndices']=[0,1]
    else:
        prior=json.loads(refs[e.EXPANDED_WEIGHT_REPORT]);prior['closedCandidateIndices']=[2]
        refs[e.EXPANDED_WEIGHT_REPORT]=json.dumps(prior).encode();source['reportSHA256']=e.a.sha256(refs[e.EXPANDED_WEIGHT_REPORT])
    with pytest.raises(ValueError):e.verify_sparse_weights(report,result,freeze,refs,inputs,blob,True,True)
