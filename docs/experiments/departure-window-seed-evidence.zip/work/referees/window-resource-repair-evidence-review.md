# Kaynak onarımı: bağımsız kanıt denetimi

Bu not `fixed223-v1` deneyinin kimlik ve iddia kapsamı denetimidir. Başarılı bir 44 profil planı veya hastane sayısı onayı değildir.

## Donmuş kod kapısı

- Deney kodu LF SHA-256: `6b214ebe2c159a050274c5508854beb870df56fd44b48e2bc6758fefc4a07842`.
- Freeze SHA-256: `03ab842e1eb8678069f83023c2e1ebff5c05edc61ffe93f150961b5e95a73c0e`.
- 23 deney testi ile 20 bağımsız projeksiyon/kısıt kapsamı testi: **43 geçti**. Bağımsız testler yeni gerçek Ankara çözümü çalıştırmadı.
- Gerçek 273 aday / 44 profil hazırlık denetimi native çözüm çağırmadan geçti. 14 üretim kodu değişmedi.

## `fixed223-v1`: sonuçsuz deney

Rapor SHA-256: `1f6b26da811f826677966d819701c95b1e266a3fddde07e25c8ca255b2c8e6aa`.
Boş vektör arşivi SHA-256: `8739c76e681f900923b900c9df0ef75cf421d39cabb54650c4b9ad19b6a76d85`.

İlk 12 profilin kaynak planındaki 223 yer ve hastane şablonu korunmuş; 273 adayın 1.406 şablon ikilisi sabitlenmiştir. Hekim sayıları ve 44 profilin hasta atamaları serbesttir. Native çözümleyici yaklaşık 55,58 saniyede `kInfeasible` bildirmiştir. İşçi 65,125 saniyede kapanmıştır.

Bağımsız dosya denetimi 9 güncel kaynak, 14 kod, 7 önceki deney kaynağı ve 44 matris manifesti bağlarını doğrulamıştır. Sonuç `feasible: null` olarak kalır. Atama vektörü, tam 44 profil sertifikası ve dört profil projeksiyonu üretilmemiştir. Native durumu bağımsız bir imkânsızlık sertifikası değildir; sabitlenmiş bu şablonların dışındaki yerleşimler hakkında sonuç vermez.

Makine tarafından okunabilir bağımsız kayıt: `window-resource-repair-fixed-all-evidence-audit.json`.

## Sonraki `fixed-core` deneyinin ayrı kapısı

Root tarafından ayrıca yetkilendirilen `fixed-core` kapsamı, kaynak 223 yerin kendi şablonlarını ve yatak sayılarını korur; havuzdaki kalan 50 yerde yeni şablon seçimine izin verir. Bağımsız denetçi sabitlenmiş ikili sütunları parsel alanı ve şablon uygunluğundan yeniden kurar. Kaynak yerlerin silinmesini veya şablonlarının değiştirilmesini reddeder. Yeni yerler yalnız bu kapsamda kabul edilebilir. Hekimlerin değiştirilmesi ayrıca kapasite, alan ve tek yıllık Decimal maliyet denetimine tabidir.

Başarı elde edilirse 44 akışın tamamı, il/ilçe hedefleri, 45 dakika matrisi, ayrı yatak/hekim kapasitesi, çakışmayan parseller ve eski yıllık bütçe yeniden denetlenir. Dört profil projeksiyonu yalnız ilgili dört akışı aynen seçer; tüm kaynakları ve yıllık faturayı korur, dört profile ait azami yükleri yeniden toplar. Dört profil için ayrı bir native arama yapıldığı söylenmez. Bu projeksiyon ve tam 44 profil sonucu birbirine gerçek dosya hashleriyle bağlanır.

Bu deneyler nihai serbest yer/şablon aramasının yerine geçmez. Genel optimum, en az hastane sayısı, bütün gün veya gerçek klinik/ulaşım yeterliliği iddiası yoktur.

## `core223-v1`: süre sınırında sonuçsuz deney

Rapor SHA-256: `4584239124707f9f3987782e4936a51ef3c2cebe50d21a4850970e45522bb132`.
Vektör arşivi yine boştur: `8739c76e681f900923b900c9df0ef75cf421d39cabb54650c4b9ad19b6a76d85`.

Bağımsız yeniden kurulum, 223 kaynak yerin 1.084 şablon sütununun sabitlendiğini doğrulamıştır. 273 adaylık havuzdaki diğer 50 yerin şablonları serbest kalır. İşçi 309,719 saniyede tamamlanmıştır; native durum `kTimeLimit` ve `nativeReportedInfeasible: false` değerindedir. `feasible: null` korunmuştur. Tam 44 profil sertifikası veya dört profil projeksiyonu yoktur.

9 güncel kaynak, 14 kod, 7 önceki kaynak ve matris manifesti bağları geçmiştir. Bu kayıt süre sınırında geçerli plan bulunamadığını gösterir; bu havuzun veya Ankara'nın imkânsızlığına ilişkin kanıt değildir. Bağımsız kayıt: `window-resource-repair-core-evidence-audit.json`.

## `upgrade223-v1`: yatak büyütmeye izin veren sonuçsuz deney

Rapor SHA-256: `bcac1d9ba082977602b762fc9edccab1731753d6b81a521f96e5d4abab84b319`.
Kod LF SHA-256: `725d487b49447000ea4c3e6ed47a9a953678ca8dae197843edba272325d975ea`.

Kaynak 223 konum açık kalır; her birinde aynı veya daha fazla yatağa sahip, parsele sığan bir şablon seçilebilir. Kalan 50 aday isteğe bağlıdır. Hekimler yine serbesttir. Ek açılış satırları ve küçük şablon yasakları dışında özgün model korunmuştur. 11 no-native test ayrıca geçmiştir.

310,625 saniyede kapanan işçinin native durumu `kTimeLimit` değeridir. `feasible: null` korunur; boş vektör arşivi, hiçbir 44/4 sertifika ve hiçbir bağımsız imkânsızlık iddiası yoktur. Kaynak ve ek kısıt kimlikleri bağımsız denetlenmiştir: `window-resource-repair-upgrade-evidence-audit.json`.

## `lp223-v1`: sürekli çözüm var, tamsayılı kaynak sertifikası yok

Kod LF SHA-256: `a99789d6777f1a4bae27b88a96582904234d82859e0b5713d8f95690c9048b2d`.
Rapor SHA-256: `cf47ba8fc42d4246a8497cbd6de7b5c1b7a8da7c4f04236c404eea560c6651c5`.
Vektör SHA-256: `4012983270f39f88a44cc870d3154a3276976022c42d6e94b37898e6370d0f2c`.

Bu farklı deney, yalnız kaynak 223 konumu açık tutar; diğer 50 yer kapalıdır. Uygun şablon kararları ve hekim miktarları sürekli LP'de kesirli olabilir. Tamsayılı kaynaklar sonradan her yerin 44 profil arasındaki en büyük gerçek yükünden seçilir. Kaynak yatağın küçültülmesi bu deneyde yasak değildir. Yuvarlanmış kaynaklar özgün model ve kesin Decimal bütçe denetimini geçmeden sertifika oluşturulmaz.

Native LP 45 iterasyon sonunda `Optimal` bildirmiş ve yaklaşık 174,431 milyar TL sürekli amaç değeri kaydedilmiştir. Ancak en az bir yerde oluşan azami yük için tamsayılı yatak/hekim çifti parsele sığmadığından yuvarlama reddedilmiştir. İşçi 26,156 saniyede kapanmıştır. Yalnız sürekli vektör saklanır; tamsayı planı, tam 44 sertifikası ve dört profil projeksiyonu **yoktur**. Sürekli amaç değeri genel yerleşim problemi için alt sınır olarak aktarılmaz.

Bu incelemenin actual kapısı kaynak/çıktı kimliğini, başarısız yuvarlama kapsamını, boş tamsayı/certificate alanlarını ve gerçek `worker.log` hashini kontrol eder. Sürekli vektörün özgün tüm satırları ulaşım hakeminin ayrı sayısal incelemesidir; burada tamsayılı primal doğrulanmış sayılmaz. Bağımsız kayıt: `window-resource-repair-lp-evidence-audit.json`.

## `lp-envelope223-v1`: daha dar başlangıç araması sonuçsuz

Kod LF SHA-256: `af979b03cb255b0891092e67af30679b4307eb1ef1e3753c529b560c04d294d2`.
Rapor SHA-256: `0ed282d03512e94e6679e64bddf68ab2bec659c32936e80ef8dbcac32229c273`.

Her parselde uygun tamsayılı kaynak çiftleri için bir kapasite tavanı hesaplanmış, başlangıç araması için ayrıca 0,001 kişilik iç pay uygulanmıştır. Bu pay özgün tüm geçerli tamsayı çözümlerini korumak zorunda değildir. Yöntem özellikle başlangıç planı üretmek için daha dar bir aramadır; genel imkânsızlık veya genel optimum kanıtı sağlayamaz. İl/ilçe kapsamı, süre eşiği ve bütçe değiştirilmemiştir.

Native LP 19 iterasyon sonunda `Infeasible` bildirmiştir. 19,438 saniyede kapanan deney `feasible: null`, boş vektör arşivi ve hiçbir 44/4 sertifika ile kaydedilmiştir. Kaynak kimliği, 223 parsel kimliği, iç pay hesabı ve kanıt iddiasının sınırları bağımsız denetlenmiştir. Bağımsız kayıt: `window-resource-repair-envelope-evidence-audit.json`. Kapasite tavanı katsayılarının ayrı matematik kontrolü ulaşım hakeminin kapsamındadır.

Son kapıda 33 bağımsız projection/kısıt/vektör testi ile 30 envelope testi birlikte **63 geçti**. Bunlar gerçek 44 profil için geçerli tamsayı planı bulunduğu anlamına gelmez.

## `lp-open273-v1`: sürekli çözücü sonucu var, doğrulanmış primal yok

Kod LF SHA-256: `4c9ce3fe74ba7faf08a9630e176fbfb180834150a56f7f1aa76eacb223057b50`.
Rapor SHA-256: `1acbc9587a1688cb5604f0fdf3ca830f6b51ffec6c5d9d54b5946aec27edb90b`.

Bu deney 273 adayın tamamında açılma/kapanmaya izin verir; tarihsel 223 yer yalnız kaynak bağıdır. Kapasite tavanı açılma şablonlarının toplamıyla çarpılır. Pozitif akış taşıyan yerleri sonradan açan yuvarlama, çakışan parselleri reddeder; hiçbir pozitif akışı silmez. 17 yeni kapsam testi bağımsız tekrarda geçmiştir.

92,141 saniyede kapanan işçinin LP çözücüsü `Optimal` bildirmiştir. Fakat en az bir negatif akış nedeniyle primal kapısı reddetmiştir. Ham vektör bu kapıdan önce saklanmadığından negatif değerin büyüklüğü artık bağımsız doğrulanamaz; ona "çok küçük" veya "zararsız" denemez. Vektör arşivi boştur. Sürekli primal, tamsayılı plan ve 44/4 sertifika yoktur; `feasible: null` korunmuştur.

Kaynak, kod, referans ve süreç/çıktı kimliği denetimi geçmiştir: `window-resource-repair-open-pool-evidence-audit.json`. Sonraki ayrı deneyde açıkça sınırlı sayısal negatiflerin sıfırlanması düşünülebilir; bunun ham→temizlenmiş→yuvarlanmış zincirini saklaması ve temizlenmiş planın özgün hedef/kapasite/bütçe kapılarından yeniden geçmesi gerekir. Bu, v1 için geriye dönük başarı değildir.

## `lp-open273-v2`: ham sayısal artık artık ölçülebiliyor

Kod LF SHA-256: `ee09912b5c9c47ef6f5d52616b424f831ecaee68f319a068b5916a3511fb7192`.
Rapor SHA-256: `197759b2f356ddceb8976ce9cd2574abb6d093c4e5184188bc93992a465cbd2f`.
Ham vektör SHA-256: `2f2310f25edeb11f2b6d12d60f719ebd7158293bf2a4b5dfb08445809ee68688`.

V2 90,172 saniyede kapanmış ve ham sürekli vektörü korumuştur. 1.679 kaynak sütunundan sonraki akışlarda 125 negatif değer vardır. En küçüğü −2,3849100472261853×10⁻⁸ bin kişi; bunları sıfırlamanın toplam etkisi, 44 profil üzerinden 0,0008815714638288341 kişi-eşdeğeridir. Bu toplam benzersiz kişi sayısı değildir. Kaynak önekinde ayrıca 583. indekste −2,2432499129102145×10⁻¹⁰ vardır; akış temizliği bu kaynak değerini değiştirmemelidir.

Belirlenmiş 10⁻¹⁰ bin kişi eşiğini aşan artıklar yüzünden V2 de doğru biçimde reddedilmiş, temiz/tamsayı vektörü ve 44/4 sertifika üretmemiştir. Native `Optimal` kaydı tek başına plan kabulü değildir. Ayrı, hash bağlı ve yeni native arama yapmayan bir yeniden işleme, açıkça ilan edilen farklı sayısal eşiği uygulayabilir; hedefler, özgün satırlar, kapasite/alan, çakışma ve kesin bütçe yeniden doğrulanmadan başarı sayılamaz.

Bağımsız kimlik kaydı: `window-resource-repair-open-pool-v2-evidence-audit.json`. Yeni temizleme zincirine 19 karşıörnek/pozitif test eklendi; bağımsız denetçi toplam 52 testi geçti. Üretici V2'nin 24 odaklı testi de bağımsız tekrarda geçti. Üretim kodları değişmedi.

## `lp-branch273-v1`: sürekli dal planı var, tamsayı sertifikası yok

Kod LF SHA-256: `9fc5926f2e3035b152e28f7f1016bcb2569222e288e409d9bb154e687c35533d`.
Rapor SHA-256: `18c00b46958a48b8a9ea8044e4caf3376be2aad0b8debf65d428ef99caae2530`.
Vektör SHA-256: `296728539be47e812a04357173c1386640d28350374901f8c319b5183e03c410`.

Bu ayrı dal 401, 1495 ve 1679 indeksli adayları kapatır; diğer 270 adayda açılma/kapanma serbesttir. Kapanışlar freeze, komut, rapor ve sonuçta aynı listeyle bağlıdır. Özgün hedefler ve bütçe satırı değişmemiştir. Native primal/dual toleransları ve sınırlı negatif düzeltme eşiği 10⁻⁹ bin kişidir. Coğrafi eleme bir geçerlilik veya optimum kanıtı değildir.

Ham→temizlenmiş zincirde 114 negatif akışın toplam düzeltmesi 1,29730469004521×10⁻⁶ kişi-eşdeğeri, en büyük tek düzeltme 4,4997960912951385×10⁻⁷ kişidir. Pozitif akışlar ve kaynak öneki birebir korunmuştur. Bu toplam yine profil toplamıdır, benzersiz kişi sayısı değildir. Sürekli vektör özgün denetimden geçmiş; tamsayılı kaynaklara yuvarlama son satır denetiminde reddedilmiştir. Bu nedenle geçerli 44 profil planı ve dört profil projeksiyonu yoktur.

Bağımsız kimlik/düzeltme kaydı: `window-resource-repair-branch-evidence-audit.json`. 36 üretici testi ile 62 bağımsız denetçi testi birlikte 98 geçmiştir. Dal sınırları genel Ankara problemi hakkında imkânsızlık veya optimum sonucu vermez. Sonraki amaç fonksiyonu değişikliği yalnız yeni bir başlangıç-planı yöntemi olabilir; özgün maliyet faturası ve bütçesi ayrı korunmalıdır.

## `lp-sparse273-v1`: ek açılış cezası da sertifika üretmedi

Kod LF SHA-256: `8cc8f83fff291b23dbcf11c59312a7253836d1465c9b5b1b9afc561874a28ca4`.
Rapor SHA-256: `ac1b00503312ee71f97c1b2e2e0d6798eea7b97b630c3f30124b03d971c829ba`.
Vektör SHA-256: `fcbe992f0087b7bf267e133fb4e3cfa1d1c790bef4f094c7ed4a27d26d1c3ae2`.

Önceki dalın ham şablon ağırlıklarından 273 adayın açılma toplamı yeniden hesaplanmıştır. Yalnız bu sezgisel ağırlıklar için [0,1] aralığına sınırlama uygulanır. Her uygun şablona eklenen ceza, 0,25 × aynı yerin en küçük özgün şablon katsayısı / (açılma toplamı + 0,05) biçimindedir. Hekim katsayıları, özgün yıllık maliyet/bütçe satırı ve 44 hedef değişmez. Ek ceza gerçek yıllık maliyet veya klinik kalibrasyon değildir.

Bağımsız denetim kaynak ham vektörünü, bütün ağırlıkları, cezayı ve amaçların ayrımını doğrulamıştır: sürekli primalın özgün yıllık maliyeti 139.824.920.440,72916 TL; cezalı amaç 12,965793815602895 ölçekli birimdir. İkincisi bir TL faturası veya özgün maliyet için alt sınır değildir. 147 negatifin düzeltilmesi toplam 0,00006470873384083489 kişi-eşdeğeridir; pozitif akışlar ve kaynak öneki aynıdır.

84,5 saniyede kapanan süreç tamsayılı yuvarlama sonrası özgün satır denetiminde reddedilmiştir. Sonuç `feasible: null`; tam 44/4 sertifikası yoktur. Kayıt: `window-resource-repair-sparse-evidence-audit.json`. 17 üretici odaklı testi ve ek ağırlık/amaç karşıörnekleriyle 71 bağımsız denetçi testi geçmiştir. Bu, model hedeflerini sağlayan bir plan bulunması anlamına gelmez.

## `lp-sparse-strong273-v1`: iki taraflı sayısal düzeltme açık, bütçe başarısı yok

Rapor SHA-256: `dab0bfaaa3ddda394cdf85c9fc703ba91a26fe0f04a19d005a2694a2fca6b572`.
Vektör SHA-256: `a0fef3134006bfc9ff4bde20d04a781b9ec8a708cd48fc70b4a03c4b46237da4`.

Yeni ayrı deneme α=2 ve payda ekini 0,005 seçmiş; önceki gerçek sparse denemesinin ham şablon toplamlarını kullanmıştır. Özgün yıllık fatura ve bütçe ayrı kalır. |Akış| ≤ 10⁻⁹ bin kişi değerleri sıfırlanmış; özgün tüm hedef ve doğrulama toleransları korunmuştur.

Bağımsız ham→temiz karşılaştırmasında 74 pozitif akıştan 0,000032804327049851725 kişi-eşdeğeri çıkarılmış, 76 negatif akış sıfırlanarak 0,000039280593250312634 kişi-eşdeğeri eklenmiştir. Toplam mutlak değişim 0,00007208492030016436; net değişim +0,0000064762662004609066'dır. Bunlar 44 profil üzerinden toplamdır. Tüm pozitiflerin korunduğu iddiası yoktur; kalan akışlar ve kaynak öneki birebir korunur.

Tamsayılı plan yine özgün satır kapısında reddedilmiş; geçerli 44/4 sertifika yoktur. Daha küçük bütçe açığı kabul anlamına gelmez. Kayıt: `window-resource-repair-strong-evidence-audit.json`. Bu kapsam için 22 üretici testi ve 83 bağımsız denetçi testi geçmiştir.

## 312 adaylık yeni havuzun kaynak kapısı

Yeni havuz, önceki 273 adayın tamamını ve 39 ek adayı içerir. Önceki ham vektör 312 sütun düzeninde okunmaz: kendi 273 aday düzeni yeniden kurulur, ağırlıklar global aday kimliğiyle taşınır. Yeni 39 adayın ham gözlemi `null`, sezgisel başlangıç ağırlığı 1'dir. Bu başlangıç değeri gözlenmiş açılma veya ihtiyaç kanıtı değildir.

10 açık kapanış kararı, havuz ve 44 matris manifestine bağlı ayrı kayıttan gelir. Bağımsız denetçi 312 parselin fiziksel çakışma kümesini kaynak koordinatlarından yeniden kurar. Bu dal da genel yerleşim probleminden dardır. Final 312 adayın serbest ortak maliyet araması ve bağımsız 44 hedef/kesin bütçe kapısı ayrıca gerekir. 30 üretici testi ve genişletilmiş 90 bağımsız denetçi testi geçmiştir; bu paragraf gerçek denemenin başarısı hakkında sonuç içermez.

## `lp-expanded312-v1`: bağımsız doğrulanmış tam 44 profil başlangıç planı

Rapor SHA-256: `40403f4a1b1c4b8ffa1bf55abfa9b6f793b5234b389013374559de25da2ad541`.
Vektör SHA-256: `292b6891b3aed315d0253cbf92540e67023ee9b980b07766767b33764551e685`.
Dört profil projeksiyonu SHA-256: `423012737b265e08261728ff990bee03630ebaf36b5f8f8c1f4a8a6632b0bb32`.

**Dar kabul:** 228 konum, 31.000 yatak ve 23.095 hekimle kaydedilen tamsayılı başlangıç planı bağımsız denetimden geçmiştir. Aynı kaynaklar bütün 44 profilde ortaktır. Gerçek matrislerde 45 dakika, il %95 ve 25 ilçenin her birinde %80 hedefleri; ayrı yatak/hekim kapasitesi; mevcut fiziksel alan ve çakışmama koşulları doğrulanmıştır. Bu sayılar hedefleri sağlayan model planını anlatır, gerçek klinik ihtiyaç veya asgari hastane sayısını kanıtlamaz.

Tek yıllık Decimal maliyet `186819886564.106839406380435209886191519005421` TL'dir. Özgün `189556939209.2935` TL bütçeden kalan pay `2737052645.186660593619564790113808480994579` TL'dir. Talep 44 kez fatura edilmemiştir. 273 eski ağırlık kendi kaynak vektörüyle, 39 yeni aday yalnız açık sezgisel başlangıç değeriyle bağlanmıştır. 223 yerli tarihsel kaynak plana göre 44 yer çıkarılmış ve 49 yer eklenmiştir; eski yerlerin korunması bir kısıt değildir.

Ham→temizlenmiş zincirde 68 pozitif küçük akıştan 0,000026613384752230226 kişi-eşdeğeri çıkarılmış; 78 negatif akışın sıfırlanması 0,000049413743645107355 kişi-eşdeğeri eklemiştir. Kalan akışlar ve kaynak öneki birebir, temizlenmiş→yuvarlanmış akışlar birebir korunmuştur. Son yayımlanabilir JSON ile NPZ son vektörü bağımsız yeniden kurulumda aynıdır. Özgün tüm doğrulama toleransları değiştirilmemiştir.

Dört profil projeksiyonu yalnız ilgili dört akışı aynen seçer; tüm 228 kaynağı ve aynı yıllık faturayı korur. Ayrı dört profil native çözüm yapıldığı iddiası yoktur. Bağımsız çıktı `window-resource-repair-expanded312-evidence-audit.json` içindedir. Bu kabul başlangıç planıyla sınırlıdır: nihai 312 adayın serbest özgün maliyet aramasını, genel optimumu, minimum hastane sayısını, örneklenmeyen saatleri veya gerçek şehir/klinik yeterliliği onaylamaz.
