"""Focused all-pool LP opening, closed-site and conflict regressions."""
from copy import deepcopy
import importlib.util
from pathlib import Path
from types import SimpleNamespace
import sys
import numpy as np
import pytest
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'));sys.path.insert(0,str(Path(__file__).parent))
from test_window_seed import tiny,fixed_plan
from test_joint_model import fixture
from backend.window_model import build_window_problem
spec=importlib.util.spec_from_file_location('lp_open_pool_repair_v2_work',Path(__file__).with_name('window-lp-open-pool-repair-v2.py'))
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)


def make_all(sites=2,conflicts=()):
    _,source,_,args=fixture(sites_count=sites,scenario={'coverageTarget':95,'districtFloor':80})
    args=list(deepcopy(args));args[0]={f'clock-{i:02d}':np.ones((2,sites)) for i in range(44)}
    full=build_window_problem(*args,conflicts=conflicts,annual_budget=100)
    v=full.fixed_resource_vector(source)
    for name,(oi,sj) in full.edges.items():
        for i in range(2):v[full.offsets[name]+np.flatnonzero((oi==i)&(sj==i))[0]]=.00095
    return full,full.serialize(v)


def test_only_integrality_and_opening_coupled_capacity_rows_change():
    full,subset,source,_=tiny();source=fixed_plan(subset(list(full.times)[:12]),source,both=False)
    before=r.signature(full);q,prefix,eligible=r.restrict_templates(full,source)
    assert r.signature(full)==before and eligible.tolist()==list(range(full.m))
    assert not q.model[1].any()
    for k in (0,2,3):assert q.model[k] is full.model[k]
    nr=full.model[4].shape[0]
    for k in (5,6):np.testing.assert_array_equal(q.model[k][:nr],full.model[k])
    np.testing.assert_array_equal(q.model[4][:nr].toarray(),full.model[4].toarray())
    row=nr
    for name,(oi,sj) in full.edges.items():
        for record in q.integer_capacity_limits:
            j=record['localIndex'];es=np.flatnonzero(sj==j)
            if not len(es):continue
            expected=np.zeros(len(full.c));expected[full.offsets[name]+es]=1
            expected[full.site_xs[j]]=-record['workingCapacityThousandResidents']
            np.testing.assert_array_equal(q.model[4][row].toarray()[0],expected)
            assert q.model[5][row]==-np.inf and q.model[6][row]==0;row+=1
    assert row==q.model[4].shape[0]
    assert q.material==full.material and q.annual_budget==full.annual_budget


def test_native_can_open_previously_closed_site_at_new_clock():
    full,subset,source,_=tiny();source=fixed_plan(subset(list(full.times)[:12]),source,both=False)
    result,vectors,plan=r.repair(full,source,3)
    assert result['feasible'] and plan['hospitalCount']==2 and source['hospitalCount']==1
    assert plan['totalBeds']==plan['totalDoctors']==2
    assert plan['annualEquivalentCostTRY']==pytest.approx(25.5)
    assert result['fixedSourceLocations'] is False and result['locationsMayOpenOrClose']
    assert result['sourcePlanUsedOnlyForProvenance']
    assert not result['nativeIntegerSearchPerformed'] and result['minimumAnnualCostLowerBoundTRY'] is None
    np.testing.assert_array_equal(vectors['continuousRelaxationVector'][full.nf:],vectors['roundedOriginalVector'][full.nf:])
    np.testing.assert_array_equal(full.read_plan(result)[0],vectors['finalOriginalVector'])


def test_source_open_location_can_close_when_all_its_flow_is_zero():
    full,source=make_all();raw=full.fixed_resource_vector(source);raw[:full.nf]=0
    raw[full.site_xs[0][1]]=1;raw[full.nx]=2
    for name,(oi,sj) in full.edges.items():
        for i in range(2):raw[full.offsets[name]+np.flatnonzero((oi==i)&(sj==0))[0]]=.00095
    def supplied(*args):return SimpleNamespace(status=0,x=raw,message='synthetic checked continuous primal',nit=0)
    result,vectors,plan=r.repair(full,source,3,solve=supplied)
    assert result['feasible'] and source['hospitalCount']==2 and plan['hospitalCount']==1
    assert plan['selected'][0]['candidateIndex']==0 and plan['annualEquivalentCostTRY']==pytest.approx(24.5)
    assert result['numericallyCleanedFlowAssignmentsPreservedDuringRounding']


def conflict_fractional():
    full,source=make_all(sites=3,conflicts=((1,2),));raw=np.zeros(len(full.c))
    for j in (1,2):raw[full.site_xs[j][1]]=.5;raw[full.nx+j]=1
    for name,(oi,sj) in full.edges.items():
        for i,j in ((0,1),(1,2)):raw[full.offsets[name]+np.flatnonzero((oi==i)&(sj==j))[0]]=.00095
    return full,source,raw


def test_fractional_conflict_cannot_be_rounded_into_overlapping_hospitals():
    full,source,raw=conflict_fractional();q,_,_=r.restrict_templates(full,source)
    r.validate_vector(raw,*q.model[1:])
    result,vectors,plan=r.repair(full,source,3,solve=lambda *a:SimpleNamespace(status=0,x=raw,message='fractional',nit=0))
    assert result['feasible'] is None and plan is None
    assert set(vectors)=={'rawContinuousSolverVector','continuousRelaxationVector'}
    assert 'conflicting candidate pairs: [[1, 2]]' in result['reason']
    assert not result['modelInfeasibilityIndependentlyCertified']


def test_any_positive_conflicting_flow_is_rejected_without_dropping_tiny_mass():
    full,source=make_all(sites=3,conflicts=((1,2),));raw=full.read_plan(source)[0]
    name=next(iter(full.times));oi,sj=full.edges[name]
    tiny=full.offsets[name]+np.flatnonzero((oi==1)&(sj==2))[0]
    donor=full.offsets[name]+np.flatnonzero((oi==1)&(sj==1))[0]
    raw[tiny]=1e-15;raw[donor]-=1e-15
    result,vectors,plan=r.repair(full,source,3,solve=lambda *a:SimpleNamespace(status=0,x=raw,message='tiny',nit=0))
    assert result['feasible'] is None and plan is None and vectors['continuousRelaxationVector'][tiny]==1e-15
    assert 'conflicting' in result['reason']


@pytest.mark.parametrize('bad',[True,0,181,float('nan'),float('inf')])
def test_native_time_limit_guard(bad):
    full,source=make_all()
    with pytest.raises(ValueError):r.repair(full,source,bad,solve=lambda *a:pytest.fail('No native'))


@pytest.mark.parametrize('status',[1,2,3,4])
def test_no_primal_no_old_source_fallback(status):
    full,source=make_all();result,vectors,plan=r.repair(full,source,3,
        solve=lambda *a:SimpleNamespace(status=status,x=None,message='unknown',nit=0))
    assert result['feasible'] is None and plan is None and vectors=={}


def test_source_and_model_mutation_fail_closed():
    full,source=make_all()
    def changed(q,*a):q.model[5][-1]=0;return SimpleNamespace(status=1,x=None,message='changed',nit=0)
    with pytest.raises(ValueError,match='changed during repair'):r.repair(full,source,3,solve=changed)


def test_significant_negative_flow_rejected_but_raw_diagnostic_retained():
    full,source=make_all();raw=full.read_plan(source)[0];raw[full.nf]=-1.0001e-10
    result,vectors,plan=r.repair(full,source,3,solve=lambda *a:SimpleNamespace(status=0,x=raw,message='negative',nit=0))
    assert result['feasible'] is None and 'Significant negative' in result['reason'] and plan is None
    assert set(vectors)=={'rawContinuousSolverVector'}
    np.testing.assert_array_equal(vectors['rawContinuousSolverVector'],raw)


def test_one_bill_and_original_integer_global_staff_bound():
    full,source=make_all();q,_,eligible=r.restrict_templates(full,source)
    assert q.material==full.material and q.cost_scale==full.cost_scale
    np.testing.assert_array_equal(q.model[3][full.nx:full.nf],full.model[3][full.nx:full.nf])
    assert q.model[4][full.budget_row_index].toarray().tolist()==full.model[4][full.budget_row_index].toarray().tolist()
    assert q.model[6][full.budget_row_index]==full.model[6][full.budget_row_index]


def zero_edge_negative(full,source,value=-1e-12):
    raw=full.read_plan(source)[0]
    name=next(iter(full.times));oi,sj=full.edges[name]
    position=full.offsets[name]+np.flatnonzero((oi==0)&(sj==1))[0]
    assert raw[position]==0;raw[position]=value
    return raw,position


def test_tiny_negative_is_reported_and_original_positive_flows_preserved():
    full,source=make_all();raw,position=zero_edge_negative(full,source)
    result,vectors,plan=r.repair(full,source,3,solve=lambda *a:SimpleNamespace(status=0,x=raw,message='tiny',nit=0))
    assert result['feasible'] and plan is not None
    correction=result['numericalFlowCorrection']
    assert correction['changedFlowCount']==1 and correction['maximumCorrectionResidents']==pytest.approx(1e-9)
    assert correction['totalCorrectionResidents']==pytest.approx(1e-9)
    assert correction['originalRelaxedConstraintsRevalidated'] and correction['positiveFlowEntriesPreserved']
    assert result['rawFlowAssignmentsPreserved'] is False
    assert result['rawPositiveFlowAssignmentsPreserved'] and result['numericallyCleanedFlowAssignmentsPreservedDuringRounding']
    assert vectors['rawContinuousSolverVector'][position]==-1e-12
    assert vectors['continuousRelaxationVector'][position]==vectors['roundedOriginalVector'][position]==0
    positive=raw[full.nf:]>0
    np.testing.assert_array_equal(vectors['continuousRelaxationVector'][full.nf:][positive],raw[full.nf:][positive])
    full.read_plan(plan)


def test_exact_negative_threshold_is_inclusive_without_any_positive_drop():
    full,source=make_all();raw,position=zero_edge_negative(full,source,-1e-10)
    clean,report=r.correct_tiny_negative_flows(full,raw)
    assert clean[position]==0 and report['totalCorrectionResidents']==pytest.approx(1e-7)
    assert raw[position]==-1e-10


def test_post_correction_original_target_gate_cannot_be_bypassed():
    full,source=make_all();raw,position=zero_edge_negative(full,source)
    # A separate material target error must remain after a permitted repair.
    raw[full.nf]+=.001
    result,vectors,plan=r.repair(full,source,3,solve=lambda *a:SimpleNamespace(status=0,x=raw,message='bad target',nit=0))
    assert result['feasible'] is None and plan is None
    assert result['numericalFlowCorrection']['originalRelaxedConstraintsRevalidated'] is False
    assert set(vectors)=={'rawContinuousSolverVector','continuousRelaxationVector'}
    assert 'original constraints' in result['reason']


@pytest.mark.parametrize('value',[float('nan'),float('inf')])
def test_nonfinite_raw_still_retained_without_claimed_primal(value):
    full,source=make_all();raw,position=zero_edge_negative(full,source,value)
    result,vectors,plan=r.repair(full,source,3,solve=lambda *a:SimpleNamespace(status=0,x=raw,message='nonfinite',nit=0))
    assert result['feasible'] is None and plan is None and set(vectors)=={'rawContinuousSolverVector'}
    assert not result['continuousRelaxationPrimalValidated']


def test_no_numerical_correction_when_raw_flows_already_nonnegative():
    full,source=make_all();raw=full.read_plan(source)[0]
    clean,report=r.correct_tiny_negative_flows(full,raw)
    np.testing.assert_array_equal(clean,raw)
    assert report['changedFlowCount']==0 and report['totalCorrectionResidents']==0 and report['rawFlowEntriesPreserved']


def test_nonoptimal_returned_vector_is_diagnostic_only_not_discarded():
    full,source=make_all();raw=full.read_plan(source)[0]
    result,vectors,plan=r.repair(full,source,3,solve=lambda *a:SimpleNamespace(status=1,x=raw,message='time limit',nit=1))
    assert result['feasible'] is None and plan is None
    assert set(vectors)=={'rawContinuousSolverVector'} and not result['continuousRelaxationPrimalValidated']
    np.testing.assert_array_equal(vectors['rawContinuousSolverVector'],raw)
