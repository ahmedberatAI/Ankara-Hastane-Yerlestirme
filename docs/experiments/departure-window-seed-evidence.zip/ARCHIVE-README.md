# Saved 44-start seed evidence

Extract this archive at the repository root into a fresh clone, retaining the work/... paths. It does not contain the 44 large matrices: copy each externalWindowMatrices publishedRelativePath to its archiveRequiredPath, and verify its SHA256 in archive-manifest.json. Do not overwrite unrelated work. Repository code/data requirements are also hash bound; code hashes use LF normalization.

The full44 plan and exact canonical-four projection are in work/window-repair/lp-expanded312-v1. The projection is an exact subset of this saved 44-profile primal, not a separate four-profile native search. Its researchReportSHA256 and researchVectorSHA256 refer to repair-result.json and vectors.npz in that folder. The root final production plan separately recomputes all 44 assignments and runs the original-cost free-312 MIP.

Audit without native search:
python work/referees/audit_window_resource_repair_evidence.py --run-folder work/window-repair/lp-expanded312-v1 --manifest work/window-routing/full-v1/manifest.json --freeze work/referees/window-lp-expanded312-repair-freeze.json --producer-script work/referees/window-lp-expanded312-repair.py

The producer --run flag starts a new native research experiment. Do not use it merely to inspect saved evidence. Some synthetic tests also call tiny LPs. No claim is made that time-limited research will reproduce an identical optimum. Earlier historical 239 resource seed is a separately checked four-profile primal, not a replay of all its ancestral experiments. Seed sparse-opening objectives and closed-site branches are computational heuristics only; original budget and targets were unchanged. They are removed in the final free-312 cost search.
