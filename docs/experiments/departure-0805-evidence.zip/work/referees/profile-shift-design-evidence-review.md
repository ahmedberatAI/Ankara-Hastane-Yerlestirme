# 08.05 başlangıç duyarlılığı: bağımsız tasarım kapısı

23 Ekim 2026. Üretim modeli, kaynaklar ve dört yayımlanmış profil donuktur. Bu inceleme work-only yeni bir başlangıç saatini değerlendirme tasarımına aittir; yeni tam matris veya LP sonucuna otomatik kabul vermez.

## Bilimsel soru ve sınır

Soru: mevcut 209 konum, 26.400 yatak ve 23.035 hekim aynı kalırken, normal hafta içi yolculuğa 08.00 yerine 08.05'te başlamak erişilebilir bağlantıları ve yeniden atanabilecek talebi nasıl etkiler? Değişen tek ulaşım girdisi başlangıç saatidir; resmî kalkışlar, tahmini ara ofsetler, yürüyüş/biniş/aktarma kuralları korunur. Bu, ara durak tahmini hatasını veya gerçek gecikme belirsizliğini örnekleyen bir deney değildir.

Göreli süre ile mutlak varış ayrılmalı: `varış=başlangıç+süre`. Aynı mahalle/tesis çiftinde, iki değer de sonluysa FIFO gereği `T08:05+5 >= T08:00` (yalnız kayıtlı float toleransı) olmalıdır. Beş dakika sonra başlayan yolcunun göreli süresi azalabilir; bu daha erken mutlak varış anlamına gelmez. Kaçırılan sefer göreli süreyi çok artırabilir. 120 dakika arama penceresinin sağ ucu da beş dakika kayar; yeni sonlu çiftleri tümüyle yeni hizmet gibi yorumlamamak gerekir.

## Pilot kabulü

`work/referees/profile_shift_pilot.py` salt okunur incelendi; dört tiny testi bağımsız tekrar geçti. Sekiz amaçlı seçilmiş talep noktası kullanılır: 42,295,54,510,1239,638,963,228. Bu nüfusu temsil eden rastgele örnek değildir; sonuçları il geneline ağırlıklandırarak genellemek kabul edilmez.

Hedefler yayımlanmış travel-plan'ın aynı209 aday kimlik/sırasıdır. Bütün durak, örüntü ve aktarma ağı korunur; yalnız access satırları ve egress/direct hedef sütunları daraltılır. Geçici araştırma profil anahtarı ayrı in-process sözlükte yaratılıp finally'da eski sözlük nesnesi geri konur. Dosya tabanlı üretim profili değişmez.

08.00 hesabı kayıtlı matrise finite-mask ve 2e-5 dakika toleransıyla eşlenir. Her iki saatte ayrı heap event search ile 16 başlangıç ×209 hedef kontrolü ve ortak sonlu çiftlerde FIFO denetimi yapılır. 17 veri kimliği, paket, yönlendirme/pilot kodu giriş/çıkışta bağlanır. Önceden var olan work çıktısı üzerine yazılmaz. **Pilot tasarımına dar kabul**; gerçek sonucuna ayrıca bakılmalı.

## Tam matris ve kapasite kapısı

1. Tüm1.413 talep noktası ve aynı209 hedef için sıra/ID açık metadata; tek08.05araştırma profili, eski08.00olarak yanlış etiketlenmemeli. ÜretimNPZ üzerine yazma yok.
2. Giriş/çıkış kaynak, kaynak209sertifikası, sağlık ve yönlendirme kod kimlikleri; yeni matrisin kendiSHA'sı. Eski dört profil sertifikası değişmez ve yeni matrisin doğrulaması gibi gösterilmez.
3. Aynı kaynaklar/arsa/alan, tam%95il, tüm25ilçede%80,45dk; yeniaday, cihaz/kadro, ek bütçe veya hedef gevşetmesi yok. Yıllık malzeme dört/beş kez sayılmaz; bağımsız Decimal gider eşitliği gerekir.
4. Yeni LP aday/atanan indeksleri, gerçek yeni matris süreleri, talep üst sınırları, il/ilçe paydaları ve iki kaynak sınırları ayrı doğrulanmalı. Yeni atama hizmet verilen mahalle paylarını değiştirebilir; iki profil ortalaması aynı kişilerin süre kazancı değildir.
5. Eski08.00ataması yeni45dkedgekümesinde geçersiz olabilir. Üretim fixed-travel helper'ın `source_preserved` geri dönüşü yeni08.05verisine otomatik taşınamaz. Yeni saatte yeniden geçerliliği kanıtlanmayan akışın `feasible/sourceFallback` etiketi kabul edilmez; sonuç yoksa null/belirsiz.
6. Başarısız veya zaman aşan LP, gerçek08.05hizmetinin veya modelde başka planın olanaksızlığı olarak sunulmaz. Başarıda primal ve varsa sabit kaynaklı exact-dual kapsamı ayrı; bu yeni konum/minimum sayı optimumu değildir.

## Süre bütçesi

Sekiz kaynak pilotunun süresi `1413/8` ile ölçeklenip güvenilir tam süre sayılmaz; vektör batch boyutu, yoğun satırlar ve bellek farklıdır. Tam matris için üst sınır ve son bağımsız primal/kimlik incelemesine kalan süre yazılı seçilmelidir. Deadline'ı geçecekse pilotla durmak geçerli sonuçtur; sıfır değişim veya sonuçsuzluk yapay ilerleme diye sunulmaz. Başarılı bir08.05duyarlılığı da açık gerçek ulaşım/klinik/kamu gideri P1'lerini kapatmaz.

## Gerçek pilot ve tam yönlendirme kapısı

Pilot JSON SHA `18a8942f030b7dbcb4bdd9ab0f4a0c3f34cb909bc66342d87843cc9b9468990f`, NPZ SHA `10e697fcde440251e74b70e14f1b8a4df23fb3d6eac42d47043943f3a19c14ab` bağımsız okundu. On yedi kaynak ve iki kod kimliği güncel baytlarla eşleşiyor. Eski08.00 8×209 matrisi depodaki matrisin aynı satır/sütunlarıyla bitbir eşit; yeni çıktının indeksleri, adayları, finite-mask sayıları ve satır bazlı45dk değişimleri doğrudanNPZ'den yeniden hesaplandı.

1.672 çiftte147ortak sonlu,7yeni sonlu ve4kaybolan çift;45dk eşikte4kazanç/2kayıp. FIFO minimum mutlakvarış farkı0dk; en büyük göreli uzama yaklaşık25dk. Yeni7sonlu çiftin hepsi115–120dk'da olduğundan beş dakika kaymış120dk arama penceresiyle tutarlıdır. İki45dk kayıp: origin295→candidate1402,43,02885→45,94905dk; origin1239→candidate1505,42,39537→53,16490dk. Sekiz originin nüfus örneği olduğu iddiası yok.

Rapor 08.00/08.05 batch sürelerini0,512/0,504sn;16ayrı event kontrolünü5,660sn, toplam7,155sn olarak kaydediyor. Bu süre bütün1.413origin için doğrulanmış süre tahmini değildir. **En çok300sn bütçeli tam1413×209 yönlendirme araştırmasına açık blocker yok**; work-only çıktı, giriş/çıkışkimliği, iptal/sonuçsuzluk ve son bağımsızdenetim kapıları korunmalı. TamkapasiteLPsonucuna bu onay otomatik geçmez.

Optimizer'ın ayrıLPtasarımında eski geçerli-kaynak varsayan üstseviye helper yerine alt düzey formül/solve/exactdual kullanılması ve yeni08.05'te eskiakışı önce değerlendirmesi uygun. Yeni edgekümesi/offsetler farklı olabileceğinden eskiham vektörün akış dilimleri indisle kopyalanamaz; globalorigin/candidate kimliğiyle yeniden map edilip diğerüç profil JSONakışları değişmez kalmalıdır. Kaynakprefiksi ve Decimaltekfatura aynıdır; yeni saatte geçerli olmayan eskiakış için source_preserved/feasible etiketi yasaktır. Bu tasarım kabulü yeni kodun veya gerçek LPsonucunun kabulü değildir.

## Tam yönlendirme ve gerçek tek LP sonucunun son denetimi

Tam yönlendirme JSON `b9f60e61b3bbee0c3aadf670e8f400338fa95dae015bdd590d3d5243096e4eb0`, NPZ `51b24496428a2d84f614c6809779aea5576512a8867bf7d6b0a519179070faab` bağımsız kontrol edildi. 17 kaynak, üç kod, tüm1.413origin ve209hedef kimliği; eski08.00matrisin tamamı bitbir doğrulandı. 295.317 çiftte45dk için286kazanç/275kayıp;14.653 ortaksonlu,332yenisonlu,370kaybolan çift. Yeni332sonlu çiftin tümü115–120dk'da. En düşük mutlakvarış farkı−7,63e−6dk, float32toleransı içinde; gerçek zamanda erken varış iddiası yok.

25ilçe erişim paydası ve görünen nüfusları doğrudanNPZ'den yeniden hesaplandı. Altı crossing örneğinin dokuz sonlu rotası, ayrı kodla ham access/egress/direct/transferCSR kenarları, resmîduraksırası/kalkış/ofsetler, her biniş60sn hazırlığı, en fazlaüçbiniş ve dakika toplamı üzerinden doğrulandı; üç120dkufukdışı rotanın null kaydı korundu. Kalan bütün yeni çiftlerde ayrıeventshortestpath tekrarının yapıldığı iddia edilmez; betik32başlangıç/profil kontrolünü ayrıca raporlar.

Kaynak08.00süre planının760pozitifakışından32'si yeni45dkdestekdışında: 327.502,790368026363945 kişi-eşdeğeri atanma; bunun24.522'si120dkufkudışında. Bu yenidenatamadan sonraki kapsam kaybı değildir. Eskiakış yeni saatte geçerli fallback olarak kullanılamaz. Bağımsız sayısal kayıt `profile-shift-full-evidence-audit.json` içindedir.

LPhelper'ın ilk taslağında bellek içindeki times/resources ayrışması eskiLPkatsayılarına karşı serileştirilmiş99dkakışın geçmesine izin veriyordu. Kaynak/kaynak-kopyası ve matrissnapshot eşitliğiyle düzeltildi; dört negatifregresyon eklendi. Son helper `72457b45fe6e2a7782565d2afe5b5b7519bde719009fa87f0599e7cdeaf89c42`, runner `594b7a89238d0a2fbb06fc0fe289865871ad555a28a43e59f9fbfb441b1559ae`.35test ve gerçek no-nativepreflight bağımsız tekrar geçti; yeni LP tekprofile aittir, eskiüçprofil vektörüne dokunulmaz.

Root'un tek gerçekLP koşusu: `departure-sensitivity-v07.json` SHA `2c550293f1121c3cbbdf3b5dd03698b9404a6c7f8b26b8c75646d0a37827b131`. 17girdi/9üretim/3yönlendirme/2araştırma kodu güncel; kaynak209selected kaydı,26.400yatak/23.035hekim, maliyetin gösterilen değeri ve bağımsızDecimal kaynakfaturası birebir korunuyor. Native status2, yaklaşık0,016sn; üst düzey durum `inconclusive_without_validated_primal`, feasible/mean/allocations/certificate/dual/gap null, sourceFallbackfalse. Bağımsız infeasibility kanıtı kaydedilmediği için yeni08.05planı veya gerçek-kent olanaksızlığı iddiası yok.

**Gerçek çıktı için dar kabul:** yeni başlangıç saatinin routing hassasiyeti ve sonuçsuz kapasite deneyi dürüst/kimliği bağlı biçimde kaydedilmiş. Kaynakfaturası yeni08.05'te başarılmış bir plan maliyeti değildir. Varsayımlar ve dört üretim profili değişmedi; yeni klinik,91, minimumhastane veya tümgün güvenilirlik kabulü verilmez. İleride basit bağımsızkaynak kesiti bulunursa kendi dar kapsamıyla ayrı doğrulanmalı; bu kayıt geriye dönük olarak sahte sertifikaya çevrilmemelidir.
