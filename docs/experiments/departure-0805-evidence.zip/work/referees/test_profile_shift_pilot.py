import importlib.util
from pathlib import Path
import numpy as np
import pytest
from scipy.sparse import csr_matrix

spec = importlib.util.spec_from_file_location('profile_shift_pilot', Path(__file__).with_name('profile_shift_pilot.py'))
pilot = importlib.util.module_from_spec(spec)
spec.loader.exec_module(pilot)


def tiny(departures):
    network = {'stops': [{}, {}], 'patterns': [{'stops': [0, 1], 'offsets': [0, 600],
                                               'departures': {'weekday': departures}}]}
    access = csr_matrix(([60.], ([0], [0])), shape=(1, 2))
    egress = csr_matrix(([60.], ([1], [0])), shape=(2, 1))
    transfers = csr_matrix((2, 2))
    direct = csr_matrix((1, 1))
    return network, access, egress, transfers, direct


@pytest.mark.parametrize('departures,expected', [([28920, 30000], (13., 26.)), ([30000], (31., 26.))])
def test_later_start_can_increase_or_decrease_elapsed_time(departures, expected):
    args = tiny(departures)
    for start, want in zip((28800, 29100), expected):
        assert pilot.independent_events(*args, 0, start)[0] == want
    with pilot.temporary_profile():
        for profile, want in zip(('weekday-0800', pilot.KEY), expected):
            actual = pilot.timetable.route_batch(*args, profile)
            assert actual[0, 0] == want


def test_profile_context_restored_on_failure():
    original = pilot.timetable.PROFILES
    with pytest.raises(RuntimeError):
        with pilot.temporary_profile():
            assert pilot.timetable.PROFILES[pilot.KEY]['seconds'] == 29100
            raise RuntimeError('test')
    assert pilot.timetable.PROFILES is original and pilot.KEY not in original


def test_no_service_remains_unknown_and_not_zero():
    args = tiny([])
    assert np.isinf(pilot.independent_events(*args, 0, 29100)).all()
    with pilot.temporary_profile():
        assert np.isinf(pilot.timetable.route_batch(*args, pilot.KEY)).all()
