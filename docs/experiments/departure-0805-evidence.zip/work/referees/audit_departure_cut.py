"""Read-only exact audit against reconstructed LP rows; no graph or LP solve."""
from fractions import Fraction
from pathlib import Path
import hashlib,json,sys
import numpy as np
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT),str(Path(__file__).parent)]
import run_departure_sensitivity as experiment

def verify():
    path=ROOT/'work/referees/departure-capacity-cut-v07.json'
    raw=path.read_bytes()
    assert hashlib.sha256(raw).hexdigest()=='a33d3e0d93df8efa367fe15189220d43ae38e08bbac638ce0f4be68e718fa9d7'
    cut=json.loads(raw);state=experiment.preflight();c=state['context'];p=c.p;lp=c.lp
    assert cut['derivedMatricesSHA256']==state['bindings']['derivedMatricesSHA256']
    assert cut['sourceSHA256']==state['bindings']['sourceSHA256']
    assert cut['sourceResultSHA256']==experiment.sha(experiment.OUTPUT)
    assert cut['codeLF_SHA256']==experiment.sha(ROOT/'work/referees/find_departure_capacity_cut.py',True)
    partition=cut['cut'];inside=set(partition['originSourceSideIndices'])
    outside=set(partition['originSinkSideIndices']);sites=set(partition['siteSourceSideCandidateIndices'])
    assert not inside&outside and inside|outside==set(range(p.n))
    assert len(inside)==len(partition['originSourceSideIndices']) and len(outside)==len(partition['originSinkSideIndices'])
    assert len(sites)==len(partition['siteSourceSideCandidateIndices']) and sites<=set(p.ids)
    assert not any(int(i) in inside and int(p.ids[j]) not in sites for i,j in zip(lp['edgeOrigin'],lp['edgeSite']))
    # Every retained origin/bed/doctor inequality has unit nonnegative flow
    # coefficients, so summing those RHS bounds gives an upper cut capacity.
    head=lp['A'][:p.n+2*p.m].tocsc()
    assert np.all(head.data==1) and np.all(np.diff(head.indptr)==3)
    f=lambda v:Fraction.from_float(float(v))
    tol=f(1e-7)
    origin={i:(f(lp['b'][i])+tol)*1000 for i in outside}
    resource={int(p.ids[j]):(min(f(lp['b'][p.n+j]),f(lp['b'][p.n+p.m+j]))+tol)*1000
              for j in range(p.m) if int(p.ids[j]) in sites}
    read=lambda v:Fraction(int(v['numerator']),int(v['denominator']))
    assert {x['index']:read(x['upper']) for x in partition['originTerms']}==origin
    assert {x['candidateIndex']:read(x['upper']) for x in partition['siteTerms']}==resource
    exact=sum(origin.values(),Fraction())+sum(resource.values(),Fraction())
    target=f(p.target)-Fraction(1,1000)
    assert exact==read(cut['exactCutUpper']) and target==read(cut['targetLowerAllowingPhysicalTolerance'])
    assert target-exact==read(cut['exactShortfallAfterTolerance']) and exact<target
    experiment.unchanged(state)
    return dict(accepted=True,solverCalls=0,legalEdgesChecked=len(lp['c']),originTerms=len(origin),siteTerms=len(resource),
        exactCutUpper=str(exact),targetLower=str(target),shortfall=str(target-exact),
        scope='Only fixed 209 resources and derived 08:05 matrix; all district floors relaxed.')

if __name__=='__main__':print(json.dumps(verify(),indent=2))
