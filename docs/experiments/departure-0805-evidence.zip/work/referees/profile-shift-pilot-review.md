# Eight-origin 08:00 → 08:05 routing pilot

23 October 2026, work-only. No production file, server profile, saved matrix, placement or capacity was modified. No native optimization was run.

## Result and identity

The current `ego-da0980e2b9057e21065f4b018a9e935d994f89f52572e08db4546710cf3eb997` package was checked on entry and exit. The 17 source file hashes, production routing code and pilot code remained unchanged. The selected target order is exactly the 209 `candidateIndex`/`id` pairs in the accepted `travel-plan.json`; every stop, pattern and transfer remains available to routing.

Eight purposively chosen origins are `[42, 295, 54, 510, 1239, 638, 963, 228]`. This is neither a population sample nor an estimate of province-wide change.

- Code: `profile_shift_pilot.py`, SHA-256 `64810b8f7bba95d5770733070e5b006c3d7db3eb7c1cce2fff156e8791d9eac0`.
- Four synthetic tests passed, including shorter/longer elapsed time after a later start, absent service and restoration after failure.
- Report: `profile-shift-pilot-v07.json`, SHA-256 `18a8942f030b7dbcb4bdd9ab0f4a0c3f34cb909bc66342d87843cc9b9468990f`.
- NPZ: `profile-shift-pilot-v07.npz`, SHA-256 `10e697fcde440251e74b70e14f1b8a4df23fb3d6eac42d47043943f3a19c14ab`.

The 08:00 batch matrix matches the published matrix slice exactly. Both starts were compared independently against a heap-based event search: 16 origin/start combinations × 209 targets, equal finite sets and differences within float32 tolerance. The FIFO check holds: on every common finite pair, `elapsed08:05 + 5 >= elapsed08:00` within tolerance. Thus elapsed time can fall by up to five minutes without implying earlier absolute arrival.

Batch runtimes were 0.512 and 0.504 seconds; the independent event checks took 5.660 seconds; total pilot 7.155 seconds. These are measured small-pilot times, not a linear full-run forecast.

## Observed changes, not a feasibility conclusion

Of 1,672 pairs, 147 remain finite within the 120-minute routing horizon; seven become finite and four cease to be finite. The shifted horizon ends five minutes later, so the finite-set counts must not be described as a fixed absolute-arrival comparison.

Four selected-target connections enter the 45-minute threshold, and two leave it:

| Origin index | Target candidate index | 08:00 minutes | 08:05 minutes |
|---|---:|---:|---:|
| Cumhuriyet, 295 | 1402 | 43.0289 | 45.9490 |
| Cumhuriyet, 295 | 1405 | 48.2128 | 44.5003 |
| Cumhuriyet, 295 | 1483 | 48.2049 | 43.2049 |
| Cumhuriyet, 295 | 1726 | 45.8159 | 40.8159 |
| Ahi Evran, 1239 | 1505 | 42.3954 | 53.1649 |
| Ahi Evran, 1239 | 3395 | 48.8570 | 43.8570 |

The first row and fifth row lose threshold access. Ahi Evran still has four targets within 45 minutes, but their identities differ. Neither a gain nor a loss of a single edge proves that the fixed 209-site capacity plan passes or fails. No reassignment LP, population-wide coverage calculation or hospital-count claim is present.

## What is being perturbed

Only journey start is shifted by exactly 300 seconds, within the same ordinary-weekday departure catalogue. The terminal clocks, estimated intermediate offsets, 60-second boarding slack, three-boardings limit, full transfer network, 15-minute access/egress cap, five-minute transfer cap and walking costs are unchanged. A new temporary profile dictionary exists only inside the isolated Python process and is restored even on failure.

This does not model uncertain vehicle arrivals, delays, a different service date, exceptions, a full peak-period distribution, missing EGO services or newly observed 08:05 trips. It probes sensitivity to an existing model input. The absence of change for one of these eight origins cannot establish robustness.

## Proposed next gate, requiring separate authorization

1. Reuse the immutable source identities and exact 209 target order; run one work-only 1,413 × 209 matrix for 08:05. Keep all stop/line/transfer structures. Do not regenerate the production package or add a persistent profile.
2. Require the eight pilot rows to match, no NaN/negative times, finite values within 120 minutes, and FIFO absolute-arrival checks against the published 08:00 slice. Recompute independent event traces for any especially large threshold changes before interpretation.
3. Report full-denominator reachability and the existing saved assignment's changed edges as descriptive diagnostics only. This is not a capacity result: alternate hospitals may absorb a lost edge, while newly reachable hospitals may lack spare capacity.
4. Only if separately authorized, evaluate one fixed-resource allocation LP at the new start. Preserve every source location, bed type and physician integer, original district denominators and 95%/80%/45-minute constraints, exact existing annual resources, and the original cost comparison. A timeout remains unknown. Do not infer minimum count, real-city infeasibility or all-day reliability from that single extra profile.

No full matrix or LP has been started by this pilot.
