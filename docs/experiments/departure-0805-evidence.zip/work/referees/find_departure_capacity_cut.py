"""One authorized <=30-second integer max-flow; exact cut audit, no LP solver."""
from pathlib import Path
from fractions import Fraction
import hashlib,json,math,subprocess,sys,time
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import maximum_flow,breadth_first_order
ROOT=Path(__file__).resolve().parents[2];W=ROOT/'work/referees';P=ROOT/'data/processed'
OUT=W/'departure-capacity-cut-v07.json'
RESULT_SHA='2c550293f1121c3cbbdf3b5dd03698b9404a6c7f8b26b8c75646d0a37827b131'
F=Fraction.from_float
def sha(path,lf=False):
    b=path.read_bytes();return hashlib.sha256(b.replace(b'\r\n',b'\n') if lf else b).hexdigest()
def load(path):return json.loads(path.read_text(encoding='utf8'))
def rat(value):return dict(numerator=str(value.numerator),denominator=str(value.denominator),approximate=float(value))


def worker():
    start=time.monotonic();assert not OUT.exists();code=sha(Path(__file__),True)
    result=load(W/'departure-sensitivity-v07.json');assert sha(W/'departure-sensitivity-v07.json')==RESULT_SHA
    def unchanged():
        for n,digest in result['sourceSHA256'].items():assert sha(P/n)==digest
        for group in ('modelCodeSHA256','researchCodeLF_SHA256','routingCodeLF_SHA256'):
            for n,digest in result[group].items():assert sha(ROOT/n,True)==digest
        assert sha(W/'profile-shift-full-v07.npz')==result['derivedMatricesSHA256']
        assert sha(Path(__file__),True)==code
    unchanged();data=load(P/'dataset.json');health=load(P/'health-planning.json');cert=load(P/'travel-plan.json')
    s=cert['scenario'];sites=cert['plan']['selected'];rates=health['rates']
    with np.load(W/'profile-shift-full-v07.npz',allow_pickle=False) as z:
        times=z['minutes0805'].copy();ids=z['targetCandidateIndices'].tolist();origins=z['originIndices'].copy()
    assert ids==[x['candidateIndex'] for x in sites] and np.array_equal(origins,np.arange(len(data['demands'])))
    legal=np.isfinite(times)&(times<=s['threshold']);n,m=legal.shape
    # Each row permits 1e-7 in thousands-of-residents units. These ceilings
    # dominate that tolerance; district lower bounds are entirely removed.
    tol=F(1e-7);pop=[x['population'] for x in data['demands']]
    origin_bounds=[(F(float(v/1000))+tol)*1000 for v in pop]
    contact=float(rates['contactsPerResident'])*s['demandMultiplier']
    bedrate=float(rates['bedDaysPerResident'])*s['demandMultiplier']
    q=s['contactsPerDoctor']/contact/1000;occ=s['bedOccupancy']/100
    site_bounds=[];components=[]
    for site in sites:
        doctor=(F(float(site['doctors']*q))+tol)*1000
        bed=(F(float(site['beds']*365*occ/bedrate/1000))+tol)*1000
        site_bounds.append(min(doctor,bed));components.append((doctor,bed))
    origin_int=[math.ceil(x) for x in origin_bounds];site_int=[math.ceil(x) for x in site_bounds]
    source=n+m;sink=source+1;large=sum(origin_int)+1;oi,sj=np.where(legal)
    rows=np.r_[np.full(n,source),oi,n+np.arange(m)]
    cols=np.r_[np.arange(n),n+sj,np.full(m,sink)]
    values=np.r_[origin_int,np.full(len(oi),large),site_int].astype(np.int64)
    capacity=coo_matrix((values,(rows,cols)),shape=(sink+1,sink+1)).tocsr()
    elapsed_before=time.monotonic()-start
    solved=maximum_flow(capacity,source,sink,method='dinic')
    residual=(capacity-solved.flow).tocsr();residual.data=(residual.data>0).astype(np.int8);residual.eliminate_zeros()
    reachable=breadth_first_order(residual,source,directed=True,return_predecessors=False)
    inS=np.zeros(sink+1,bool);inS[reachable]=True
    assert inS[source] and not inS[sink]
    assert not np.any(inS[oi]&~inS[n+sj]),'Legal origin-to-site edge crosses the alleged finite cut'
    # This exact inequality is the certificate. The max-flow algorithm only
    # finds a useful partition and is unnecessary to independently verify it.
    outside_origins=np.flatnonzero(~inS[:n]);inside_sites=np.flatnonzero(inS[n:n+m])
    exact=sum((origin_bounds[i] for i in outside_origins),Fraction())+sum((site_bounds[j] for j in inside_sites),Fraction())
    integer=int(sum(origin_int[i] for i in outside_origins)+sum(site_int[j] for j in inside_sites))
    assert integer==int(solved.flow_value) and exact<=integer
    target=F(float(data['metadata']['provincePopulation']*s['coverageTarget']/100))
    target_lower=target-Fraction(1,1000)
    proved=exact<target_lower
    unchanged();elapsed=time.monotonic()-start;assert elapsed<30
    report=dict(format=1,artifactType='work-only-exact-fixed-resource-0805-capacity-cut',
        sourceResultSHA256=RESULT_SHA,sourcePackageId=result['sourcePackageId'],sourceSHA256=result['sourceSHA256'],
        derivedMatricesSHA256=result['derivedMatricesSHA256'],codeLF_SHA256=code,
        productionAndResearchCodeSHA256={**result['modelCodeSHA256'],**result['researchCodeLF_SHA256'],**result['routingCodeLF_SHA256']},
        graph=dict(nodes=sink+1,legalOriginSiteEdges=len(oi),integerFlowValue=int(solved.flow_value),integerCutUpper=integer,
            capacitiesRoundedUpToResidents=True,districtFloorsRemoved=True,secondsBeforeGraph=elapsed_before),
        exactCutUpper=rat(exact),exactTarget=rat(target),targetLowerAllowingPhysicalTolerance=rat(target_lower),
        exactShortfallAfterTolerance=rat(target_lower-exact),representedFixedResourceInfeasibilityCertified=proved,
        cut=dict(originSourceSideIndices=np.flatnonzero(inS[:n]).tolist(),originSinkSideIndices=outside_origins.tolist(),
            siteSourceSideCandidateIndices=[ids[j] for j in inside_sites],
            originTerms=[dict(index=int(i),id=data['demands'][i]['id'],population=pop[i],upper=rat(origin_bounds[i])) for i in outside_origins],
            siteTerms=[dict(candidateIndex=ids[j],id=sites[j]['id'],beds=sites[j]['beds'],doctors=sites[j]['doctors'],
                upper=rat(site_bounds[j]),doctorUpper=rat(components[j][0]),bedUpper=rat(components[j][1])) for j in inside_sites]),
        formula='sum origin upper for origins outside S + sum min(bed upper, physician upper) for sites inside S. No legal <=45min origin-inside-S to site-outside-S edge may exist. Every upper includes 1e-7-thousand-resident row tolerance. Exact target lower subtracts .001 resident.',
        elapsedSeconds=elapsed,hardTimeoutSeconds=30,
        scope='Cut applies only to the supplied derived08:05 matrix and unchanged209 source resources under this model. District floors were relaxed; no new LP, resource sizing, hospital count, real EGO or real-city impossibility claim. Original inconclusive LP report remains unchanged.')
    with OUT.open('x',encoding='utf8',newline='\n') as f:json.dump(report,f,ensure_ascii=False,indent=2);f.write('\n')
    print(json.dumps({'output':str(OUT),'sha256':sha(OUT),'integerFlow':int(solved.flow_value),'exactUpper':float(exact),
        'targetLower':float(target_lower),'certified':proved,'shortfall':float(target_lower-exact),'seconds':elapsed}))


if __name__=='__main__':
    if sys.argv[1:]==['--worker']:worker()
    else:
        assert not sys.argv[1:] and not OUT.exists()
        try:completed=subprocess.run([sys.executable,str(Path(__file__).resolve()),'--worker'],cwd=ROOT,timeout=30)
        except subprocess.TimeoutExpired:sys.exit('Graph research timeout; any partial output unaccepted')
        sys.exit(completed.returncode)
