import importlib.util
from pathlib import Path
import numpy as np

spec=importlib.util.spec_from_file_location('profile_shift_full',Path(__file__).with_name('profile_shift_full.py'))
full=importlib.util.module_from_spec(spec)
spec.loader.exec_module(full)


def test_crossings_preserve_global_indices_and_unreachable_meaning():
    before=np.asarray([[44.,46.,44.,44.],[30.,50.,50.,50.]])
    after=np.asarray([[np.inf,44.,47.,44.],[31.,42.,47.,50.]])
    value=full.largest_crossings(before,after,[10,20],[100,200,300,400])
    assert value['lost45'][0]['originIndex']==10
    assert value['lost45'][0]['candidateIndex']==100
    assert value['lost45'][0]['minutes0805'] is None
    assert value['gained45'][0]['originIndex']==20
    assert value['gained45'][0]['candidateIndex']==200
    assert value['gained45'][0]['elapsedChangeMinutes']==-8.
    assert len(value['lost45'])==2 and len(value['gained45'])==2


def test_no_threshold_crossing_is_not_an_improvement_count():
    value=full.largest_crossings(np.asarray([[40.,50.]]),np.asarray([[39.,49.]]),[7],[19,22])
    assert value=={'lost45':[],'gained45':[]}


def test_deadline_and_outputs_remain_work_only():
    assert full.BUDGET_SECONDS==300
    assert full.FULL_REPORT.parent==full.WORK and full.FULL_ARRAYS.parent==full.WORK
    assert full.FULL_REPORT.name=='profile-shift-full-v07.json'
    assert full.FULL_ARRAYS.name=='profile-shift-full-v07.npz'
