"""Independent exact cut verification from source JSON and derived matrix; no model/solver imports."""
from pathlib import Path
from fractions import Fraction
import hashlib,json,numpy as np
ROOT=Path(__file__).resolve().parents[2];P=ROOT/'data/processed';W=ROOT/'work/referees'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text(encoding='utf-8'))
F=Fraction.from_float
report_path=W/'departure-capacity-cut-v07.json';d=load(report_path)
assert sha(report_path)=='a33d3e0d93df8efa367fe15189220d43ae38e08bbac638ce0f4be68e718fa9d7'
for name,h in d['sourceSHA256'].items():assert sha(P/name)==h,name
for name,h in d['productionAndResearchCodeSHA256'].items():assert hashlib.sha256((ROOT/name).read_bytes().replace(b'\r\n',b'\n')).hexdigest()==h,name
assert sha(W/'departure-sensitivity-v07.json')==d['sourceResultSHA256']
assert sha(W/'profile-shift-full-v07.npz')==d['derivedMatricesSHA256']
data=load(P/'dataset.json');health=load(P/'health-planning.json');plan=load(P/'travel-plan.json');sites=plan['plan']['selected'];s=plan['scenario'];cut=d['cut']
z=np.load(W/'profile-shift-full-v07.npz');times=z['minutes0805'];ids=z['targetCandidateIndices'].tolist();n,m=times.shape
assert ids==[x['candidateIndex'] for x in sites];assert np.array_equal(z['originIndices'],np.arange(len(data['demands'])))
inside=cut['originSourceSideIndices'];outside=cut['originSinkSideIndices'];siteids=cut['siteSourceSideCandidateIndices'];lookup={g:j for j,g in enumerate(ids)}
assert len(inside)==len(set(inside)) and len(outside)==len(set(outside)) and set(inside).isdisjoint(outside)
assert set(inside)|set(outside)==set(range(n));assert len(siteids)==len(set(siteids)) and set(siteids)<=set(ids)
sitecols=[lookup[g] for g in siteids];othercols=[j for j,g in enumerate(ids) if g not in set(siteids)]
legal=np.isfinite(times)&(times<=s['threshold']);assert not legal[np.ix_(inside,othercols)].any()
tol=F(1e-7)
origin_caps={i:(F(float(data['demands'][i]['population']/1000))+tol)*1000 for i in outside}
contact=health['rates']['contactsPerResident']*s['demandMultiplier'];bedrate=health['rates']['bedDaysPerResident']*s['demandMultiplier'];q=s['contactsPerDoctor']/contact/1000;occ=s['bedOccupancy']/100
site_caps={};site_components={}
for j in sitecols:
 site=sites[j];doctor=(F(float(site['doctors']*q))+tol)*1000;bed=(F(float(site['beds']*365*occ/bedrate/1000))+tol)*1000
 site_caps[ids[j]]=min(doctor,bed);site_components[ids[j]]=(doctor,bed)
def read_fraction(obj):return Fraction(int(obj['numerator']),int(obj['denominator']))
assert len(cut['originTerms'])==len(origin_caps) and {x['index'] for x in cut['originTerms']}==set(origin_caps)
for row in cut['originTerms']:
 i=row['index'];assert row['id']==data['demands'][i]['id'] and row['population']==data['demands'][i]['population'];assert read_fraction(row['upper'])==origin_caps[i]
assert len(cut['siteTerms'])==len(site_caps) and {x['candidateIndex'] for x in cut['siteTerms']}==set(site_caps)
for row in cut['siteTerms']:
 g=row['candidateIndex'];site=sites[lookup[g]];assert row['id']==site['id'] and row['beds']==site['beds'] and row['doctors']==site['doctors']
 assert read_fraction(row['upper'])==site_caps[g] and read_fraction(row['doctorUpper'])==site_components[g][0] and read_fraction(row['bedUpper'])==site_components[g][1]
upper=sum(origin_caps.values(),Fraction())+sum(site_caps.values(),Fraction());target=F(float(data['metadata']['provincePopulation']*s['coverageTarget']/100));lower=target-Fraction(1,1000);shortfall=lower-upper
assert read_fraction(d['exactCutUpper'])==upper and read_fraction(d['exactTarget'])==target and read_fraction(d['targetLowerAllowingPhysicalTolerance'])==lower
assert read_fraction(d['exactShortfallAfterTolerance'])==shortfall and shortfall>0
assert d['representedFixedResourceInfeasibilityCertified'] is True and d['graph']['districtFloorsRemoved'] is True
assert d['graph']['legalOriginSiteEdges']==int(legal.sum())
assert upper<=d['graph']['integerCutUpper']<lower
source_result=load(W/'departure-sensitivity-v07.json');assert source_result['result']['feasible'] is None and source_result['result']['certificate'] is None
out=dict(sourceCutSHA256=sha(report_path),sourceLPResultSHA256=sha(W/'departure-sensitivity-v07.json'),sourceFilesVerified=len(d['sourceSHA256']),codeFilesVerified=len(d['productionAndResearchCodeSHA256']),originPartitionCount=n,sourceSideOrigins=len(inside),sinkSideOrigins=len(outside),sourceSideSites=len(sitecols),legalEdges=int(legal.sum()),illegalCutCrossings=0,independentExactUpper={'numerator':str(upper.numerator),'denominator':str(upper.denominator),'approximate':float(upper)},targetAfterPhysicalTolerance=float(lower),exactShortfallAfterTolerance=float(shortfall),sourceLPRecordUnchangedAndNull=True,solverCalls=0,scope='Exact fixed-209-resource 08:05 represented-model cut; district floors relaxed; no claim on new resource sizes, other locations, 91 hospitals, or real EGO completeness.')
(W/'departure-capacity-cut-evidence-audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(out,indent=2))
