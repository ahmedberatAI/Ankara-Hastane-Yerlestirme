from copy import deepcopy
from pathlib import Path
import sys
import numpy as np
import pytest
sys.path.insert(0,str(Path(__file__).parent))
import run_departure_sensitivity as r


def tiny():
    data={'demands':[dict(id='a',population=1,districtId='d')], 'candidates':[dict(id='x'),dict(id='y')]}
    plan={'selected':[dict(candidateIndex=1),dict(candidateIndex=0)]}
    report={'transitPackageId':'pkg','profiles':{'0800':dict(day='weekday',startSeconds=28800),'0805':dict(day='weekday',startSeconds=29100)},
        'origins':[dict(index=0,**data['demands'][0])], 'targets':[dict(index=1,id='y'),dict(index=0,id='x')]}
    arrays={'originIndices':np.array([0]),'targetCandidateIndices':np.array([1,0]),
        'minutes0800':np.array([[1.,2.]],np.float32),'minutes0805':np.array([[np.inf,3.]],np.float32)}
    return report,arrays,data,plan


def test_identity_noncontiguous_order_and_infinite_times_allowed():
    report,arrays,data,plan=tiny();r.identities(report,arrays,data,plan,'pkg')


@pytest.mark.parametrize('case',['package','departure','origin_order','candidate_order','origin_id','target_id','dtype','nan','negative','shape','extra'])
def test_bad_identity_or_matrix_rejected(case):
    report,arrays,data,plan=tiny()
    if case=='package':report['transitPackageId']='wrong'
    elif case=='departure':report['profiles']['0805']['startSeconds']=28800
    elif case=='origin_order':arrays['originIndices']=np.array([1])
    elif case=='candidate_order':arrays['targetCandidateIndices']=np.array([0,1])
    elif case=='origin_id':report['origins'][0]['id']='wrong'
    elif case=='target_id':report['targets'][0]['id']='wrong'
    elif case=='dtype':arrays['minutes0805']=arrays['minutes0805'].astype(float)
    elif case=='nan':arrays['minutes0805'][0,0]=np.nan
    elif case=='negative':arrays['minutes0805'][0,0]=-1
    elif case=='shape':arrays['minutes0805']=arrays['minutes0805'][:,:1]
    else:arrays['extra']=np.zeros(1)
    with pytest.raises(ValueError):r.identities(report,arrays,data,plan,'pkg')


def test_routing_report_pin_rejected_before_source_or_solve(monkeypatch):
    monkeypatch.setattr(r,'ROUTING_SHA','0'*64)
    monkeypatch.setattr(r.source,'validate_source',lambda *a:pytest.fail('Do not load stale routing source'))
    with pytest.raises(ValueError,match='Reviewed routing'):r.preflight()


def test_loaded_work_code_pin_rejected_before_source_or_solve(monkeypatch):
    monkeypatch.setattr(r,'LOADED_WORK_CODE',{})
    monkeypatch.setattr(r.source,'validate_source',lambda *a:pytest.fail('Do not load changed research code'))
    with pytest.raises(ValueError,match='Loaded research'):r.preflight()


def test_run_flag_is_strict_boolean():
    with pytest.raises(ValueError):r.run(1)
