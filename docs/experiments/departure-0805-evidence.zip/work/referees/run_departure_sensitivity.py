"""Immutable work-only 08:05 single-profile test; default is no-solver preflight."""
import argparse
from datetime import datetime,timezone
from pathlib import Path
import hashlib
import json
import sys
from time import monotonic
import numpy as np
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT),str(Path(__file__).parent)]
from scripts import run_joint_travel as source
from scripts import audit_joint_travel as audit
from backend import joint_travel as travel
import departure_sensitivity_lp as helper

WORK=ROOT/'work/referees'
ROUTING_SHA='b9f60e61b3bbee0c3aadf670e8f400338fa95dae015bdd590d3d5243096e4eb0'
ROUTING_ARRAY_SHA='51b24496428a2d84f614c6809779aea5576512a8867bf7d6b0a519179070faab'
REPORT=WORK/'profile-shift-full-v07.json'
ARRAYS=WORK/'profile-shift-full-v07.npz'
OUTPUT=WORK/'departure-sensitivity-v07.json'
SOURCES=('dataset.json','health-planning.json','example-transit-result.json','transit-package.json',
    'joint-plan.json','travel-plan.json','travel-proof.json','travel-summary.json','ego-network.json.gz',
    'ego-access.npz','ego-egress.npz','ego-transfers.npz','ego-direct.npz','transit-weekday-0800-matrix.npz',
    'transit-weekday-1000-matrix.npz','transit-saturday-1000-matrix.npz','transit-sunday-1000-matrix.npz')
ROUTING_CODE=('backend/timetable.py','work/referees/profile_shift_pilot.py','work/referees/profile_shift_full.py')
WORK_CODE=('work/referees/departure_sensitivity_lp.py','work/referees/run_departure_sensitivity.py')
def sha(path,lf=False):
    b=Path(path).read_bytes();return hashlib.sha256(b.replace(b'\r\n',b'\n') if lf else b).hexdigest()
LOADED_WORK_CODE={name:sha(ROOT/name,True) for name in WORK_CODE}


def identities(report,arrays,data,plan,package):
    if report['transitPackageId']!=package:raise ValueError('Routing source package differs')
    if report['profiles']!={'0800':{'day':'weekday','startSeconds':28800},'0805':{'day':'weekday','startSeconds':29100}}:
        raise ValueError('Actual departure identity differs')
    if set(arrays)!= {'originIndices','targetCandidateIndices','minutes0800','minutes0805'}:
        raise ValueError('Exact derived array names required')
    ids=[x['candidateIndex'] for x in plan['selected']];n=len(data['demands']);m=len(ids)
    if not np.array_equal(arrays['originIndices'],np.arange(n)) or not np.array_equal(arrays['targetCandidateIndices'],ids):
        raise ValueError('Origin/candidate order differs')
    expected=[dict(index=i,id=d['id'],population=d['population'],districtId=d['districtId']) for i,d in enumerate(data['demands'])]
    if report['origins']!=expected or report['targets']!=[dict(index=i,id=data['candidates'][i]['id']) for i in ids]:
        raise ValueError('Explicit routing identities/paydays differ')
    for key in ('minutes0800','minutes0805'):
        a=arrays[key]
        if a.shape!=(n,m) or a.dtype!=np.float32 or np.any(np.isnan(a)) or np.any(a<0):
            raise ValueError('Derived minutes shape/type/value invalid')


def assert_coefficients(left,right):
    for name in ('A','E'):
        if left[name].shape!=right[name].shape:raise ValueError('Baseline sparse shape differs')
        for part in ('indptr','indices','data'):
            if not np.array_equal(getattr(left[name],part),getattr(right[name],part)):
                raise ValueError('Baseline sparse coefficients differ')
    for name in ('c','b','d','upper','edgeOrigin','edgeSite'):
        if not np.array_equal(left[name],right[name]):raise ValueError('Baseline '+name+' differs')


def preflight():
    if sha(REPORT)!=ROUTING_SHA or sha(ARRAYS)!=ROUTING_ARRAY_SHA:raise ValueError('Reviewed routing bytes changed')
    if {n:sha(ROOT/n,True) for n in WORK_CODE}!=LOADED_WORK_CODE:raise ValueError('Loaded research code changed')
    report=json.loads(REPORT.read_text(encoding='utf8'))
    if report['arraysSHA256']!=ROUTING_ARRAY_SHA or set(report['sourceSHA256'])!=set(SOURCES):raise ValueError('Routing source inventory differs')
    if report['sourceSHA256']!={n:sha(ROOT/'data/processed'/n) for n in SOURCES}:raise ValueError('Routing sources stale')
    if report['modelCodeLF_SHA256']!={n:sha(ROOT/n,True) for n in ROUTING_CODE}:raise ValueError('Routing code stale')
    inputs=source.validate_source(ROOT)
    current=audit.current_report(ROOT/'data/processed',ROOT)
    if audit.digest(current)!=audit.digest(json.loads((ROOT/'data/processed/travel-summary.json').read_text(encoding='utf8'))):
        raise ValueError('Saved source travel summary differs')
    certificate=json.loads((ROOT/'data/processed/travel-plan.json').read_text(encoding='utf8'))
    plan=certificate['plan'];p=inputs['problem'];v,_=p.read_plan(plan)
    if (p.s['threshold'],p.s['coverageTarget'],p.s['districtFloor'])!=(45,95,80):
        raise ValueError('Reviewed 45/95/80 scenario differs')
    with np.load(ARRAYS,allow_pickle=False) as z:arrays={name:z[name].copy() for name in z.files}
    identities(report,arrays,inputs['data'],plan,inputs['package'])
    mapping={int(j):k for k,j in enumerate(arrays['targetCandidateIndices'])}
    order=[mapping[int(j)] for j in p.ids]
    baseline=arrays['minutes0800'][:,order];shifted=arrays['minutes0805'][:,order]
    if not np.array_equal(baseline,p.times['weekday-0800']):raise ValueError('Complete baseline matrix differs from production')
    same=helper.prepare(p,v,'weekday-0800',baseline)
    assert_coefficients(same.lp,travel.formulate_profile(p,v,'weekday-0800'))
    context=helper.prepare(p,v,'weekday-0800',shifted)
    bindings=dict(sourcePackageId=inputs['package'],sourceCostCertificateSHA256=inputs['seed_hash'],
        sourceTravelPlanSHA256=sha(ROOT/'data/processed/travel-plan.json'),
        sourceSHA256=report['sourceSHA256'],modelCodeSHA256=inputs['codes'],researchCodeLF_SHA256=LOADED_WORK_CODE,
        routingReportSHA256=ROUTING_SHA,derivedMatricesSHA256=ROUTING_ARRAY_SHA,
        routingCodeLF_SHA256=report['modelCodeLF_SHA256'])
    return dict(inputs=inputs,context=context,bindings=bindings,plan=plan,sourceAudit=current,
        baselineCoefficientsBitIdentical=True,sourceProfileNames=list(p.times))


def unchanged(state):
    source.unchanged(state['inputs']);b=state['bindings']
    if b['sourceSHA256']!={n:sha(ROOT/'data/processed'/n) for n in SOURCES}:raise ValueError('Source changed during research')
    if b['routingCodeLF_SHA256']!={n:sha(ROOT/n,True) for n in ROUTING_CODE}:raise ValueError('Routing code changed')
    if LOADED_WORK_CODE!={n:sha(ROOT/n,True) for n in WORK_CODE}:raise ValueError('Research code changed')
    if sha(REPORT)!=ROUTING_SHA or sha(ARRAYS)!=ROUTING_ARRAY_SHA:raise ValueError('Routing result changed')


def run(execute=False):
    if type(execute) is not bool:raise ValueError('Explicit execute boolean required')
    began=monotonic();state=preflight();unchanged(state)
    if not execute:return {'status':'preflight_only_no_native_call',**state['bindings'],
        'baselineCoefficientsBitIdentical':True,'hospitalCount':state['plan']['hospitalCount'],
        'baselineAtShift':{k:v for k,v in state['context'].baseline.items() if k!='flow'}}
    # Fixed work output, write once. Reject redirected work/referees paths.
    if (ROOT/'work').resolve()!=ROOT/'work' or WORK.resolve()!=WORK or OUTPUT.exists() or OUTPUT.is_symlink():
        raise ValueError('Unsafe or existing immutable research output')
    remaining=60-(monotonic()-began)
    if remaining<=0:raise TimeoutError('Preflight exhausted 60-second total budget; no native call')
    result=helper.evaluate(state['context'],seconds=min(15,remaining),overall_seconds=remaining)
    unchanged(state)
    if monotonic()-began>60:raise TimeoutError('Total preflight/solve/exit audit exceeded 60 seconds; no accepted artifact')
    report=dict(format=1,artifactType='work-only-fixed-resource-departure-sensitivity',builtAt=datetime.now(timezone.utc).isoformat(),
        **state['bindings'],scenario=dict(profile='weekday-0805',serviceDay='weekday',departureSeconds=29100,
            thresholdMinutes=45,provinceTargetPercent=95,districtFloorPercent=80),
        selected=state['plan']['selected'],hospitalCount=state['plan']['hospitalCount'],
        totalBeds=state['plan']['totalBeds'],totalDoctors=state['plan']['totalDoctors'],
        annualEquivalentCostTRY=state['plan']['annualEquivalentCostTRY'],
        annualMaterialCostTRY=state['plan']['annualMaterialCostTRY'],
        independentSourceDecimalAnnualCostTRY=state['sourceAudit']['decimalAnnualEquivalentCostTRY'],
        baselineCoefficientsBitIdentical=True,unchangedOriginalProfileNames=state['sourceProfileNames'],
        result=result,elapsedSeconds=monotonic()-began,
        scope='One extra departure scenario, not a replacement/new four-profile production certificate. Original three other profiles were not solved. '
        'No new resource, cost, clinical, 91-hospital, real-city impossibility or all-day reliability claim. '
        'Old/new mean differences may concern different fractional assignments, not the same identified people. '
        'The source package identifies the source network; this derived matrix is separately hash-bound and is not a new production package.')
    payload=json.dumps(report,ensure_ascii=False,allow_nan=False,indent=2)+'\n'
    with OUTPUT.open('x',encoding='utf8',newline='\n') as stream:stream.write(payload)
    return {'status':result['status'],'resultFile':str(OUTPUT),'sha256':sha(OUTPUT),'feasible':result['feasible'],
        'meanMinutes':result['meanMinutes'],'sourceFallback':result['sourceFallback'],'elapsedSeconds':report['elapsedSeconds']}


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--run',action='store_true')
    print(json.dumps(run(parser.parse_args().run),ensure_ascii=False,allow_nan=False,indent=2))
