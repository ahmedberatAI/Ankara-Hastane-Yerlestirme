# 08:05 sensitivity: narrow fixed-resource conclusion

The sole real assignment LP returned native status 2 in 0.016 seconds. Its saved
record remains `inconclusive_without_validated_primal`, with feasibility, mean,
allocations and dual absent. It does not reuse invalid 08:00 flows. Source and
result identity, all 209 locations / 26,400 beds / 23,035 physicians, and the
annual bill were checked independently of the helper in
`check_departure_sensitivity_result.py`. Decimal annual equivalent cost is
175868263288.701820070258781870797300915922511731747057826303 TRY;
the one annual material bill is 33668611722.743994245843320718663615736 TRY.
The 17 source and 14 producer/model code identities match. No production file,
coefficient or original four-profile certificate changed.

Simple necessary inequalities for all 2,625 district groups of size one, two
and three did not establish a contradiction. A loose disconnected-component
province upper bound was 5,618,075, slightly above the 5,614,804 target. These
failures to find a cut were not treated as feasibility evidence.

Root then authorized exactly one deterministic integer max-flow attempt under
a 30-second subprocess timeout. It finished in 0.047 seconds. The graph entirely
removes district floors and rounds each source/bed/doctor capacity upwards to
integer resident-equivalents. Its cut value is 5,595,862. The algorithm only
finds a useful partition: the decisive inequality can be checked directly,
without rerunning any flow algorithm or linear optimizer.

The cut places 1,083 origins (5,400,030 modeled residents) and 43 hospitals on
the source side. No source-side origin has a legal <=45-minute connection to
any of the other 166 selected hospitals in the derived 08:05 matrix. Therefore
all service to those origins must pass through these 43 hospitals. The sum of
their min(bed, physician) capacities, with the accepted LP row tolerance added,
is at most 5,105,737.199528295 resident-equivalents. Even granting the entire
other 330 origins their relaxed upper bounds contributes only 489,774.033.

The exact rational cut upper bound is therefore **5,595,511.232528294**, or
approximately **94.6735749084%** of the full provincial population. Allowing the
province equality its .001-resident physical tolerance still requires at least
5,614,803.999. The exact positive difference is **19,292.76647170541**. Each
source and resource term is computed from the actual represented binary64
right-hand side plus 1e-7 in thousands-of-residents units, then converted to
exact Fraction arithmetic. Every member ID, term numerator and denominator,
and the no-crossing-edge partition are saved in `departure-capacity-cut-v07.json`.

This is a separate cut certificate for the supplied 08:05 matrix with the
unchanged 209 resources, even with district floors removed. It is not a claim
about real Ankara, complete EGO service, 91 hospitals, all candidates, resource
resizing, or all-day reliability. The first LP record is deliberately not
rewritten to pretend that the LP solver itself provided this certificate.

The same partition had 13 legal crossing pairs in the 08:00 matrix. Three were
used in the published 08:00 travel allocation, carrying 22,055.953042216006
resident-equivalents. All 13 are outside the new <=45-minute support. This
illustrates a joint access/resource bottleneck; it is not a causal estimate for
identified individuals. Twenty of the 43 cut-site capacities are limited by
beds and 23 by physicians under the present aggregate model.

Record SHA256 values:

- Original single-LP result: `2c550293f1121c3cbbdf3b5dd03698b9404a6c7f8b26b8c75646d0a37827b131`
- Separate exact cut: `a33d3e0d93df8efa367fe15189220d43ae38e08bbac638ce0f4be68e718fa9d7`
- Routing report: `b9f60e61b3bbee0c3aadf670e8f400338fa95dae015bdd590d3d5243096e4eb0`
- Derived routing arrays: `51b24496428a2d84f614c6809779aea5576512a8867bf7d6b0a519179070faab`

Both independent referees accepted the final partition and exact inequality
from source data without invoking a graph solver or LP. They independently
checked all 1,914 legal edges, the 1,413-origin partition, and all 330 origin plus
43 site rational capacity terms. Their records are
`departure-capacity-cut-transport-audit.json` and
`departure-capacity-cut-evidence-audit.json`. Publication is a separate root
decision; this sub-agent made no production change or second native LP attempt.
