# 08:05 district reachability upper-bound check

Independent read-only follow-up, 23 October 2026 04:37 UTC. No native solver, rerouting or production edit was performed.

Source matrix: `profile-shift-full-v07.npz`, SHA-256 `51b24496428a2d84f614c6809779aea5576512a8867bf7d6b0a519179070faab`. The source dataset and exact 209 target order are those bound by `profile-shift-full-v07.json`, SHA-256 `b9f60e61b3bbee0c3aadf670e8f400338fa95dae015bdd590d3d5243096e4eb0`.

For each district, the optimistic reachable population is the sum of populations of its represented origin rows having at least one selected target with `minutes0805 <= 45`. The denominator is the full current official district population, including unmatched people. Bed/physician capacity, competition and annual allocation are removed. Thus this is an upper bound on service possible at these fixed locations under this matrix, not a feasible assignment witness.

The 80% comparison was performed by exact integer multiplication: `5 * reachablePopulation < 4 * districtPopulation`. **Zero of 25 districts fail.**

The closest districts are:

| District | Reachable population | Full denominator | Reachability | Slack above 80%, people |
|---|---:|---:|---:|---:|
| Kızılcahamam | 22,284 | 27,841 | 80.040228% | 11.2 |
| Şereflikoçhisar | 26,335 | 32,831 | 80.213822% | 70.2 |
| Nallıhan | 20,951 | 26,083 | 80.324349% | 84.6 |
| Haymana | 20,777 | 25,798 | 80.537251% | 138.6 |
| Çamlıdere | 8,256 | 10,203 | 80.917377% | 93.6 |

The province-wide upper coverage is 5,667,638 / 5,910,320. The unchanged 95% target is 5,614,804; the optimistic coverage exceeds it by 52,834 people. This does not account for site capacities.

Consequently, this simple necessary condition does **not** provide an independent infeasibility certificate for the 08:05 fixed-resource experiment. The reported native LP status 2 remains separate from this check; without a separately validated capacity/flow cut or other certificate it must not be promoted to a proved model impossibility. Neither this upper-bound pass nor the solver status proves a real-city claim, minimum hospital count or 91-site conclusion.
