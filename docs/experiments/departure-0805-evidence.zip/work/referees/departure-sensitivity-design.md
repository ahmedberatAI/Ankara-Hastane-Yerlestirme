# One extra 08:05 fixed-resource research scenario

The published cost and four-profile travel certificates remain unchanged. This
experiment uses the same 209 locations, 26,400 beds and 23,035 physicians, and the
same single annual material bill. It does not infer a common individual identity
from fractional assigned population or multiply annual demand by five profiles.

The reviewed routing report and NPZ are pinned to b9f60e61b3bbee0c3aadf670e8f400338fa95dae015bdd590d3d5243096e4eb0
and 51b24496428a2d84f614c6809779aea5576512a8867bf7d6b0a519179070faab.
Every origin and selected candidate is checked with its explicit identity/order.
The source package identifies the source network; the derived 08:05 matrix has
its own hash and is not silently incorporated into a new production package.

The helper creates only a single-profile assignment LP using the frozen
production formulation. It does not rename/mutate any original profile or copy
flows across changed edge offsets. The entire 08:00 matrix and every sparse LP
coefficient, right-hand side, box bound and objective match the production
08:00 representation bit for bit in the no-solver real-data preflight.

The old 08:00 allocation is explicitly reevaluated at 08:05. Thirty-two positive
edges carry 327,502.790368 assigned resident-equivalents outside the new 45-minute
support, so it is not an 08:05 fallback. Unknown, timeout, negative/numerically
invalid primal, or unverified native infeasibility therefore return feasibility
null and no new allocations. The original production result is retained in its
original scope. These outcomes do not establish real-city or global infeasibility.

A new accepted assignment must satisfy exact 95% of the full province population,
80% of each complete district denominator, separate bed/physician constraints,
nonnegative flows without clipping, source resource snapshots and serialized
flow roundtrip. The population and capacity tolerances match the original model.
Each finite-box dual uses exact rational arithmetic on the represented binary64
LP arrays; signed primal/dual discrepancy remains visible, with 1e-7-minute
numerical tolerance. This bound concerns only these unchanged resources and this
one supplied matrix. New-time optimum may be worse than the old-time mean; the
comparison concerns potentially different fractional assignments, not identical
individuals leaving five minutes later.

The thin runner checks current public source travel audit, nine production code
hashes, seventeen source files, three routing code hashes and both research
module hashes on entry/exit. Native limit is 15 seconds; preflight, native and
postchecks must fit 60 seconds. No accepted output is written on deadline failure.
Default invocation performs only preflight. --run makes exactly one native LP
attempt, then exclusively creates work/referees/departure-sensitivity-v07.json.
It never overwrites any output or writes processed data. Root alone controls the
one real LP invocation after independent review.

The 35 tiny tests cover coefficient identity, a lost old edge with feasible new
assignment, invalid old flow with unknown/infeasible native status, valid new
fallback, empty support, malformed matrix/profile identity, strict negative flow,
percentage district tolerance, resource constraints, memory mutation, timing and
source/code pin failures. No real 08:05 LP was used to develop those tests.
