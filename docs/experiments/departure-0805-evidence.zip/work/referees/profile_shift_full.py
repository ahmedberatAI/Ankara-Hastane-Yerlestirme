"""Work-only full-origin/+5-minute audit, with a hard 300-second child deadline.

Preparation does not authorize execution. No native LP or production writer is imported.
"""
from datetime import datetime, timezone
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT/'work/referees'
spec = importlib.util.spec_from_file_location('shift_pilot_frozen', WORK/'profile_shift_pilot.py')
pilot = importlib.util.module_from_spec(spec)
spec.loader.exec_module(pilot)
FULL_REPORT = WORK/'profile-shift-full-v07.json'
FULL_ARRAYS = WORK/'profile-shift-full-v07.npz'
PILOT_REPORT_SHA = '18a8942f030b7dbcb4bdd9ab0f4a0c3f34cb909bc66342d87843cc9b9468990f'
PILOT_ARRAY_SHA = '10e697fcde440251e74b70e14f1b8a4df23fb3d6eac42d47043943f3a19c14ab'
BUDGET_SECONDS = 300


def finite_json(value):
    return float(value) if np.isfinite(value) else None


def largest_crossings(before, after, origins, targets, maximum=5):
    """Threshold crossings ranked by worsening/improvement, with unreachable explicit."""
    result = {}
    for name, mask, sign in (('lost45', (before<=45)&~(after<=45), 1),
                             ('gained45', (after<=45)&~(before<=45), -1)):
        rows, cols = np.where(mask)
        records = []
        for row, col in zip(rows, cols):
            a, b = float(before[row,col]), float(after[row,col])
            change = sign*(b-a)
            records.append((change, int(row), int(col), a, b))
        records.sort(key=lambda x: (-x[0], x[1], x[2]))
        result[name] = [{'originIndex': int(origins[row]), 'candidateIndex': int(targets[col]),
                         'localRow': row, 'localColumn': col,
                         'minutes0800': finite_json(a), 'minutes0805': finite_json(b),
                         'elapsedChangeMinutes': finite_json(b-a),
                         'nonfiniteMeaning': 'No route within the profile-relative 120-minute model horizon; not absence of real service'}
                        for _, row, col, a, b in records[:maximum]]
    return result


def run_worker():
    assert not FULL_REPORT.exists() and not FULL_ARRAYS.exists(), 'Immutable output exists'
    started_clock = datetime.now(timezone.utc).isoformat()
    started = time.perf_counter()
    deadline = started+BUDGET_SECONDS

    def gate():
        if time.perf_counter() >= deadline:
            raise TimeoutError('Full routing research deadline; no feasibility conclusion')

    assert pilot.sha(WORK/'profile-shift-pilot-v07.json') == PILOT_REPORT_SHA
    assert pilot.sha(WORK/'profile-shift-pilot-v07.npz') == PILOT_ARRAY_SHA
    small = json.loads((WORK/'profile-shift-pilot-v07.json').read_text(encoding='utf8'))
    assert pilot.sha(WORK/'profile_shift_pilot.py', True) == small['pilotCodeLF_SHA256']
    source_dir = ROOT/'data/processed'
    before_hashes = {name: pilot.sha(source_dir/name) for name in pilot.SOURCE_FILES}
    assert before_hashes == small['sourceSHA256'], 'Sources changed since reviewed pilot'
    package = pilot.check_package()
    assert package == small['transitPackageId']
    code = {'backend/timetable.py': pilot.sha(ROOT/'backend/timetable.py', True),
            'work/referees/profile_shift_pilot.py': pilot.sha(WORK/'profile_shift_pilot.py', True),
            'work/referees/profile_shift_full.py': pilot.sha(Path(__file__), True)}
    assert code['backend/timetable.py'] == small['routingCodeLF_SHA256']
    data = json.loads((source_dir/'dataset.json').read_text(encoding='utf8'))
    plan = json.loads((source_dir/'travel-plan.json').read_text(encoding='utf8'))
    targets = np.asarray([x['candidateIndex'] for x in plan['plan']['selected']], dtype=int)
    assert targets.tolist() == small['retainedScope']['targetCandidateIndices']
    origins = np.arange(len(data['demands']), dtype=int)
    assert len(origins) == 1413 and len(targets) == 209
    network, access, full_egress, transfers, full_direct = pilot.timetable.load_network()
    egress = full_egress[:,targets].tocsr()
    direct = full_direct[:,targets].tocsr()
    stored = np.load(source_dir/'transit-weekday-0800-matrix.npz')['minutes'][:,targets]
    matrices = {}; timings = {}
    gate()
    with pilot.temporary_profile():
        for name, profile in (('0800','weekday-0800'), ('0805',pilot.KEY)):
            t = time.perf_counter()
            value = np.full((len(origins),len(targets)), np.inf, dtype=np.float32)
            for first in range(0,len(origins),96):
                gate()
                last = min(first+96,len(origins))
                value[first:last] = pilot.timetable.route_batch(network,access[first:last],egress,
                                                               transfers,direct[first:last],profile,batch_size=96)
                gate()
            matrices[name] = value
            timings[name] = time.perf_counter()-t
    assert pilot.KEY not in pilot.timetable.PROFILES
    a,b = matrices['0800'],matrices['0805']
    baseline_error = pilot.compare(a,stored)
    small_arrays = np.load(WORK/'profile-shift-pilot-v07.npz')
    assert np.array_equal(targets,small_arrays['targetCandidateIndices'])
    pilot_errors = {label:pilot.compare(matrices[label][small_arrays['originIndices']],small_arrays['minutes'+label])
                    for label in ('0800','0805')}
    assert not np.isnan(b).any() and np.all(b>=0) and np.all(b[np.isfinite(b)]<=120.00001)
    common = np.isfinite(a)&np.isfinite(b)
    assert np.all(b[common]+5>=a[common]-2e-5)
    crossings = largest_crossings(a,b,origins,targets)
    audited_origins = sorted(set(pilot.ORIGINS)|{x['originIndex'] for rows in crossings.values() for x in rows})
    independent = []; t=time.perf_counter()
    for label,start in (('0800',28800),('0805',29100)):
        for origin in audited_origins:
            gate()
            expected = pilot.independent_events(network,access,egress,transfers,direct,origin,start)
            error = pilot.compare(matrices[label][origin],expected)
            independent.append({'profile':label,'originIndex':origin,'targets':len(targets),'maxMinutesError':error})
    timings['independentEventChecks']=time.perf_counter()-t
    # These are topology-only reachability diagnostics, with full district denominators.
    district_rows=[]
    for district in data['districts']:
        rows=[i for i,d in enumerate(data['demands']) if d['districtId']==district['id']]
        before_pop=sum(data['demands'][i]['population'] for i in rows if np.any(a[i]<=45))
        after_pop=sum(data['demands'][i]['population'] for i in rows if np.any(b[i]<=45))
        district_rows.append({'districtId':district['id'],'name':district['name'],
                              'denominatorPopulation':district['population'],
                              'anySelectedTarget45Population0800':before_pop,
                              'anySelectedTarget45Population0805':after_pop})
    # Trace only crossing examples, without changing their allocation or resources.
    traces=[]
    with pilot.temporary_profile():
        for crossing_type, examples in crossings.items():
            for example in examples[:3]:
                row,col=example['localRow'],example['localColumn']
                item={'type':crossing_type,**example,'candidateId':data['candidates'][example['candidateIndex']]['id'],
                      'demandId':data['demands'][row]['id'],'traces':{}}
                for label,profile in (('0800','weekday-0800'),('0805',pilot.KEY)):
                    gate()
                    minutes,path=pilot.timetable.route_one(network,access,egress,transfers,direct,row,profile,col)
                    pilot.compare(np.asarray([matrices[label][row,col]]),np.asarray([minutes]))
                    item['traces'][label]={'minutes':finite_json(minutes),'legs':path,
                        'rideRouteIds':[network['patterns'][leg['pattern']]['route'] for leg in path or [] if leg['kind']=='ride']}
                traces.append(item)
    assert pilot.KEY not in pilot.timetable.PROFILES
    assert package==pilot.check_package()
    assert before_hashes=={name:pilot.sha(source_dir/name) for name in pilot.SOURCE_FILES}
    assert code=={name:pilot.sha(ROOT/name,True) for name in code}
    gate()
    np.savez_compressed(FULL_ARRAYS,originIndices=origins,targetCandidateIndices=targets,
                        minutes0800=a,minutes0805=b)
    report={'format':1,'kind':'work_only_full_origin_selected_209_five_minute_start_shift',
            'startedAt':started_clock,'completedAt':datetime.now(timezone.utc).isoformat(),
            'transitPackageId':package,'sourceSHA256':before_hashes,'modelCodeLF_SHA256':code,
            'pilotReportSHA256':PILOT_REPORT_SHA,'pilotArraysSHA256':PILOT_ARRAY_SHA,
            'arraysSHA256':pilot.sha(FULL_ARRAYS),'hardSubprocessTimeoutSeconds':BUDGET_SECONDS,
            'profiles':{'0800':{'day':'weekday','startSeconds':28800},'0805':{'day':'weekday','startSeconds':29100}},
            'origins':[{'index':i,'id':d['id'],'population':d['population'],'districtId':d['districtId']} for i,d in enumerate(data['demands'])],
            'targets':[{'index':int(i),'id':data['candidates'][int(i)]['id']} for i in targets],
            'retainedNetwork':{'stops':len(network['stops']),'patterns':len(network['patterns']),
                              'transferEdges':transfers.nnz},
            'seconds':{**timings,'total':time.perf_counter()-started},
            'baselineMatrixMaxMinutesError':baseline_error,'pilotRowsMaxMinutesErrors':pilot_errors,
            'independentEventChecks':independent,
            'pairs':{'total':int(a.size),'commonFinite120':int(common.sum()),
                     'newFinite120':int((np.isfinite(b)&~np.isfinite(a)).sum()),
                     'lostFinite120':int((np.isfinite(a)&~np.isfinite(b)).sum()),
                     'shorterElapsed':int((b[common]<a[common]-2e-5).sum()),
                     'longerElapsed':int((b[common]>a[common]+2e-5).sum()),
                     'gained45':int(((b<=45)&~(a<=45)).sum()),'lost45':int(((a<=45)&~(b<=45)).sum())},
            'largestCrossings':crossings,'exampleTraces':traces,'districtReachability':district_rows,
            'scope':'Fixed 209 destinations and source weekday catalogue; only start shifted by five minutes. '
                    'All origins included in original order. District reachability ignores bed/physician capacity '
                    'and is only a necessary access diagnostic with full denominators. No reassignment LP, '
                    'placement optimization, cost change, minimum hospital count, all-day reliability or real '
                    'EGO completeness claim. Estimated offsets and missing services remain unchanged.'}
    FULL_REPORT.write_text(json.dumps(report,ensure_ascii=False,allow_nan=False,indent=2)+'\n',encoding='utf8')
    gate()
    print(json.dumps({'report':str(FULL_REPORT),'sha256':pilot.sha(FULL_REPORT),
                      'arraysSHA256':report['arraysSHA256'],'seconds':report['seconds'],'pairs':report['pairs']}))


if __name__=='__main__':
    if sys.argv[1:]==['--worker']:
        run_worker()
    else:
        assert not sys.argv[1:], 'No adjustable production or model arguments'
        assert not FULL_REPORT.exists() and not FULL_ARRAYS.exists(), 'Immutable output already exists'
        try:
            completed=subprocess.run([sys.executable,str(Path(__file__).resolve()),'--worker'],
                                     cwd=ROOT,timeout=BUDGET_SECONDS,env={**os.environ,'PYTHONHASHSEED':'0'})
        except subprocess.TimeoutExpired:
            print('Research timeout: any partial work output is unaccepted; no capacity conclusion',file=sys.stderr)
            sys.exit(124)
        sys.exit(completed.returncode)
