"""Work-only single departure sensitivity on previously validated fixed resources.

No production profile is renamed; no original flow vector is copied to different
edge offsets. The source is valid at its original time, not presumed valid here.
This module never reads/writes production files and never changes resources.
"""
from types import SimpleNamespace
from time import monotonic
import math
import numpy as np
from backend import joint_travel as travel
from backend.joint_model import positive


def prepare(problem, source_vector, source_profile, shifted_times, research_profile='weekday-0805'):
    p=problem
    p.validate(source_vector)
    if source_profile not in p.times or not isinstance(research_profile,str) or not research_profile or research_profile in p.times:
        raise ValueError('Separate genuine research profile required')
    times=np.asarray(shifted_times,float).copy()
    if times.shape!=(p.n,p.m) or np.any(np.isnan(times)) or np.any(times<0):
        raise ValueError('Shifted matrix dimensions/finite-or-positive-infinity values invalid')
    if p.target<=0:raise ValueError('Positive exact target required')
    opened,beds,docs=(a.copy() for a in p.resources(source_vector))
    edges=np.where(np.isfinite(times)&(times<=p.s['threshold']))
    adapter=SimpleNamespace(n=p.n,m=p.m,pop=p.pop,dd=p.dd,districts=p.districts,
        target=p.target,s=p.s,occupancy=p.occupancy,bedrate=p.bedrate,q=p.q,
        times={research_profile:times},edges={research_profile:edges},
        resources=lambda ignored:(opened,beds,docs))
    context=SimpleNamespace(p=p,source=source_vector.copy(),profile=research_profile,
        source_profile=source_profile,times=times,adapter=adapter,opened=opened,beds=beds,docs=docs,
        annual_cost=p.cost(source_vector),material=p.material,source_prefix=source_vector[:p.nf].copy())
    context.times_snapshot=times.copy()
    context.resource_snapshot=tuple(a.copy() for a in (opened,beds,docs))
    # Production formulation has a deliberate positive-edge precondition. Empty
    # derived support is recorded without manufacturing an infeasibility proof.
    context.lp=travel.formulate_profile(adapter,None,research_profile) if np.any(opened[edges[1]]) else None
    context.baseline=reevaluate_source(context)
    return context


def check_flow(context, flow):
    """Original scaled-row and physical percentage/resource tolerances, unchanged."""
    c=context;p=c.p;lp=c.lp
    if not np.array_equal(c.times,c.times_snapshot):raise ValueError('Shifted matrix changed in memory')
    if any(not np.array_equal(a,b) for a,b in zip((c.opened,c.beds,c.docs),c.resource_snapshot)):
        raise ValueError('Fixed resources changed in memory')
    if any(not np.array_equal(a,b) for a,b in zip(p.resources(c.source),c.resource_snapshot)):
        raise ValueError('Source resources differ from fixed snapshot')
    if lp is None:raise ValueError('No represented positive-target edges')
    f=np.asarray(flow,float)
    if f.shape!=lp['c'].shape or np.any(~np.isfinite(f)) or np.any(f<0):
        raise ValueError('Strict finite nonnegative flow required; no clipping')
    row=float(np.maximum(lp['A']@f-lp['b'],0).max(initial=0))
    eq=float(np.abs(lp['E']@f-lp['d']).max(initial=0))
    box=float(np.maximum(f-lp['upper'],0).max(initial=0))
    if row>1e-7 or eq>1e-7 or box>1e-8:raise ValueError('Scaled original assignment constraints violated')
    a,b=lp['edgeOrigin'],lp['edgeSite'];residents=f*1000
    served=np.bincount(a,weights=residents,minlength=p.n);loads=np.bincount(b,weights=residents,minlength=p.m)
    if np.any(served>p.pop+.001) or abs(served.sum()-p.target)>.001:raise ValueError('Exact province/origin target violated')
    if any(served[p.dd==d['id']].sum()/d['population']*100<p.s['districtFloor']-1e-6 for d in p.districts):
        raise ValueError('Original percentage district floor violated')
    if np.any(loads*p.contact>c.docs*p.s['contactsPerDoctor']+.1) or np.any(loads*p.bedrate>c.beds*365*p.occupancy+.1):
        raise ValueError('Separate bed/physician capacity violated')
    if np.any(f[~c.opened[b]]>0):raise ValueError('Closed-site flow')
    if not np.array_equal(c.source[:p.nf],c.source_prefix) or p.cost(c.source)!=c.annual_cost:
        raise ValueError('Source resources/cost changed')
    return {'maximumRowViolation':row,'maximumEqualityViolation':eq,'maximumBoxViolation':box,
        'servedEquivalent':float(served.sum()),'meanMinutes':float(lp['c']@f),
        'districts':[{'id':d['id'],'coveragePercent':float(served[p.dd==d['id']].sum()/d['population']*100)} for d in p.districts]}


def allocations(context, flow):
    lp=context.lp;p=context.p
    rows=[{'demandIndex':int(i),'candidateIndex':int(p.ids[j]),'population':float(v*1000),
        'minutes':float(context.times[i,j])} for i,j,v in zip(lp['edgeOrigin'],lp['edgeSite'],flow) if v>0]
    # Actual serialized quantities must pass the same gates; no dropped tiny flow.
    index={(int(i),int(p.ids[j])):k for k,(i,j) in enumerate(zip(lp['edgeOrigin'],lp['edgeSite']))}
    back=np.zeros(len(flow))
    for record in rows:back[index[record['demandIndex'],record['candidateIndex']]]=record['population']/1000
    check_flow(context,back)
    if np.max(np.abs(back-flow),initial=0)>1e-12:raise ValueError('Serialized single-profile roundtrip differs')
    return rows


def reevaluate_source(context):
    c=context;p=c.p;oi,sj=p.edges[c.source_profile]
    old=c.source[p.offsets[c.source_profile]:p.offsets[c.source_profile]+len(oi)]
    index={} if c.lp is None else {(int(i),int(j)):k for k,(i,j) in enumerate(zip(c.lp['edgeOrigin'],c.lp['edgeSite']))}
    mapped=None if c.lp is None else np.zeros(len(c.lp['c']))
    unsupported=0.;missing=0
    for i,j,v in zip(oi,sj,old):
        if v<=0:continue
        k=index.get((int(i),int(j)))
        if k is None:unsupported+=float(v*1000);missing+=1
        else:mapped[k]=v
    base={'sourceProfile':c.source_profile,'researchProfile':c.profile,
        'unsupportedAssignedEquivalent':unsupported,'unsupportedPositiveEdges':missing,
        'sourceMeanAtOriginalDeparture':float(old@p.times[c.source_profile][oi,sj]/(p.target/1000)),
        'feasibleAtShiftedDeparture':False,'meanAtShiftedDeparture':None,'flow':None}
    if missing or mapped is None:return base
    try:metrics=check_flow(c,mapped);allocations(c,mapped)
    except ValueError:return base
    return dict(base,feasibleAtShiftedDeparture=True,meanAtShiftedDeparture=metrics['meanMinutes'],flow=mapped)


def evaluate(context, seconds=15, overall_seconds=60, clock=monotonic, solver=None):
    if positive(seconds,'native seconds')>15 or positive(overall_seconds,'overall seconds')>60:
        raise ValueError('At most 15 native / 60 overall seconds')
    c=context;began=clock();deadline=began+overall_seconds
    base={'researchProfile':c.profile,'sourceProfile':c.source_profile,'resourcesUnchanged':True,
        'annualEquivalentCostTRY':c.annual_cost,'annualMaterialCostTRY':c.material,
        'annualDemandCountedOnce':True,'resourceCleanupPerformed':False,'otherThreeProfilesReSolved':False,
        'realCityInfeasibilityProven':False,'wholeLocationResourceOptimumProven':False,
        'boundScope':'Only the supplied derived departure matrix and unchanged source locations/beds/physicians.',
        'baseline':{k:v for k,v in c.baseline.items() if k!='flow'}}
    def fallback(reason,status=None):
        valid=c.baseline['feasibleAtShiftedDeparture']
        return dict(base,status='validated_shifted_source_preserved' if valid else 'inconclusive_without_validated_primal',
            reason=reason,feasible=True if valid else None,sourceFallback=bool(valid),nativeStatus=status,
            nativeReportedInfeasible=status==2,solverReportedOptimal=False,certificateAccepted=False,
            meanMinutes=c.baseline['meanAtShiftedDeparture'] if valid else None,
            allocations=allocations(c,c.baseline['flow']) if valid else None,
            certificate=None,inequalityDual=None,equalityDual=None,signedGapMinutes=None,
            elapsedSeconds=clock()-began)
    if c.lp is None:return fallback('No represented positive-target edges; no native LP or independent infeasibility certificate')
    remaining=min(seconds,deadline-clock())
    if remaining<=0:return fallback('Deadline before native call')
    native_deadline=clock()+remaining
    try:solved=(solver or travel._solve)(c.lp,remaining)
    except (ValueError,RuntimeError) as exc:return fallback('Native error: '+str(exc))
    if clock()>native_deadline:return fallback('Cooperative native deadline exceeded; candidate not accepted',solved.status)
    if solved.status!=0 or solved.x is None:return fallback('No validated optimal native candidate',solved.status)
    try:
        f=np.asarray(solved.x,float);metrics=check_flow(c,f);rows=allocations(c,f)
        proof=travel.exact_box_dual(c.lp['c'],c.lp['A'],c.lp['b'],c.lp['E'],c.lp['d'],c.lp['upper'],
            solved.ineqlin.marginals,solved.eqlin.marginals)
        mean=metrics['meanMinutes'];gap=mean-proof['lowerBoundMinutes']
        if gap < -1e-7:raise ValueError('Dual bound contradicts checked numerical primal')
        # A changed departure can worsen the old-time optimum. Only a feasible
        # baseline re-evaluated with these SAME new times bounds improvement.
        if c.baseline['feasibleAtShiftedDeparture'] and mean>c.baseline['meanAtShiftedDeparture']:
            raise ValueError('Candidate worsens validated shifted baseline')
    except (ValueError,TypeError,AttributeError) as exc:return fallback(str(exc),solved.status)
    if clock()>deadline:return fallback('Postcheck deadline exceeded; candidate not accepted',solved.status)
    return dict(base,status='research_profile_accepted',reason=None,feasible=True,sourceFallback=False,
        nativeStatus=solved.status,nativeReportedInfeasible=False,solverReportedOptimal=True,certificateAccepted=True,
        meanMinutes=mean,allocations=rows,physicalResiduals=metrics,certificate=proof,
        inequalityDual=np.asarray(solved.ineqlin.marginals,float).tolist(),equalityDual=np.asarray(solved.eqlin.marginals,float).tolist(),
        signedGapMinutes=gap,primalDualToleranceMinutes=1e-7,elapsedSeconds=clock()-began)
