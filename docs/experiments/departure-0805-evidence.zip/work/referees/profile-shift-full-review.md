# Full selected-target 08:05 experiment: transport handback

23 October 2026. One parent-authorized work-only routing run completed with exit 0. No native LP, placement search, production profile or production file change occurred. The original eight-origin pilot files remained unchanged.

The fixed package is `ego-da0980e2b9057e21065f4b018a9e935d994f89f52572e08db4546710cf3eb997`.

| Artifact | SHA-256 |
|---|---|
| `profile_shift_full.py` | `17682df86fd1209dc3f33e37e7904e68b0d33cc0edb8dfcd865fd678fbad1ea1` |
| `profile-shift-full-v07.json` | `b9f60e61b3bbee0c3aadf670e8f400338fa95dae015bdd590d3d5243096e4eb0` |
| `profile-shift-full-v07.npz` | `51b24496428a2d84f614c6809779aea5576512a8867bf7d6b0a519179070faab` |

The NPZ contains `originIndices = 0..1412`, `targetCandidateIndices` in the unchanged accepted plan's 209-site order, and `minutes0800` / `minutes0805`, both 1,413 × 209. The JSON additionally binds each origin's ID/population/district and each target's ID, 17 input hashes, three code hashes, and both profile start clocks. Every stop, pattern and transfer is retained; only destination columns are restricted to the existing 209 sites.

The isolated subprocess had a hard 300-second deadline. Measured time was **44.322 seconds**: 12.682 for the 08:00 matrix, 13.748 for 08:05 and 15.808 for independent event checks. Seven small tests passed before execution. The evidence referee reviewed the frozen code before this one authorized run; actual-result review is separate.

## Validation scope

- All 295,317 baseline 08:00 elements match the current published matrix slice exactly.
- The original eight pilot rows match exactly at both start times.
- All finite results are nonnegative and within the 120-minute relative horizon; no NaN is accepted.
- All common finite pairs satisfy FIFO absolute arrival: `08:05 + elapsed08:05 >= 08:00 + elapsed08:00` within float32 tolerance.
- Sixteen distinct origins, including the eight pilot origins and origins of the largest threshold crossings, were checked at both starts using the separate heap event search. These 32 × 209 comparisons have matching finite sets and a maximum difference of 0.0000037847 minutes. This is not an independently recomputed all-pairs claim.
- Package, all 17 source identities and three code identities match again at completion. The production profile dictionary was restored; the parent process running the application was never modified.

## Sensitivity observed

Of 295,317 origin/selected-target pairs, 14,653 remain finite within the 120-minute horizon, 332 become finite and 370 cease to be finite. The later horizon ends five minutes later. Among common finite pairs, 8,760 elapsed times decrease and 4,268 increase; shorter elapsed time does not mean earlier absolute arrival.

At 45 minutes, **286 connections enter and 275 leave**. This small positive net connection count does not mean service coverage improves. The population at a represented origin with at least one selected target within 45 minutes falls from **5,686,361 to 5,667,638**. Six origin rows (`350, 830, 840, 1230, 1236, 1360`) representing **18,723 people** lose their final threshold-accessible selected target; no origin gains first access. The unchanged provincial denominator is 5,910,320, including unmatched population; these reachability numbers ignore bed/physician competition.

For example, origins 830 and 840 to candidate 1867 move from 37.488 minutes to no route inside the shifted 120-minute horizon. The report records both route traces and the explicit unknown-horizon meaning. These are model paths, not observed service cancellation or proof that no bus operates.

## Interpretation and next gate

This experiment shows that passing four exact start profiles does not establish reliability five minutes later. It perturbs only the passenger start; the partial service catalogue, estimated stop times and all access assumptions are unchanged. It does not measure delay uncertainty, a new calendar, full-day reliability or real EGO completeness.

The new topological upper coverage remains above the original provincial target of 5,614,804 residents. That alone does not establish fixed-capacity feasibility: some reachable hospitals may have no spare bed or physician capacity. Conversely, losses on previously used edges do not by themselves prove failure because legal reassignment may exist. Any fixed-resource allocation LP requires its own authorization and independent numerical audit; none was run here.
