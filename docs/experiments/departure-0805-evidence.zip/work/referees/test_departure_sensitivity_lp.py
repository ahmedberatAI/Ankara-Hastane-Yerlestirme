from pathlib import Path
from types import SimpleNamespace
import sys
import numpy as np
import pytest
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(Path(__file__).parent)]
from test_joint_model import fixture,PROFILES
from backend import joint_travel as travel
import departure_sensitivity_lp as d


def example():return fixture({name:np.array([[1.,30.],[30.,1.]]) for name in PROFILES})


def test_same_time_coefficients_exact_frozen_production():
    p,seed,v,_=example();c=d.prepare(p,v,PROFILES[0],p.times[PROFILES[0]])
    original=travel.formulate_profile(p,v,PROFILES[0])
    for key in ('A','E'):
        for part in ('indptr','indices','data'):assert np.array_equal(getattr(c.lp[key],part),getattr(original[key],part))
    for key in ('c','b','d','upper','edgeOrigin','edgeSite'):assert np.array_equal(c.lp[key],original[key])
    assert c.baseline['feasibleAtShiftedDeparture']


def test_lost_old_edges_new_alternative_is_feasible_no_source_fallback():
    p,seed,v,_=example();original=v.copy();times=np.array([[np.inf,4.],[7.,46.]])
    c=d.prepare(p,v,PROFILES[0],times);assert not c.baseline['feasibleAtShiftedDeparture']
    assert c.baseline['unsupportedAssignedEquivalent']==2
    result=d.evaluate(c)
    assert result['status']=='research_profile_accepted' and result['meanMinutes']==pytest.approx(5.5)
    assert not result['sourceFallback'] and result['annualEquivalentCostTRY']==p.cost(v)
    assert np.array_equal(v,original) and np.array_equal(p.times[PROFILES[0]],[[1,30],[30,1]])
    assert result['meanMinutes']>c.baseline['sourceMeanAtOriginalDeparture']


@pytest.mark.parametrize('native_status',[1,2,4])
def test_invalid_old_flow_never_becomes_feasible_fallback(native_status):
    p,seed,v,_=example();c=d.prepare(p,v,PROFILES[0],np.array([[np.inf,4.],[7.,np.inf]]))
    r=d.evaluate(c,solver=lambda *a:SimpleNamespace(status=native_status,x=None))
    assert r['feasible'] is None and r['allocations'] is None and r['meanMinutes'] is None
    assert not r['sourceFallback'] and not r['realCityInfeasibilityProven']
    assert r['nativeReportedInfeasible']==(native_status==2)


def test_valid_new_baseline_preserves_full_flow_with_new_times_on_unknown():
    p,seed,v,_=example();c=d.prepare(p,v,PROFILES[0],np.array([[8.,30.],[30.,9.]]))
    r=d.evaluate(c,solver=lambda *a:SimpleNamespace(status=1,x=None))
    assert r['sourceFallback'] and r['feasible'] and r['meanMinutes']==8.5
    assert [a['minutes'] for a in r['allocations']]==[8.,9.]
    assert [a['population'] for a in r['allocations']]==[1.,1.]


def test_zero_edges_fail_closed_without_solver():
    p,seed,v,_=example();c=d.prepare(p,v,PROFILES[0],np.full((2,2),np.inf))
    r=d.evaluate(c,solver=lambda *a:pytest.fail('No native call on empty edges'))
    assert r['feasible'] is None and not r['nativeReportedInfeasible']


@pytest.mark.parametrize('bad',[np.array([[np.nan,1],[2,3]]),np.array([[-1,1],[2,3]]),np.zeros((1,2))])
def test_matrix_guards(bad):
    p,_,v,_=example()
    with pytest.raises(ValueError):d.prepare(p,v,PROFILES[0],bad)


def test_profile_cannot_falsely_reuse_canonical_name():
    p,_,v,_=example()
    with pytest.raises(ValueError):d.prepare(p,v,PROFILES[0],p.times[PROFILES[0]],PROFILES[0])


def test_negative_tiny_flow_not_clipped():
    p,_,v,_=example();c=d.prepare(p,v,PROFILES[0],p.times[PROFILES[0]])
    f=c.baseline['flow'].copy();f[1]=-1e-13
    with pytest.raises(ValueError):d.check_flow(c,f)


def test_percentage_district_guard_not_only_absolute_population():
    p,_,v,_=example();c=d.prepare(p,v,PROFILES[0],p.times[PROFILES[0]])
    f=c.baseline['flow'].copy();f[0]-=5e-8;f[2]+=5e-8
    with pytest.raises(ValueError,match='district'):d.check_flow(c,f)


def test_resource_capacity_is_not_increased_to_make_shift_feasible():
    p,_,v,_=example();c=d.prepare(p,v,PROFILES[0],np.array([[1.,np.inf],[1.,np.inf]]))
    c.docs[0]=1
    # A returned assignment may not use the other site's doctors.
    with pytest.raises(ValueError):d.check_flow(c,np.array([.001,.001]))


def test_postcheck_deadline_preserves_only_valid_shifted_baseline():
    p,_,v,_=example();c=d.prepare(p,v,PROFILES[0],p.times[PROFILES[0]]);now=[0.]
    def slow(lp,seconds):
        solved=travel._solve(lp,seconds);now[0]=61.;return solved
    r=d.evaluate(c,solver=slow,clock=lambda:now[0]);assert r['sourceFallback'] and not r['certificateAccepted']


def test_limits_rejected_before_native():
    p,_,v,_=example();c=d.prepare(p,v,PROFILES[0],p.times[PROFILES[0]])
    for kwargs in ({'seconds':16},{'overall_seconds':61},{'seconds':True}):
        with pytest.raises(ValueError):d.evaluate(c,**kwargs)


@pytest.mark.parametrize('case',['matrix','doctors','beds','open'])
def test_in_memory_source_or_matrix_mutation_is_rejected(case):
    p,_,v,_=example();c=d.prepare(p,v,PROFILES[0],p.times[PROFILES[0]])
    if case=='matrix':c.times[0,0]=99
    elif case=='doctors':c.docs[0]+=1
    elif case=='beds':c.beds[0]+=1
    else:c.opened[0]=False
    with pytest.raises(ValueError):d.allocations(c,c.baseline['flow'])
