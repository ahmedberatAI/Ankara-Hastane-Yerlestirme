"""Work-only eight-origin/+5-minute routing pilot; no capacity solve or data writes."""
from collections import defaultdict
from contextlib import contextmanager
from datetime import datetime, timezone
import bisect
import hashlib
import heapq
import json
from pathlib import Path
import sys
import time

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from backend import timetable
from scripts.transit_provenance import check_package

ORIGINS = (42, 295, 54, 510, 1239, 638, 963, 228)
KEY = 'research-weekday-0805'
SOURCE_FILES = ('dataset.json', 'health-planning.json', 'example-transit-result.json',
                'transit-package.json', 'joint-plan.json', 'travel-plan.json',
                'travel-proof.json', 'travel-summary.json', 'ego-network.json.gz',
                'ego-access.npz', 'ego-egress.npz', 'ego-transfers.npz', 'ego-direct.npz',
                'transit-weekday-0800-matrix.npz', 'transit-weekday-1000-matrix.npz',
                'transit-saturday-1000-matrix.npz', 'transit-sunday-1000-matrix.npz')


def sha(path, semantic=False):
    content = path.read_bytes()
    return hashlib.sha256(content.replace(b'\r\n', b'\n') if semantic else content).hexdigest()


@contextmanager
def temporary_profile():
    original = timetable.PROFILES
    assert KEY not in original
    timetable.PROFILES = {**original, KEY: {'day': 'weekday', 'seconds': 8*3600+300,
                                          'label': 'Research only weekday 08:05'}}
    try:
        yield
    finally:
        timetable.PROFILES = original


def independent_events(network, access, egress, transfers, direct, origin, start, day='weekday'):
    """Separate event queue, not route_one/route_batch; one transfer footpath per ride."""
    occurrences = defaultdict(list)
    for pi, pattern in enumerate(network['patterns']):
        for position, stop in enumerate(pattern['stops']):
            occurrences[stop].append((pi, position))
    deadline = start + 7200
    best = np.full((4, 2, len(network['stops'])), np.inf)
    destinations = np.full(egress.shape[1], np.inf)
    queue = []

    def push(boardings, phase, stop, at):
        if at < best[boardings, phase, stop] and at <= deadline:
            best[boardings, phase, stop] = at
            heapq.heappush(queue, (at, boardings, phase, int(stop)))

    for stop, seconds in zip(access[origin].indices, access[origin].data):
        push(0, 0, stop, start + seconds)
    row = direct[origin]
    destinations[row.indices] = start + row.data
    while queue:
        at, boardings, phase, stop = heapq.heappop(queue)
        if at != best[boardings, phase, stop]:
            continue
        if phase == 1:
            row = egress[stop]
            destinations[row.indices] = np.minimum(destinations[row.indices], at + row.data)
            if boardings < 3:
                push(boardings, 0, stop, at)
                row = transfers[stop]
                for other, seconds in zip(row.indices, row.data):
                    push(boardings, 0, other, at + seconds)
        elif boardings < 3:
            for pi, position in occurrences[stop]:
                pattern = network['patterns'][pi]
                departures = pattern['departures'][day]
                selected = bisect.bisect_left(departures, at + 60 - pattern['offsets'][position])
                if selected == len(departures):
                    continue
                trip = departures[selected]
                for other, offset in zip(pattern['stops'][position+1:], pattern['offsets'][position+1:]):
                    push(boardings+1, 1, other, trip+offset)
    destinations[destinations > deadline] = np.inf
    return (destinations-start)/60


def compare(actual, expected):
    assert actual.shape == expected.shape
    assert not np.isnan(actual).any() and np.all(actual >= 0)
    assert np.array_equal(np.isfinite(actual), np.isfinite(expected))
    finite = np.isfinite(actual)
    maximum = float(np.max(np.abs(actual[finite]-expected[finite]), initial=0))
    assert maximum <= 2e-5, maximum
    return maximum


def run():
    output = ROOT/'work/referees/profile-shift-pilot-v07.json'
    arrays = output.with_suffix('.npz')
    assert not output.exists() and not arrays.exists(), 'Immutable pilot output already exists'
    observed = datetime.now(timezone.utc).isoformat()
    started = time.perf_counter()
    package_id = check_package()
    data_dir = ROOT/'data/processed'
    before = {name: sha(data_dir/name) for name in SOURCE_FILES}
    model_sha = sha(ROOT/'backend/timetable.py', True)
    code_sha = sha(Path(__file__), True)
    data = json.loads((data_dir/'dataset.json').read_text(encoding='utf8'))
    plan = json.loads((data_dir/'travel-plan.json').read_text(encoding='utf8'))
    assert plan['transitPackageId'] == package_id
    assert plan['sourceCostCertificateSHA256'] == before['joint-plan.json']
    for name, digest in plan['sourceSHA256'].items():
        assert before[name] == digest, name
    selected = plan['plan']['selected']
    targets = [site['candidateIndex'] for site in selected]
    assert len(selected) == plan['plan']['hospitalCount'] == 209
    assert len(targets) == len(set(targets)) and all(type(i) is int for i in targets)
    assert all(data['candidates'][i]['id'] == site['id'] for i, site in zip(targets, selected))
    assert len(set(ORIGINS)) == 8 and all(0 <= i < len(data['demands']) for i in ORIGINS)
    network, all_access, all_egress, transfers, all_direct = timetable.load_network()
    access = all_access[list(ORIGINS)]
    egress = all_egress[:, targets].tocsr()
    direct = all_direct[list(ORIGINS)][:, targets].tocsr()
    stored = np.load(data_dir/'transit-weekday-0800-matrix.npz')['minutes'][np.ix_(ORIGINS, targets)]
    timings = {}; matrices = {}
    with temporary_profile():
        for label, profile in (('0800', 'weekday-0800'), ('0805', KEY)):
            t = time.perf_counter()
            matrices[label] = timetable.route_batch(network, access, egress, transfers, direct,
                                                    profile, batch_size=len(ORIGINS))
            timings[label] = time.perf_counter()-t
    assert KEY not in timetable.PROFILES
    baseline_error = compare(matrices['0800'], stored)
    event_audit = []
    event_started = time.perf_counter()
    for label, start in (('0800', 8*3600), ('0805', 8*3600+300)):
        for local, origin in enumerate(ORIGINS):
            expected = independent_events(network, access, egress, transfers, direct, local, start)
            error = compare(matrices[label][local], expected)
            event_audit.append({'profile': label, 'originIndex': origin, 'targets': len(targets),
                                'maxMinutesError': error})
    independent_seconds = time.perf_counter()-event_started
    a, b = matrices['0800'], matrices['0805']
    common = np.isfinite(a) & np.isfinite(b)
    deltas = []
    for local, origin in enumerate(ORIGINS):
        row = data['demands'][origin]
        deltas.append({'originIndex': origin, 'demandId': row['id'], 'name': row['name'],
                       'district': row['district'], 'population': row['population'],
                       'reachable45At0800': int(np.sum(a[local] <= 45)),
                       'reachable45At0805': int(np.sum(b[local] <= 45)),
                       'gained45Targets': [targets[i] for i in np.flatnonzero((b[local] <= 45) & ~(a[local] <= 45))],
                       'lost45Targets': [targets[i] for i in np.flatnonzero((a[local] <= 45) & ~(b[local] <= 45))]})
    # A later start cannot arrive earlier in absolute time on this FIFO model.
    # A +5-minute shifted deadline can, however, reveal additional 120-minute trips.
    assert np.all(b[common] + 5 >= a[common] - 2e-5)
    assert check_package() == package_id
    assert before == {name: sha(data_dir/name) for name in SOURCE_FILES}
    assert model_sha == sha(ROOT/'backend/timetable.py', True)
    assert code_sha == sha(Path(__file__), True)
    np.savez_compressed(arrays, originIndices=np.asarray(ORIGINS), targetCandidateIndices=np.asarray(targets),
                        minutes0800=a, minutes0805=b)
    report = {'format': 1, 'kind': 'work_only_eight_origin_five_minute_start_shift_pilot',
              'startedAt': observed, 'completedAt': datetime.now(timezone.utc).isoformat(),
              'transitPackageId': package_id, 'sourceSHA256': before,
              'routingCodeLF_SHA256': model_sha, 'pilotCodeLF_SHA256': code_sha,
              'arraysSHA256': sha(arrays), 'temporaryProfile': {'day': 'weekday', 'startSeconds': 29100},
              'retainedScope': {'stops': len(network['stops']), 'patterns': len(network['patterns']),
                                'allTransferEdges': transfers.nnz, 'targetSites': len(targets),
                                'originCount': len(ORIGINS), 'originIndices': list(ORIGINS),
                                'targetCandidateIndices': targets},
              'seconds': {'batch0800': timings['0800'], 'batch0805': timings['0805'],
                          'independentEventChecks': independent_seconds, 'total': time.perf_counter()-started},
              'baselineMatrixMaxMinutesError': baseline_error, 'eventChecks': event_audit,
              'pairs': {'total': a.size, 'commonFinite120': int(common.sum()),
                        'newFinite120': int((np.isfinite(b)&~np.isfinite(a)).sum()),
                        'lostFinite120': int((np.isfinite(a)&~np.isfinite(b)).sum()),
                        'shorterElapsed': int((b[common] < a[common]-2e-5).sum()),
                        'longerElapsed': int((b[common] > a[common]+2e-5).sum()),
                        'gained45': int(((b<=45)&~(a<=45)).sum()),
                        'lost45': int(((a<=45)&~(b<=45)).sum())},
              'origins': deltas,
              'scope': 'Only eight purposively chosen origins and 209 existing targets; not a population sample, '
                       'not a capacity reassignment, no new optimum or city coverage claim. The same partial '
                       'weekday service catalogue, estimated offsets, access/egress and boarding assumptions '
                       'are retained. Elapsed journey time can rise or fall when departure shifts. No source '
                       'time uncertainty or real observed 08:05 timetable is added. Full 1413-origin matrix '
                       'and native LP were not run. Runtime is this small pilot only, not a linear full-run estimate.'}
    output.write_text(json.dumps(report, ensure_ascii=False, allow_nan=False, indent=2)+'\n', encoding='utf8')
    print(json.dumps({'output': str(output), 'sha256': sha(output), 'seconds': report['seconds'],
                      'pairs': report['pairs'], 'baselineError': baseline_error}, ensure_ascii=True))


if __name__ == '__main__':
    run()
