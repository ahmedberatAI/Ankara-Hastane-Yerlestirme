# Final three-referee evidence

All paths are repository-relative. In a fresh clone, extract at the repository root; copy externalPublishedFiles publishedPath entries to the listed work paths after checking SHA256. Preserve existing unrelated work. The archive includes the original worker.log and plain runner audit.json which are not part of the production publication.

The three Python reviewers were run without native optimization. They require the current production sources/data and the seed evidence ZIP identified in archive-manifest.json. Run them at their original work/referees paths. Their scripts write their own audit JSON reports; run on a separate fresh copy to preserve the saved originals. They verify feasibility and arithmetic; solver-reported lower bounds are not independent dual certificates.

The production audit command in docs/departure-window-plan.md is the simplest read-only check. The historical negative 08:05 experiment is unchanged. New 226 resources close that sampled gap under the declared model, not in measured actual EGO/clinical conditions.
