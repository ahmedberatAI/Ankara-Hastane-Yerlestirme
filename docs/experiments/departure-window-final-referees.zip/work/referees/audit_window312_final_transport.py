"""Independent arithmetic/identity/flow audit: no model, solver or router import."""
from pathlib import Path
from datetime import datetime,timezone
from decimal import Decimal,getcontext
import hashlib,io,json,math,zipfile
import numpy as np
from pyproj import Transformer

ROOT=Path(__file__).resolve().parents[2]
SHA=lambda b:hashlib.sha256(b).hexdigest()
D=lambda x:Decimal(str(x))
getcontext().prec=45


def main():
    folder=ROOT/'work/window-plans/joint312-v4';base=ROOT/'work/window-routing/full-v1'
    files={name:(folder/name).read_bytes() for name in ['run-result.json','vectors.npz','window-plan.json','resource-seed.json','candidate-pool.json','process-status.json','solver.log']}
    report=json.loads(files['run-result.json']);cert=json.loads(files['window-plan.json']);plan=cert['plan'];source=json.loads(files['resource-seed.json']);status=json.loads(files['process-status.json'])
    manifest_bytes=(base/'manifest.json').read_bytes();M=json.loads(manifest_bytes)
    assert SHA(manifest_bytes)==report['profileManifestSHA256']==cert['profileManifestSHA256']=='29eb7c5a298536ab6a93a998fef1e39ef18a5ea3edd8d9eaf4b78db484bcc7f1'
    assert SHA(files['vectors.npz'])==report['vectorSHA256']==cert['generation']['vectorSHA256']
    assert SHA(files['run-result.json'])==cert['generation']['runReportSHA256']
    assert status['returnCode']==0 and status['status']=='completed' and SHA(files['solver.log'])==report['solverLogSHA256']
    assert SHA(files['resource-seed.json'])==report['resourceSeedSHA256'] and SHA(files['candidate-pool.json'])==report['candidatePoolSHA256']
    assert 'MIP start solution is feasible' in files['solver.log'].decode() and 'Time limit reached' in files['solver.log'].decode()
    for p,h in report['modelCodeSHA256'].items():assert SHA((ROOT/p).read_bytes().replace(b'\r\n',b'\n'))==h,p
    assert report['modelCodeSHA256']==cert['modelCodeSHA256']
    src={}
    for p,h in report['sourceSHA256'].items():
        src[p]=(ROOT/'data/processed'/p).read_bytes();assert SHA(src[p])==h,p
    assert report['sourceSHA256']==cert['sourceSHA256']
    data=json.loads(src['dataset.json']);health=json.loads(src['health-planning.json']);scenario=cert['scenario'];C=data['candidates']
    assert scenario==source['scenario'] and scenario['threshold']==45 and scenario['coverageTarget']==95 and scenario['districtFloor']==80
    pool=report['candidateIndices'];assert len(pool)==312 and pool==sorted(set(pool))==cert['generation']['candidateIndices']
    names=M['producedProfileIds'];assert len(names)==44 and [p['profile'] for p in plan['profiles']]==names==report['validatedProfiles']==report['optimizedProfiles']
    pop=[D(x['population']) for x in data['demands']];total=D(data['metadata']['provincePopulation']);target=total*D('.95')
    districts={d['id']:d for d in data['districts']};assert sum(D(d['population']) for d in districts.values())==total
    design=health['design'];rates=health['rates'];eco=health['economics'];templates=health['templates'];tid={t['id']:i for i,t in enumerate(templates)}
    contact=D(rates['contactsPerResident'])*D(scenario['demandMultiplier']);bedrate=D(rates['bedDaysPerResident'])*D(scenario['demandMultiplier'])
    areas=np.array([t['grossAreaM2'] for t in templates],float);available=np.pi*np.array([C[j]['footprintRadiusMeters'] for j in pool])**2*design['maxFloors']
    xs,ts=np.where(areas[None,:]+design['minimumDoctorsPerSite']*design['areaPerDoctorM2']<=available[:,None]+.001)
    nx=len(xs);nf=nx+len(pool);local={j:k for k,j in enumerate(pool)};prefix_index={(int(j),int(t)):i for i,(j,t) in enumerate(zip(xs,ts))}
    with np.load(io.BytesIO(files['vectors.npz']),allow_pickle=False) as z:
        expected_keys={'finalOriginalVector','suppliedOriginalVector','returnedRawVector','costStageOriginalVector','costStageNativeValidatedVector'}
        assert set(z.files)==expected_keys
        vectors={k:z[k].copy() for k in z.files}
    final=vectors['finalOriginalVector'];raw=vectors['returnedRawVector'];supplied=vectors['suppliedOriginalVector'];cost=vectors['costStageOriginalVector']
    assert all(v.shape==final.shape and np.isfinite(v).all() and (v>=0).all() for v in vectors.values())
    assert np.array_equal(supplied,raw)
    assert np.array_equal(raw[nf:],cost[nf:])
    assert np.array_equal(cost,vectors['costStageNativeValidatedVector'])
    assert np.array_equal(cost[:nf],final[:nf])
    vector_checks={k:dict(maximumTargetErrorResidents=0.,maximumOriginOvershootResidents=0.,minimumDistrictPercent=100.,minimumBedSlackDays=math.inf,minimumDoctorSlackContacts=math.inf) for k in vectors}
    vector_resources={}
    for key,v in vectors.items():
        assert np.array_equal(v[:nf],np.rint(v[:nf])) and (v[:nx]<=1).all()
        opened=np.bincount(xs,weights=v[:nx],minlength=len(pool));beds=np.bincount(xs,weights=np.array([t['beds'] for t in templates])[ts]*v[:nx],minlength=len(pool));doctors=v[nx:nf]
        assert (opened<=1).all() and (doctors>=opened*design['minimumDoctorsPerSite']).all()
        assert np.all(doctors[opened==0]==0)
        gross=np.bincount(xs,weights=areas[ts]*v[:nx],minlength=len(pool))+doctors*design['areaPerDoctorM2']
        assert np.all(gross<=available+.001)
        bound=np.minimum(np.floor(np.nextafter((available+.001-areas.min())/design['areaPerDoctorM2'],np.inf)),max(design['minimumDoctorsPerSite'],math.ceil(float(target)*(rates['contactsPerResident']*scenario['demandMultiplier'])/scenario['contactsPerDoctor'])))
        assert np.all(doctors<=bound)
        vector_resources[key]=(opened,beds,doctors,gross)
        vector_checks[key].update(hospitalCount=int(opened.sum()),beds=int(beds.sum()),doctors=int(doctors.sum()))
    recon=np.zeros(len(final));selected={s['candidateIndex']:s for s in plan['selected']};assert len(selected)==plan['hospitalCount']==226
    minarea=math.inf;staff_bound=max(design['minimumDoctorsPerSite'],math.ceil(float(target)*(rates['contactsPerResident']*scenario['demandMultiplier'])/scenario['contactsPerDoctor']))
    for j,s in selected.items():
        assert type(j)is int and j in local and s['id']==C[j]['id'] and s['footprintRadiusMeters']==C[j]['footprintRadiusMeters']
        t=templates[tid[s['templateId']]];assert type(s['doctors'])is int and design['minimumDoctorsPerSite']<=s['doctors']<=staff_bound
        assert type(s['beds'])is int and s['beds']==t['beds']
        gross=D(t['grossAreaM2'])+D(s['doctors'])*D(design['areaPerDoctorM2']);assert abs(gross-D(s['grossAreaM2']))<=D('.001')
        slack=available[local[j]]-float(gross);assert slack>=-.001;minarea=min(minarea,slack)
        recon[prefix_index[local[j],tid[s['templateId']]]]=1;recon[nx+local[j]]=s['doctors']
    assert np.array_equal(recon[:nf],final[:nf])
    assert sum(s['beds'] for s in selected.values())==plan['totalBeds']==30900 and sum(s['doctors'] for s in selected.values())==plan['totalDoctors']==23066
    tr=Transformer.from_crs(4326,32636,always_xy=True);points={j:tr.transform(C[j]['lon'],C[j]['lat']) for j in selected};clearance=math.inf
    ordered=list(selected)
    for a,j in enumerate(ordered):
        for k in ordered[:a]:
            gap=math.dist(points[j],points[k])-C[j]['footprintRadiusMeters']-C[k]['footprintRadiusMeters'];assert gap>=-1e-7;clearance=min(clearance,gap)
    maximum={j:D(0) for j in selected};profiles=[];offset=nf;allocation_count=0;matrix_sha={}
    min_doc=D('Infinity');min_bed=D('Infinity');max_target=D(0);max_origin=D(0);min_district=D(100)
    for rec,p in zip(M['matrices'],plan['profiles']):
        blob=(base/rec['file']).read_bytes();assert SHA(blob)==rec['sha256'];matrix_sha[rec['file']]=SHA(blob)
        with np.load(io.BytesIO(blob),allow_pickle=False) as z:matrix=z['minutes']
        sub=matrix[:,pool];oi,sj=np.where(np.isfinite(sub)&(sub<=45));index={(int(i),pool[int(j)]):offset+k for k,(i,j) in enumerate(zip(oi,sj))};offset+=len(oi)
        served=[D(0) for _ in pop];loads={j:D(0) for j in selected};seen=set();person_minutes=D(0)
        for a in p['allocations']:
            i,j=a['demandIndex'],a['candidateIndex'];assert type(i)is int and type(j)is int and (i,j) in index and (i,j) not in seen and j in selected
            mass=D(a['population']);assert mass>0 and math.isfinite(a['population']);minutes=float(matrix[i,j]);assert math.isfinite(minutes) and minutes<=45 and abs(minutes-a['minutes'])<=1e-6
            seen.add((i,j));served[i]+=mass;loads[j]+=mass;person_minutes+=mass*D(minutes);recon[index[i,j]]=float(a['population'])/1000
        for key,v in vectors.items():
            f=v[offset-len(oi):offset]*1000;opened,beds,doctors,gross=vector_resources[key]
            assert np.all(f[opened[sj]==0]==0) and np.all(f<=np.array(pop,float)[oi]+1e-5)
            vserved=np.bincount(oi,weights=f,minlength=len(pop));vloads=np.bincount(sj,weights=f,minlength=len(pool))
            err=abs(vserved.sum()-float(target));over=float(np.max(vserved-np.array(pop,float),initial=0))
            assert err<=.0001 and over<=.0001
            checks=vector_checks[key];checks['maximumTargetErrorResidents']=max(checks['maximumTargetErrorResidents'],float(err));checks['maximumOriginOvershootResidents']=max(checks['maximumOriginOvershootResidents'],over)
            for did,dist in districts.items():
                value=sum(vserved[i] for i,x in enumerate(data['demands']) if x['districtId']==did)
                pct=100*value/dist['population'];assert pct>=80-1e-6 and value>=.8*dist['population']-.0001
                checks['minimumDistrictPercent']=min(checks['minimumDistrictPercent'],float(pct))
            dslack=doctors*scenario['contactsPerDoctor']-vloads*float(contact)
            bslack=beds*365*scenario['bedOccupancy']/100-vloads*float(bedrate)
            assert np.min(dslack)>=-.1 and np.min(bslack)>=-.1
            checks['minimumDoctorSlackContacts']=min(checks['minimumDoctorSlackContacts'],float(dslack.min()))
            checks['minimumBedSlackDays']=min(checks['minimumBedSlackDays'],float(bslack.min()))
        allocation_count+=len(seen);mass=sum(served);error=abs(mass-target);assert error<=D('.001');max_target=max(max_target,error)
        overshoot=max((served[i]-pop[i] for i in range(len(pop))),default=D(0));assert overshoot<=D('.001');max_origin=max(max_origin,overshoot)
        ds=[]
        for did,d in districts.items():
            cov=sum(served[i] for i,x in enumerate(data['demands']) if x['districtId']==did);pct=cov*100/D(d['population']);assert pct>=D('79.999999');min_district=min(min_district,pct);ds.append(dict(id=did,percent=str(pct)))
        docslack=[];bedslack=[]
        for j,s in selected.items():
            dsla=D(s['doctors'])*D(scenario['contactsPerDoctor'])-loads[j]*contact
            bsla=D(s['beds'])*365*D(scenario['bedOccupancy'])/100-loads[j]*bedrate
            assert dsla>=D('-.1') and bsla>=D('-.1');min_doc=min(min_doc,dsla);min_bed=min(min_bed,bsla)
            maximum[j]=max(maximum[j],loads[j])
        assert abs(D(p['coveredPopulation'])-mass)<=D('.001') and abs(D(p['meanMinutes'])-person_minutes/target)<=D('.000001')
        profiles.append(dict(profile=p['profile'],coveredResidents=str(mass),coveragePercent=str(mass*100/total),
            minimumDistrictPercent=str(min(D(d['percent']) for d in ds)),meanMinutes=str(person_minutes/target),allocationCount=len(seen)))
    assert offset==len(final)==145520 and np.array_equal(recon,final)
    for j,s in selected.items():assert abs(maximum[j]-D(s['maximumAssignedPopulationAcrossProfiles']))<=D('.001')
    r=D(eco['realDiscountRate']);years=D(eco['horizonYears']);annuity=r/(1-(1+r)**(-years)) if r else 1/years
    construction=sum(D(s['grossAreaM2']) for s in selected.values())*D(eco['buildingUnitCostTRY'])
    operating=sum(D(scenario['operatingCostMultiplier'])*(D(eco['annualFixedSiteCostTRY'])+D(s['beds'])*D(eco['annualBedSupportCostTRY'])+D(s['doctors'])*D(eco['annualDoctorCostTRY'])) for s in selected.values())
    material=target*contact*D(eco['costPerContactTRY'])*D(scenario['operatingCostMultiplier']);annual=construction*annuity+operating+material
    assert abs(annual-D(plan['annualEquivalentCostTRY']))<D('.001') and abs(material-D(plan['annualMaterialCostTRY']))<D('.001')
    budget=D(cert['budget']['limitTRY']);assert annual<=budget
    # Verify all vectors also obey footprint conflicts and original annual budget.
    for key,(opened,beds,doctors,gross) in vector_resources.items():
        active=np.flatnonzero(opened);xy={j:tr.transform(C[pool[j]]['lon'],C[pool[j]]['lat']) for j in active}
        for a,j in enumerate(active):
            for k in active[:a]:assert math.dist(xy[j],xy[k])>=C[pool[j]]['footprintRadiusMeters']+C[pool[k]]['footprintRadiusMeters']-1e-7
        resource_cost=D(float(gross.sum()))*D(eco['buildingUnitCostTRY'])*annuity+D(scenario['operatingCostMultiplier'])*(D(float(opened.sum()))*D(eco['annualFixedSiteCostTRY'])+D(float(beds.sum()))*D(eco['annualBedSupportCostTRY'])+D(float(doctors.sum()))*D(eco['annualDoctorCostTRY']))+material
        assert resource_cost<=budget;vector_checks[key]['decimalAnnualCostTRY']=str(resource_cost)
    for site in source['plan']['selected']:
        k=local[site['candidateIndex']];assert supplied[prefix_index[k,tid[site['templateId']]]]==1 and supplied[nx+k]==site['doctors']
    assert len(source['plan']['selected'])==vector_checks['suppliedOriginalVector']['hospitalCount']
    archive_bytes=(ROOT/'docs/experiments/departure-0805-evidence.zip').read_bytes();assert SHA(archive_bytes)==M['sourceSHA256']['docs/experiments/departure-0805-evidence.zip']
    with zipfile.ZipFile(io.BytesIO(archive_bytes)) as archive:
        oldmat=archive.read('work/referees/profile-shift-full-v07.npz');oldreport=archive.read('work/referees/profile-shift-full-v07.json');oldcut=archive.read('work/referees/departure-capacity-cut-v07.json')
    assert SHA(oldmat)==M['archived0805']['matrixSHA256'] and SHA(oldreport)==M['archived0805']['reportSHA256']
    with np.load(io.BytesIO(oldmat),allow_pickle=False) as z:
        old_ids=z['targetCandidateIndices'];old0805=z['minutes0805']
        with np.load(base/'weekday-0805.npz',allow_pickle=False) as current:assert np.array_equal(current['minutes'][:,old_ids],old0805)
    cut=json.loads(oldcut);assert cut['representedFixedResourceInfeasibilityCertified'] is True and cut['sourcePackageId']==cert['transitPackageId']
    oldcomparison=dict(oldArchiveSHA256=SHA(archive_bytes),oldCutSHA256=SHA(oldcut),same0805All1413By209Matrix=True,
        oldResources=dict(hospitals=209,beds=26400,doctors=23035),oldCutScope='Fixed209 resources only, previously separately certified; not reapplied to changed resources',
        final0805=next(p for p in profiles if p['profile']=='weekday-0805'),scope='New226 resource/location vector is feasible at08:05 under unchanged stored matrix. This does not invalidate the old fixed209 capacity cut.')
    lower=D(report['result']['minimumAnnualCostLowerBoundTRY']);gap=(annual-lower)/annual
    assert abs(gap-D(report['result']['costGap']))<D('1e-12')
    assert report['result']['provenOptimal'] is False and report['result']['nativeBoundIndependentlyCertified'] is False
    assert all((folder/n).read_bytes()==b for n,b in files.items()) and (base/'manifest.json').read_bytes()==manifest_bytes
    for p,h in report['modelCodeSHA256'].items():assert SHA((ROOT/p).read_bytes().replace(b'\r\n',b'\n'))==h
    out=dict(status='accepted_within_final_stored_44_profile_model',builtAt=datetime.now(timezone.utc).isoformat(),auditCodeLF_SHA256=SHA(Path(__file__).read_bytes().replace(b'\r\n',b'\n')),
        artifactSHA256={n:SHA(b) for n,b in files.items()},sourceSHA256=report['sourceSHA256'],modelCodeSHA256=report['modelCodeSHA256'],matrixSHA256=matrix_sha,
        candidatePoolCount=312,selectedHospitalCount=226,beds=30900,doctors=23066,profileCount=44,allocationCount=allocation_count,
        exactReconstructedFinalVector=True,allFiveOriginalVectorsValidated=vector_checks,
        nativeReturnedSuppliedVectorUnchanged=True,resourceCleanupPreservedCostStageFlows=True,
        finalTravelRefinementPreservedResources=True,finalRefinementChangedFlowVariables=int(np.count_nonzero(cost[nf:]!=final[nf:])),
        costImprovementSource='Resource-only cleanup after unchanged native incumbent; separate fixed-resource profile reassignment follows',
        old0805Comparison=oldcomparison,reportedCostGap=str(gap),nativeBoundIndependentlyCertified=False,
        boundScope='Reported solver bound only for supplied312 and44 profile integer model, not4701 or real-city/global proof',
        maximumProvinceTargetAbsoluteErrorResidents=str(max_target),maximumOriginPopulationOvershootResidents=str(max_origin),minimumDistrictPercent=str(min_district),
        minimumDoctorContactSlack=str(min_doc),minimumBedDaySlack=str(min_bed),minimumAreaSlackM2=minarea,minimumPlotClearanceMeters=clearance,
        decimalAnnualEquivalentCostTRY=str(annual),decimalMaterialCostTRY=str(material),decimalBudgetSlackTRY=str(budget-annual),profiles=profiles,
        routingCalls=0,nativeSolverCalls=0,scope='Independent complete JSON/NPZ and matrix-edge arithmetic for this 312-pool, 44 stored exact-minute final model. Original numerical tolerances unchanged. Separate flows may serve different people. No continuous-time/all-day/real-EGO reliability, minimum-count or global-cost-optimum claim. Native cost run stopped at time limit; resource cleanup and fixed-resource reassignment are independently feasible. Reported native lower bound is not independently certified.')
    path=ROOT/'work/referees/window312-final-transport-actual-audit.json'
    with path.open('x',encoding='utf8') as f:json.dump(out,f,ensure_ascii=False,indent=2);f.write('\n')
    print(json.dumps({k:out[k] for k in ['status','selectedHospitalCount','allocationCount','maximumProvinceTargetAbsoluteErrorResidents','maximumOriginPopulationOvershootResidents','minimumDistrictPercent','minimumDoctorContactSlack','minimumBedDaySlack','minimumAreaSlackM2','minimumPlotClearanceMeters','decimalAnnualEquivalentCostTRY','decimalBudgetSlackTRY']}|dict(reportSHA256=SHA(path.read_bytes()))))


if __name__=='__main__':main()
