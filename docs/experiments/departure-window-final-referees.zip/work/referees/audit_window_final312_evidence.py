"""Read-only final run and publication audit. Never invokes a native solver."""
from pathlib import Path
import hashlib, json, math, re, sys, zipfile
from decimal import Decimal, localcontext
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from scripts.audit_window_plan import audit_saved_window_plan

def h(b): return hashlib.sha256(b).hexdigest()
def read(path): return json.loads((ROOT / path).read_bytes())
def D(v): return Decimal(str(v))

def main():
    folder = ROOT / 'work/window-plans/joint312-v4'
    published = ROOT / 'data/processed/departure-window-plan'
    manifest_path = ROOT / 'data/processed/departure-window/manifest.json'
    summary = audit_saved_window_plan(published / 'window-plan.json', manifest_path)
    saved_summary = read('data/processed/window-plan-summary.json')
    assert summary == saved_summary
    report = json.loads((folder/'run-result.json').read_bytes())
    certificate = json.loads((folder/'window-plan.json').read_bytes())
    result, plan, s = report['result'], certificate['plan'], certificate['scenario']
    data, health = read('data/processed/dataset.json'), read('data/processed/health-planning.json')
    copied = {}
    expected_files = {'candidate-pool.json','process-status.json','resource-seed.json',
        'run-result.json','solver.log','vectors.npz','window-plan.json'}
    assert {p.name for p in published.iterdir()} == expected_files
    for name in expected_files:
        path, other = folder/name, published/name
        assert path.is_file() and path.read_bytes() == other.read_bytes(), name
        copied[name] = h(path.read_bytes())
    m = json.loads(manifest_path.read_bytes())
    old_manifest = ROOT / 'work/window-routing/full-v1/manifest.json'
    assert old_manifest.read_bytes() == manifest_path.read_bytes()
    matrix_copies = {}
    for record in m['matrices']:
        raw = (manifest_path.parent/record['file']).read_bytes()
        assert h(raw) == record['sha256']
        assert raw == (old_manifest.parent/record['file']).read_bytes()
        matrix_copies[record['profileId']] = h(raw)
    for name, expected in report['sourceSHA256'].items():
        assert h((ROOT/'data/processed'/name).read_bytes()) == expected
    for name, expected in report['modelCodeSHA256'].items():
        assert h((ROOT/name).read_bytes().replace(b'\r\n', b'\n')) == expected
    selected = {a['candidateIndex']:a for a in plan['selected']}
    pool = report['candidateIndices']; templates = health['templates']
    eligibility = [(j,t) for j,g in enumerate(pool) for t, template in enumerate(templates)
        if template['grossAreaM2'] + health['design']['minimumDoctorsPerSite']*health['design']['areaPerDoctorM2']
        <= math.pi*data['candidates'][g]['footprintRadiusMeters']**2*health['design']['maxFloors'] + .001]
    nx, nf = len(eligibility), len(eligibility)+len(pool)
    with np.load(folder/'vectors.npz',allow_pickle=False) as z:
        vectors = {name:z[name].copy() for name in z.files}
    assert np.array_equal(vectors['returnedRawVector'],vectors['suppliedOriginalVector'])
    assert np.array_equal(vectors['costStageNativeValidatedVector'][nf:],vectors['suppliedOriginalVector'][nf:])
    assert np.array_equal(vectors['finalOriginalVector'][:nf],vectors['costStageOriginalVector'][:nf])
    seed = json.loads((folder/'resource-seed.json').read_bytes())
    expected_seed = np.zeros(nf)
    pos = {key:i for i,key in enumerate(eligibility)}
    type_index = {t['id']:i for i,t in enumerate(templates)}
    for site in seed['plan']['selected']:
        j = pool.index(site['candidateIndex'])
        expected_seed[pos[(j,type_index[site['templateId']])]] = 1
        expected_seed[nx+j] = site['doctors']
    assert np.array_equal(vectors['suppliedOriginalVector'][:nf],expected_seed)
    log = (folder/'solver.log').read_text()
    assert 'MIP start solution is feasible' in log and 'Time limit reached' in log
    assert result['nativeRunStarted'] is True and result['timeLimitedFeasible'] is True
    assert result['provenOptimal'] is False and result['mipNodes'] == 0
    assert result['warmStart']['solverAcceptedFeasibleStart'] is True
    assert result['nativeBoundIndependentlyCertified'] is False
    assert result['boundCandidateIndices'] == pool and len(pool) == 312
    with localcontext() as context:
        context.prec = 60
        eco = health['economics']; template_map = {t['id']:t for t in templates}
        total = D(sum(d['population'] for d in data['districts']))
        target = total * D(s['coverageTarget'])/100
        contact = D(health['rates']['contactsPerResident'])*D(s['demandMultiplier'])
        bedrate = D(health['rates']['bedDaysPerResident'])*D(s['demandMultiplier'])
        rate, years = D(eco['realDiscountRate']), D(eco['horizonYears'])
        annuity = rate/(1-(1+rate)**(-years)) if rate else 1/years
        material = target*contact*D(eco['costPerContactTRY'])*D(s['operatingCostMultiplier'])
        def bill(sites):
            construction = sum((D(template_map[x['templateId']]['grossAreaM2'])+D(x['doctors'])*D(health['design']['areaPerDoctorM2']))*D(eco['buildingUnitCostTRY']) for x in sites)
            operating = sum((D(eco['annualFixedSiteCostTRY'])+D(x['beds'])*D(eco['annualBedSupportCostTRY'])+D(x['doctors'])*D(eco['annualDoctorCostTRY']))*D(s['operatingCostMultiplier']) for x in sites)
            return construction*annuity+operating+material
        annual = bill(list(selected.values())); seed_annual = bill(seed['plan']['selected'])
        reference = read('data/processed/joint-plan.json')
        reference_annual = bill(reference['plan']['selected'])
        budget = D(read('data/processed/example-transit-result.json')['capacity']['budgetLimitTRY'])
        assert annual <= budget and abs(annual-D(summary['decimalAnnualEquivalentCostTRY'])) < D('1e-30')
        assert abs(material-D(summary['decimalAnnualMaterialCostTRY'])) < D('1e-30')
        pop = [D(d['population']) for d in data['demands']]
        districts = {d['id']:d for d in data['districts']}
        maximum = dict.fromkeys(selected,D(0)); served_all=[]; profile_rows=[]
        for profile, matrix_record in zip(plan['profiles'],m['matrices']):
            assert profile['profile'] == matrix_record['profileId']
            with np.load(manifest_path.parent/matrix_record['file'],allow_pickle=False) as z: matrix=z['minutes']
            served=[D(0)]*len(pop); loads=dict.fromkeys(selected,D(0)); minutes=D(0); max_minutes=0
            seen=set()
            for a in profile['allocations']:
                i,j=a['demandIndex'],a['candidateIndex']; amount=D(a['population'])
                assert (i,j) not in seen and amount>0 and j in selected
                seen.add((i,j)); time=float(matrix[i,j]); assert math.isfinite(time) and time<=45 and time==a['minutes']
                served[i]+=amount;loads[j]+=amount;minutes+=amount*D(time);max_minutes=max(max_minutes,time)
            assert abs(sum(served)-target)<=D('.001')
            assert all(x<=p+D('.001') for x,p in zip(served,pop))
            dserved=dict.fromkeys(districts,D(0))
            for d,amount in zip(data['demands'],served):dserved[d['districtId']]+=amount
            dcover={k:dserved[k]/D(d['population'])*100 for k,d in districts.items()}
            assert min(dcover.values())>=D('79.999999')
            for j,site in selected.items():
                assert D(site['doctors'])*D(s['contactsPerDoctor'])-loads[j]*contact>=D('-.1')
                assert D(site['beds'])*365*D(s['bedOccupancy'])/100-loads[j]*bedrate>=D('-.1')
                maximum[j]=max(maximum[j],loads[j])
            assert abs(minutes/target-D(profile['meanMinutes']))<D('1e-6')
            profile_rows.append(dict(profile=profile['profile'],coveragePercent=float(sum(served)/total*100),minimumDistrictCoveragePercent=float(min(dcover.values())),meanMinutes=float(minutes/target),maxMinutes=max_minutes,allocations=len(seen)))
            served_all.append([min(p,max(D(0),a)) for p,a in zip(pop,served)])
        for j,site in selected.items():assert abs(maximum[j]-D(site['maximumAssignedPopulationAcrossProfiles']))<=D('.001')
        lower=sum(max(D(0),sum(row[i] for row in served_all)-(len(served_all)-1)*p) for i,p in enumerate(pop))
        upper=sum(min(row[i] for row in served_all) for i in range(len(pop)))
        overlap=dict(lowerPercent=float(lower/total*100),upperPercent=float(upper/total*100))
        for k,v in overlap.items():assert abs(v-summary['conditionalOverlap']['province'][k])<1e-10
        recomputed_gap=(annual-D(result['minimumAnnualCostLowerBoundTRY']))/annual
        assert abs(float(recomputed_gap)-result['costGap'])<1e-12
        economics=dict(annualEquivalentCostTRY=str(annual),annualMaterialCostTRY=str(material),hardBudgetTRY=str(budget),budgetSlackTRY=str(budget-annual),reference209AnnualTRY=str(reference_annual),increaseFrom209TRY=str(annual-reference_annual),seed228AnnualTRY=str(seed_annual),resourceCleanupSavingTRY=str(seed_annual-annual),reportedPoolOnlyLowerBoundTRY=result['minimumAnnualCostLowerBoundTRY'],recomputedPoolOnlyCostGap=float(recomputed_gap),nativeBoundIndependentlyCertified=False)
    archive=ROOT/'docs/experiments/departure-window-seed-evidence.zip'
    with zipfile.ZipFile(archive) as z:
        am=json.loads(z.read('archive-manifest.json'))
        assert all(h(z.read(n))==expected for n,expected in am['files'].items())
        archived_seed=z.read('work/window-repair/lp-expanded312-v1/canonical-four-source.json')
        assert archived_seed==(folder/'resource-seed.json').read_bytes()
        assert seed['generation']['researchReportSHA256']==h(z.read('work/window-repair/lp-expanded312-v1/repair-result.json'))
        assert seed['generation']['researchVectorSHA256']==h(z.read('work/window-repair/lp-expanded312-v1/vectors.npz'))
        assert all(h((ROOT/e['publishedRelativePath']).read_bytes())==e['sha256'] for e in am['externalWindowMatrices'])
    out=dict(status='narrow_model_and_published_artifact_acceptance',solverCalls=0,certificateSHA256=copied['window-plan.json'],runReportSHA256=copied['run-result.json'],vectorSHA256=copied['vectors.npz'],archiveSHA256=h(archive.read_bytes()),sourceCount=len(report['sourceSHA256']),modelCodeCount=len(report['modelCodeSHA256']),publishedRunCopies=copied,publishedMatrixCopies=matrix_copies,savedSummaryExactlyMatchesIndependentAudit=True,hospitalCount=plan['hospitalCount'],beds=plan['totalBeds'],doctors=plan['totalDoctors'],economics=economics,profiles=profile_rows,conditionalOverlap=overlap,nativeIncumbentEqualsSuppliedVector=True,costReductionIsResourceCleanup=True,costStageFlowUnchanged=True,travelChangedFlowEntries=int(np.count_nonzero(vectors['finalOriginalVector'][nf:]!=vectors['costStageOriginalVector'][nf:])),finalVectorLength=len(vectors['finalOriginalVector']),nativeStatus=result['nativeModelStatus'],mipNodes=result['mipNodes'],scope='Conditional feasibility for 44 named sampled minutes in the fixed transport/health model, original hard annual budget, 312-candidate search. No minimum-count, 91-hospital, all-day, real-service, clinical or full public-cost proof. Solver lower bound is reported, not independently dual-certified. Rounded tiny primal residuals use the unchanged published tolerances.')
    output=ROOT/'work/referees/window-final312-evidence-audit.json'
    output.write_text(json.dumps(out,ensure_ascii=False,allow_nan=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:out[k] for k in ('status','hospitalCount','beds','doctors','economics','conditionalOverlap','archiveSHA256')},ensure_ascii=False,indent=2))

if __name__=='__main__': main()
