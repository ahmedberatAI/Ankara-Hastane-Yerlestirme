"""Read-only actual-run review. No solver or routing call is made."""
from pathlib import Path
import sys,json,hashlib,re,math
from decimal import Decimal,localcontext
import numpy as np
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.audit_window_plan import read_window_inputs,unchanged_window_inputs,code_hashes
from scripts.run_window_plan import formulate
from scripts.run_joint_plan import PLAN_FIELDS
P=ROOT/'work/window-plans/joint312-v4'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_bytes())
files={p.name:sha(p) for p in P.iterdir() if p.is_file()}
report=load(P/'run-result.json');certificate=load(P/'window-plan.json');result=report['result'];seed=load(P/'resource-seed.json')
inputs=read_window_inputs(ROOT/'work/window-routing/full-v1/manifest.json')
assert inputs['current_code_hashes']==report['modelCodeSHA256']==code_hashes()
assert inputs['current_source_hashes']==report['sourceSHA256'] and inputs['manifest_sha256']==report['profileManifestSHA256']
assert sha(P/'vectors.npz')==report['vectorSHA256']==certificate['generation']['vectorSHA256']
assert sha(P/'solver.log')==report['solverLogSHA256'] and sha(P/'run-result.json')==certificate['generation']['runReportSHA256']
assert sha(P/'resource-seed.json')==report['resourceSeedSHA256']
assert sha(P/'candidate-pool.json')==report['candidatePoolSHA256']
pool=load(P/'candidate-pool.json')['candidateIndices'];assert pool==report['candidateIndices']
f=formulate(inputs,pool);assert len(pool)==312 and len(f.times)==44 and len(f.conflicts)==12
assert report['optimizedProfiles']==report['validatedProfiles']==list(f.times)
assert f.model[4].shape==(101201,145520) and f.nx==1572 and f.nf==1884
assert np.array_equal(f.model[0],f.c) and np.all(f.model[3][:f.nx]==1)
assert all(len(f.site_xs[j]) and f.model[3][f.nx+j]>0 for j in range(f.m))
# Prior seed closures are not present in the original MIP variable bounds.
prior_closed=[401,1495,1548,1679,1832,1833,2450,2571,3411,4536]
for candidate in prior_closed:
 j=f.local[candidate];assert np.all(f.model[3][f.site_xs[j]]==1) and f.model[3][f.nx+j]>0
vectors=np.load(P/'vectors.npz');residuals={}
for name in vectors.files:residuals[name]=f.validate(vectors[name])[0]
final=vectors['finalOriginalVector'];cost=vectors['costStageOriginalVector'];raw=vectors['returnedRawVector'];start=vectors['suppliedOriginalVector'];native_clean=vectors['costStageNativeValidatedVector']
wire,_=f.read_plan(certificate['plan']);assert np.array_equal(wire,final)
assert certificate['plan']=={k:result[k] for k in PLAN_FIELDS}
assert np.array_equal(final[:f.nf],cost[:f.nf])
assert np.array_equal(f.fixed_resource_vector(seed['plan'])[:f.nf],start[:f.nf])
assert np.array_equal(raw,start)
assert np.array_equal(raw[f.nf:],native_clean[f.nf:])
assert np.all(np.abs(cost-native_clean)<=2*np.spacing(np.maximum(np.abs(cost),np.abs(native_clean))))
assert abs(f.cost(raw)-f.cost(native_clean)-result['resourceCleanup']['annualCostReductionTRY'])<.01
# Independently form the original annual bill, with material exactly once.
D=lambda v:Decimal(str(v))
with localcontext() as ctx:
 ctx.prec=50;h=inputs['health'];s=certificate['scenario'];eco=h['economics'];design=h['design'];templates={t['id']:t for t in h['templates']}
 rate=D(eco['realDiscountRate']);years=D(eco['horizonYears']);annuity=rate/(1-(1+rate)**(-years)) if rate else 1/years;oper=D(s.get('operatingCostMultiplier',1))
 fixed=Decimal(0)
 for site in certificate['plan']['selected']:
  area=D(templates[site['templateId']]['grossAreaM2'])+D(site['doctors'])*D(design['areaPerDoctorM2'])
  fixed+=area*D(eco['buildingUnitCostTRY'])*annuity+oper*(D(eco['annualFixedSiteCostTRY'])+D(site['beds'])*D(eco['annualBedSupportCostTRY'])+D(site['doctors'])*D(eco['annualDoctorCostTRY']))
 target=D(inputs['data']['metadata']['provincePopulation'])*D(s['coverageTarget'])/100
 material=target*D(h['rates']['contactsPerResident'])*D(s['demandMultiplier'])*D(eco['costPerContactTRY'])*oper
 annual=fixed+material;budget=D(certificate['budget']['limitTRY']);assert annual<=budget
 assert abs(annual-D(result['annualEquivalentCostTRY']))<D('.01')
 decimal_cost=dict(annualTRY=str(annual),fixedTRY=str(fixed),materialOnceTRY=str(material),hardBudgetTRY=str(budget),slackTRY=str(budget-annual))
# The native objective and lower bound refer to this original model only.
log=(P/'solver.log').read_text(encoding='utf8')
assert 'MIP start solution is feasible' in log and 'Time limit reached' in log and 'Solution status   feasible' in log
printed_start=float(re.search(r'MIP start solution is feasible, objective value is ([0-9.e+-]+)',log).group(1))
printed_dual=float(re.search(r'Dual bound\s+([0-9.e+-]+)',log).group(1))
assert abs(printed_start-f.c@start)<1e-9
printed_annual_dual=printed_dual*f.cost_scale+f.material
assert abs(printed_annual_dual-result['minimumAnnualCostLowerBoundTRY'])<1.
annual_gap=(f.cost(final)-result['minimumAnnualCostLowerBoundTRY'])/f.cost(final)
assert abs(annual_gap-result['costGap'])<1e-12
scaled_dual=(result['minimumAnnualCostLowerBoundTRY']-f.material)/f.cost_scale
native_resource_gap=((f.c@raw)-scaled_dual)/(f.c@raw)
assert abs(native_resource_gap-result['solverReportedGap'])<1e-12
assert result['timeLimitedFeasible'] and not result['provenOptimal'] and not result['nativeBoundIndependentlyCertified']
assert result['boundScope']=='supplied_candidate_pool_and_exact_named_profile_set'
assert result['warmStart']['solverAcceptedFeasibleStart'] and result['warmStart']['completeStartSupplied']
assert result['travelRefinement']['independentlyCertifiedOptimality'] is False
# Profile means/quotas independently calculated from edge arrays and matrix.
data=inputs['data'];pops=np.array([x['population'] for x in data['demands']]);district=np.array([x['districtId'] for x in data['demands']]);profiles=[]
for name,(oi,sj) in f.edges.items():
 times=f.times[name][oi,sj];a=final[f.offsets[name]:f.offsets[name]+len(oi)]*1000;b=cost[f.offsets[name]:f.offsets[name]+len(oi)]*1000
 served=np.bincount(oi,weights=a,minlength=f.n);assert np.all(served<=pops+.001)
 total=float(a.sum());before=float(times@b/b.sum());after=float(times@a/a.sum())
 assert abs(total-float(target))<=.001 and after<=before+1e-7
 district_coverage={str(d['id']):float(served[district==d['id']].sum()/d['population']*100) for d in data['districts']}
 assert min(district_coverage.values())>=s['districtFloor']-1e-6
 assert abs(after-next(p['meanMinutes'] for p in result['profiles'] if p['profile']==name))<1e-10
 profiles.append(dict(profile=name,servedEquivalentResidents=total,minimumDistrictCoveragePercent=min(district_coverage.values()),beforeFixedResourceTravelMinutes=before,finalMeanMinutes=after,meanImprovementMinutes=before-after,positiveAssignments=int((a>0).sum())))
old=inputs['source_cost_certificate']['plan'];oldids={s['candidateIndex'] for s in old['selected']};newids={s['candidateIndex'] for s in result['selected']};seedids={s['candidateIndex'] for s in seed['plan']['selected']}
summary=dict(status='accepted_model_feasibility_and_arithmetic_with_qualified_scope',blockers=[],sourceArtifactSHA256=files,reviewerScriptSHA256=sha(Path(__file__)),sourceModelFilesVerified=14,sourceDataFilesVerified=9,profileCount=44,candidateCount=312,
 originalObjectiveAndUnrestricted312VariableBoundsRestored=True,seedClosureCandidatesFreeInFinalModel=prior_closed,heuristicOpeningPenaltyInFinalModel=False,
 allVectorsOriginalModelResiduals=residuals,finalJsonVectorExact=True,nativeReturnedVectorEqualsSuppliedStart=True,nativeCostSearchFoundBetterIncumbent=False,
 postprocessing=dict(closedLocations=sorted(seedids-newids),removedHospitalCount=seed['plan']['hospitalCount']-result['hospitalCount'],removedBeds=seed['plan']['totalBeds']-result['totalBeds'],removedDoctors=seed['plan']['totalDoctors']-result['totalDoctors'],annualCostReductionTRY=result['resourceCleanup']['annualCostReductionTRY'],nativeFlowPreservedByCleanup=True),
 finalResources=dict(hospitals=result['hospitalCount'],beds=result['totalBeds'],doctors=result['totalDoctors']),decimalAnnualCost=decimal_cost,
 costBound=dict(solverReportedAnnualLowerBoundTRY=result['minimumAnnualCostLowerBoundTRY'],printedLogAnnualLowerBoundTRY=printed_annual_dual,finalAnnualCostGap=annual_gap,nativeResourceObjectiveGap=native_resource_gap,independentlyCertified=False,scope='Only exact supplied312 candidate pool and44 matrices, original annual-cost objective'),
 travel=dict(all44NativeProfileStatusesOptimal=True,all44MeansNonWorsening=True,independentlyCertifiedOptimality=False,globalTravelOptimumProven=False,resourcesAndAnnualBillUnchanged=True,minimumMeanMinutes=min(p['finalMeanMinutes'] for p in profiles),maximumMeanMinutes=max(p['finalMeanMinutes'] for p in profiles),largestImprovementMinutes=max(p['meanImprovementMinutes'] for p in profiles)),
 old209Comparison=dict(retainedLocations=len(oldids&newids),newLocations=len(newids-oldids),removedLocations=len(oldids-newids),hospitalDelta=result['hospitalCount']-old['hospitalCount'],bedDelta=result['totalBeds']-old['totalBeds'],doctorDelta=result['totalDoctors']-old['totalDoctors'],annualCostDeltaTRY=result['annualEquivalentCostTRY']-old['annualEquivalentCostTRY']),
 native=dict(status=result['nativeModelStatus'],nodes=result['mipNodes'],nativeSeconds=result['solverSeconds'],searchSeconds=report['searchElapsedSeconds'],searchOverrunSeconds=report['cooperativeSearchOverrunSeconds'],outerSeconds=load(P/'process-status.json')['elapsedSeconds']),profiles=profiles,
 limitations=['Feasible sampled-clock model plan, not real-city demand or clinical validation','No global4701 cost optimum or minimum hospital count proof','44profile quotas do not identify the same95percent of people','Native cost lower bound and travel optimality are not independently exact dual certificates','Current transit completeness and health/FTE/public-cost calibration limitations remain'])
unchanged_window_inputs(inputs);assert code_hashes()==report['modelCodeSHA256'];assert files=={p.name:sha(p) for p in P.iterdir() if p.is_file()}
out=ROOT/'work/referees/joint312-v4-optimization-actual-audit.json'
with out.open('x',encoding='utf8') as f:json.dump(summary,f,indent=2)
print(json.dumps({k:v for k,v in summary.items() if k not in ['profiles','sourceArtifactSHA256','allVectorsOriginalModelResiduals']}))
print('reportSHA256',sha(out))
